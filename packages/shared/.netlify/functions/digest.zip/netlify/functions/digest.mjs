
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/digest.mts
import { PrismaClient } from "@prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";
import { getConnectionString, MissingDatabaseConnectionError } from "@netlify/database";

// packages/shared/src/digest.ts
var RANK = Object.freeze({
  NOW: 3,
  TODAY: 2,
  SOON: 1
});
var DEADLINE_URGENCY = Object.freeze({
  /* Already late. There is no softer word for this. */
  OVERDUE: "NOW",
  /* An obligation the instrument words as "without delay" — it has no
     computed window to be due soon within, so it is always NOW. */
  WITHOUT_DELAY: "NOW",
  DUE_SOON: "TODAY",
  /* Outstanding with time in hand. Deliberately silent: a digest that
     lists every open obligation every day is a list, not a warning. */
  PENDING: null,
  /* Done. */
  MET: null
});
var CURRENCY_URGENCY = Object.freeze({
  LAPSED: "TODAY",
  DUE_SOON: "SOON",
  CURRENT: null,
  NO_EXPIRY: null
});
var CONTACT_URGENCY = Object.freeze({
  NEVER_VERIFIED: "TODAY",
  STALE: "TODAY",
  DUE_SOON: "SOON",
  CURRENT: null
});
function worst(levels) {
  let best = null;
  for (const level of levels) {
    if (best === null || RANK[level] > RANK[best]) best = level;
  }
  return best;
}
function highest(items) {
  return worst(items.map((i) => i.urgency));
}
function soonest(days) {
  const known = days.filter((d) => d !== null);
  return known.length ? Math.min(...known) : null;
}
function digestFor(input) {
  const items = [];
  const deadlines = input.deadlines.filter((d) => DEADLINE_URGENCY[d.status] !== null);
  if (deadlines.length) {
    items.push({
      kind: "DEADLINE",
      urgency: worst(deadlines.map((d) => DEADLINE_URGENCY[d.status])),
      count: deadlines.length,
      soonestDays: soonest(deadlines.map((d) => d.daysLeft)),
      href: "/triage"
    });
  }
  const currencies = input.currencies.filter((c) => CURRENCY_URGENCY[c.state] !== null);
  if (currencies.length) {
    items.push({
      kind: "CURRENCY",
      urgency: worst(currencies.map((c) => CURRENCY_URGENCY[c.state])),
      count: currencies.length,
      soonestDays: soonest(currencies.map((c) => c.daysLeft)),
      href: "/sms"
    });
  }
  if (input.untriaged > 0) {
    items.push({
      kind: "UNTRIAGED",
      urgency: "SOON",
      count: input.untriaged,
      soonestDays: null,
      href: "/triage"
    });
  }
  if (input.overdueActions.length) {
    items.push({
      kind: "ACTION_OVERDUE",
      urgency: "TODAY",
      count: input.overdueActions.length,
      soonestDays: soonest(input.overdueActions.map((a) => a.daysLeft)),
      href: "/toolkits/register"
    });
  }
  const contacts = input.contacts.filter((contact) => CONTACT_URGENCY[contact.state] !== null);
  if (contacts.length) {
    items.push({
      kind: "CONTACT",
      urgency: worst(contacts.map((contact) => CONTACT_URGENCY[contact.state])),
      count: contacts.length,
      soonestDays: soonest(contacts.map((contact) => contact.daysLeft)),
      href: "/sms"
    });
  }
  return Object.freeze({ items: Object.freeze(items), urgency: highest(items) });
}
function isWorthSending(digest) {
  return digest.items.length > 0;
}

// packages/shared/src/currency.ts
var DUE_SOON_FRACTION = 0.25;
var MIN_WINDOW_DAYS = 7;
var MAX_WINDOW_DAYS = 90;
var DAY_MS = 864e5;
function wholeDaysBetween(from, to) {
  const a = Date.UTC(from.getFullYear(), from.getMonth(), from.getDate());
  const b = Date.UTC(to.getFullYear(), to.getMonth(), to.getDate());
  return Math.round((b - a) / DAY_MS);
}
function windowFor(record) {
  if (!record.expiresOn) return null;
  const validity = wholeDaysBetween(record.completedOn, record.expiresOn);
  if (validity <= 0) return MIN_WINDOW_DAYS;
  const proportional = Math.round(validity * DUE_SOON_FRACTION);
  return Math.min(MAX_WINDOW_DAYS, Math.max(MIN_WINDOW_DAYS, proportional));
}
function currencyOf(record, today) {
  if (!record.expiresOn) return { state: "NO_EXPIRY", daysLeft: null, windowDays: null };
  const daysLeft = wholeDaysBetween(today, record.expiresOn);
  const windowDays = windowFor(record);
  if (daysLeft < 0) return { state: "LAPSED", daysLeft, windowDays };
  if (windowDays !== null && daysLeft <= windowDays) {
    return { state: "DUE_SOON", daysLeft, windowDays };
  }
  return { state: "CURRENT", daysLeft, windowDays };
}

// packages/shared/src/erp.ts
var VERIFY_WITHIN_DAYS = 182;
var VERIFY_WARN_DAYS = 30;
var at = (v) => {
  if (!v) return null;
  const d = v instanceof Date ? v : new Date(v);
  return Number.isNaN(d.getTime()) ? null : d;
};
var DAY = 864e5;
function freshnessOf(c, today) {
  const verified = at(c.verifiedOn);
  if (!verified) return "NEVER_VERIFIED";
  const age = Math.floor((today.getTime() - verified.getTime()) / DAY);
  if (age >= VERIFY_WITHIN_DAYS) return "STALE";
  if (age >= VERIFY_WITHIN_DAYS - VERIFY_WARN_DAYS) return "DUE_SOON";
  return "CURRENT";
}
function daysUntilStale(c, today) {
  const verified = at(c.verifiedOn);
  if (!verified) return null;
  const age = Math.floor((today.getTime() - verified.getTime()) / DAY);
  return VERIFY_WITHIN_DAYS - age;
}

// packages/shared/src/regulations.ts
var JURISDICTIONS = ["ICAO", "KE", "UG", "TZ", "RW", "BI", "SS", "CD", "SO"];
var MOR_OBLIGATIONS = {
  ICAO: {
    jurisdiction: "ICAO",
    authority: "ICAO Standards and Recommended Practices",
    sourceLevel: "PRIMARY",
    hours: null,
    clockStart: "AWARENESS",
    instrument: "ICAO Annex 13, Chapter 4, 4.1 \u2014 notification with a minimum of delay and by the most suitable and quickest means available; with Annex 19 (Safety Management), which requires the State to operate mandatory and voluntary safety reporting systems and leaves the reporting period to the State",
    verifiedOn: "2026-08-12",
    instrumentIssued: "2016-07-01",
    reviewCycleMonths: 36,
    note: "NO FIXED PERIOD, and that is the finding rather than a gap in this row. The 72 hours widely quoted as an ICAO figure is the EU's, from Regulation (EU) No 376/2014 \u2014 misattribution common enough that three rows of this very table once carried it as an 'ICAO-common' default. Use this baseline where the State's own instrument has not been read: notify without delay, and obtain the period from the authority of the State of the operator."
  },
  KE: {
    jurisdiction: "KE",
    authority: "Kenya Civil Aviation Authority",
    sourceLevel: "PRIMARY",
    regionalFramework: "CASSOA",
    /* The strictest of the three below, used when the class is not yet
       known. Never a middle value: an unknown occurrence is treated as
       the one with the least time, because the cost of being early is
       an inconvenience and the cost of being late is a breach. */
    hours: 24,
    /* Regulation 12(1), verbatim: a service provider shall notify and
       make mandatory occurrence reports "to the Authority within 24
       hours, in the case of accident, 48 hours in the case of serious
       incidents and 72 hours in the case of incidents and other safety
       related occurrences." */
    hoursByClass: { ACCIDENT: 24, SERIOUS_INCIDENT: 48, INCIDENT: 72 },
    clockStart: "AWARENESS",
    /* ================================================================
           IT USED TO BE OUR READING. IT IS NOW THE AUTHORITY'S WORDS.
    
           This carried `clockStartUnstated: true` and a note saying that
           L.N. 32 states a period and never says what starts it, so
           awareness was the product's own inference and the screens said
           so. That was honest and it was the best available answer until
           somebody read the governing Advisory Circular.
    
           CAA-AC-SMS004A (January 2023), paragraph 3.3.6.1, Note 1:
    
             "The reporting period is normally understood to start from
              when the incident took place or from the time when the
              reporter determined that there was, or could have been, a
              potentially hazardous or unsafe condition."
    
           So the Authority does state it, in the instrument sitting above
           this row rather than in the row's own. Awareness is not our
           inference; it is the second limb of the Authority's sentence,
           and the first limb collapses into it — for an occurrence
           somebody knew about as it happened, "when it took place" and
           "when the reporter determined" are the same moment. There is no
           case where the awareness anchor is later than the AC allows.
    
           THE AC PREDATES L.N. 32 AND IS STILL THE REFERENCE. Its own
           deadline table — incident 72 hours, serious incident 48,
           accident 24 — is the same table regulation 12(1) later enacted,
           so it is confirmatory rather than superseded, and the owner's
           instruction was to use it on that basis.
    
           The two facts now come from two instruments, which is why the
           clock start carries its own citation rather than borrowing the
           deadline's. Conflating them would attribute a sentence to L.N. 32
           that L.N. 32 does not contain — the exact misattribution the
           header of this file exists to complain about. */
    clockStartInstrument: "KCAA Advisory Circular CAA-AC-SMS004A (January 2023), paragraph 3.3.6.1, Note 1",
    instrument: "Civil Aviation (Safety Management) Regulations, 2025 (L.N. 32 of 2026, Kenya Gazette Supplement No. 43, 3 March 2026), regulation 12(1)",
    verifiedOn: "2026-08-12",
    /* The date of gazettement, which is the date the instrument bears.
       Note the citation year and the notice year differ — the
       Regulations are cited as of 2025 and were gazetted in 2026, and
       both appear above because an operator searching either will find
       it. */
    instrumentIssued: "2026-03-03",
    reviewCycleMonths: 60,
    note: "THREE PERIODS, NOT ONE, and which applies depends on how the occurrence classifies: 24 hours for an accident, 48 for a serious incident, 72 for an incident or other safety related occurrence. This product previously showed 24 hours for all of them, from KCAA Advisory Circular CAA-AC-SMS004A (January 2023) \u2014 guidance, and now superseded. Regulation 18 of these Regulations revokes L.N. 91/2018.",
    /* THE SECOND CALL, and the reason this field exists at all.
           Regulation 12(1) above is owed to KCAA. Annex 13 puts an
           independent duty on the operator to notify the investigators,
           and the AAID is a different organisation under a different
           ministry. Immediately, and not within any of the three periods
           above — the periods are about the paperwork to the regulator.
    
           THE PROSE STAYS SHORT because this module is in the entry chunk
           that a reporter at a remote strip downloads before filing
           anything. The reasoning belongs in comments, which minify away;
           string values do not. Raising the entry budget to carry an
           argument is a cost paid by the person this product exists for. */
    accidentNotification: {
      authority: "Aircraft Accident Investigation Department (AAID), Kenya",
      url: "https://aaid.transport.go.ke/",
      appliesTo: ["ACCIDENT", "SERIOUS_INCIDENT"],
      basis: "Annex 13 to the Convention on International Civil Aviation.",
      domesticInstrumentRead: false,
      note: "Immediate, and separate from the report to the Authority. Confirm their numbers from the AAID and record them in your emergency contact directory."
    }
  },
  // ------------------------------------------------------------------
  // EAC MEMBER STATES — PROVISIONAL
  //
  // All seven rows below are PROVISIONAL. No primary instrument has been
  // read for any of them. Each row cites ICAO Annex 13, which binds all
  // Chicago Convention signatories and sets the floor: notification with
  // a minimum of delay. The period is null — no fixed figure enters this
  // registry without a citation.
  //
  // To graduate a row from provisional: read the State's own civil
  // aviation regulations and advisory circulars, confirm the period and
  // the clock start, and replace this note with a dated citation.
  // ------------------------------------------------------------------
  UG: {
    jurisdiction: "UG",
    authority: "Uganda Civil Aviation Authority",
    sourceLevel: "PROVISIONAL",
    regionalFramework: "CASSOA",
    hours: null,
    clockStart: "AWARENESS",
    instrument: "ICAO Annex 13, Chapter 4 \u2014 notification with a minimum of delay, by the most suitable and quickest means available. Uganda's own civil aviation regulations have not been read against this row.",
    verifiedOn: "2026-08-19",
    instrumentIssued: "2016-07-01",
    reviewCycleMonths: 12,
    note: "PROVISIONAL \u2014 primary instrument (Uganda Civil Aviation Act and any advisory circulars on occurrence reporting) has not been read. Use ICAO baseline: notify without delay and confirm the period with UCAA directly."
  },
  TZ: {
    jurisdiction: "TZ",
    authority: "Tanzania Civil Aviation Authority",
    sourceLevel: "PROVISIONAL",
    regionalFramework: "CASSOA",
    hours: null,
    clockStart: "AWARENESS",
    instrument: "ICAO Annex 13, Chapter 4 \u2014 notification with a minimum of delay, by the most suitable and quickest means available. Tanzania's own civil aviation regulations have not been read against this row.",
    verifiedOn: "2026-08-19",
    instrumentIssued: "2016-07-01",
    reviewCycleMonths: 12,
    note: "PROVISIONAL \u2014 primary instrument (Tanzania Civil Aviation Act and TCAA regulations on occurrence reporting) has not been read. Use ICAO baseline: notify without delay and confirm the period with TCAA directly."
  },
  RW: {
    jurisdiction: "RW",
    authority: "Rwanda Civil Aviation Authority",
    sourceLevel: "PROVISIONAL",
    regionalFramework: "CASSOA",
    hours: null,
    clockStart: "AWARENESS",
    instrument: "ICAO Annex 13, Chapter 4 \u2014 notification with a minimum of delay, by the most suitable and quickest means available. Rwanda's own civil aviation regulations have not been read against this row.",
    verifiedOn: "2026-08-19",
    instrumentIssued: "2016-07-01",
    reviewCycleMonths: 12,
    note: "PROVISIONAL \u2014 primary instrument (Rwanda Civil Aviation Law and RCAA regulations on occurrence reporting) has not been read. Use ICAO baseline: notify without delay and confirm the period with RCAA directly."
  },
  BI: {
    jurisdiction: "BI",
    authority: "Agence Nationale de l'Aviation Civile du Burundi",
    sourceLevel: "PROVISIONAL",
    regionalFramework: "CASSOA",
    hours: null,
    clockStart: "AWARENESS",
    instrument: "ICAO Annex 13, Chapter 4 \u2014 notification with a minimum of delay, by the most suitable and quickest means available. Burundi's own civil aviation regulations have not been read against this row.",
    verifiedOn: "2026-08-19",
    instrumentIssued: "2016-07-01",
    reviewCycleMonths: 12,
    note: "PROVISIONAL \u2014 primary instrument (Burundi civil aviation law and ANAC-BI regulations on occurrence reporting) has not been read. Use ICAO baseline: notify without delay and confirm the period with ANAC-BI directly."
  },
  SS: {
    jurisdiction: "SS",
    authority: "South Sudan Civil Aviation Authority",
    sourceLevel: "PROVISIONAL",
    regionalFramework: "CASSOA",
    hours: null,
    clockStart: "AWARENESS",
    instrument: "ICAO Annex 13, Chapter 4 \u2014 notification with a minimum of delay, by the most suitable and quickest means available. South Sudan's own civil aviation regulations have not been read against this row.",
    verifiedOn: "2026-08-19",
    instrumentIssued: "2016-07-01",
    reviewCycleMonths: 12,
    note: "PROVISIONAL \u2014 primary instrument (South Sudan Civil Aviation Act and SSCAA regulations on occurrence reporting) has not been read. Use ICAO baseline: notify without delay and confirm the period with SSCAA directly."
  },
  CD: {
    jurisdiction: "CD",
    authority: "Direction G\xE9n\xE9rale de l'Aviation Civile (DRC)",
    sourceLevel: "PROVISIONAL",
    regionalFramework: "CASSOA",
    hours: null,
    clockStart: "AWARENESS",
    instrument: "ICAO Annex 13, Chapter 4 \u2014 notification with a minimum of delay, by the most suitable and quickest means available. DRC's own civil aviation regulations have not been read against this row.",
    verifiedOn: "2026-08-19",
    instrumentIssued: "2016-07-01",
    reviewCycleMonths: 12,
    note: "PROVISIONAL \u2014 primary instrument (DRC civil aviation code and DGAC regulations on occurrence reporting) has not been read. Use ICAO baseline: notify without delay and confirm the period with DGAC-DRC directly."
  },
  SO: {
    jurisdiction: "SO",
    authority: "Somali Civil Aviation Authority",
    sourceLevel: "PROVISIONAL",
    regionalFramework: "CASSOA",
    hours: null,
    clockStart: "AWARENESS",
    instrument: "ICAO Annex 13, Chapter 4 \u2014 notification with a minimum of delay, by the most suitable and quickest means available. Somalia's own civil aviation regulations have not been read against this row.",
    verifiedOn: "2026-08-19",
    instrumentIssued: "2016-07-01",
    reviewCycleMonths: 12,
    note: "PROVISIONAL \u2014 primary instrument (Somalia Civil Aviation Law and SCAA regulations on occurrence reporting) has not been read. Use ICAO baseline: notify without delay and confirm the period with SCAA directly."
  }
};
function reportingHours(jurisdiction, occurrenceClass) {
  const obligation = MOR_OBLIGATIONS[jurisdiction];
  return (occurrenceClass && obligation.hoursByClass?.[occurrenceClass]) ?? obligation.hours;
}
function reportingDeadline(jurisdiction, times, occurrenceClass) {
  const obligation = MOR_OBLIGATIONS[jurisdiction];
  const anchor = obligation.clockStart === "AWARENESS" ? times.awareAt : times.occurredAt;
  if (Number.isNaN(anchor.getTime())) {
    throw new Error(
      `reportingDeadline: ${obligation.clockStart === "AWARENESS" ? "awareAt" : "occurredAt"} is not a valid date`
    );
  }
  if (times.awareAt.getTime() < times.occurredAt.getTime()) {
    throw new Error("reportingDeadline: awareAt precedes occurredAt");
  }
  const hours = reportingHours(jurisdiction, occurrenceClass);
  return {
    due: hours === null ? null : new Date(anchor.getTime() + hours * 36e5),
    obligation,
    hours
  };
}
function deadlineStatus(due, now, options = {}) {
  const { submittedAt, obligation, dueSoonHours } = options;
  if (due === null) return submittedAt ? "MET" : "WITHOUT_DELAY";
  if (submittedAt) {
    return submittedAt.getTime() <= due.getTime() ? "MET" : "OVERDUE";
  }
  if (now.getTime() > due.getTime()) return "OVERDUE";
  const windowMs = dueSoonHours !== void 0 ? dueSoonHours * 36e5 : obligation?.hours != null ? obligation.hours * DUE_SOON_FRACTION2 * 36e5 : DEFAULT_DUE_SOON_HOURS * 36e5;
  return due.getTime() - now.getTime() <= windowMs ? "DUE_SOON" : "PENDING";
}
var DUE_SOON_FRACTION2 = 0.25;
var DEFAULT_DUE_SOON_HOURS = 6;

// apps/api/src/digest.compute.ts
var UNTRIAGED_STATE = "SUBMITTED";
var DEADLINE_LOOKBACK_DAYS = 90;
var ROW_LIMIT = 500;
var TRAINING_LIMIT = 2e3;
var CONTACT_LIMIT = 300;
async function computeDigest(prisma, orgId, now) {
  const org = await prisma.org.findUnique({
    where: { id: orgId },
    select: { jurisdiction: true }
  });
  if (!org) return null;
  const [open, training, untriaged, overdue, contacts] = await Promise.all([
    prisma.safetyReport.findMany({
      where: {
        orgId,
        /* RETRACTED REPORTS DO NOT OWE A NOTIFICATION. A duplicate
           filed twice and corrected is not two occurrences, and a
           digest that counts it is a digest that sends somebody to
           telephone an authority about a report that was withdrawn. */
        retractedAt: null,
        type: "MOR",
        /* The column that did not exist when the deadline engine was
           written, and the whole reason the section was empty. */
        reportedToAuthorityAt: null,
        /* CLOSED IS OUT. A report the safety office has finished with is
           not today's action, and leaving it in means an operator that
           closed an occurrence without recording the call gets told
           about it every morning for ever. */
        state: { not: "CLOSED" },
        createdAt: { gte: new Date(now.getTime() - DEADLINE_LOOKBACK_DAYS * 864e5) }
      },
      select: { occurredAt: true, awareAt: true, createdAt: true },
      /* OLDEST FIRST. The cap keeps whatever it reads, so taking the
         NEWEST would drop precisely the overdue ones this is for. */
      orderBy: { createdAt: "asc" },
      take: ROW_LIMIT
    }),
    prisma.trainingRecord.findMany({
      where: { orgId },
      select: { completedOn: true, expiresOn: true },
      take: TRAINING_LIMIT
    }),
    prisma.safetyReport.count({ where: { orgId, retractedAt: null, state: UNTRIAGED_STATE } }),
    /* THE DATES, NOT A COUNT. Padding a count with a placeholder made a
       195-day-old action read as "overdue by 1 days" — a number the
       reader acts on and the caller invented. */
    prisma.correctiveAction.findMany({
      where: { orgId, verifiedOn: null, cancelledOn: null, dueOn: { lt: now } },
      select: { dueOn: true },
      orderBy: { dueOn: "asc" },
      take: ROW_LIMIT
    }),
    prisma.emergencyContact.findMany({
      where: { orgId },
      select: { verifiedOn: true },
      orderBy: [
        { verifiedOn: { sort: "asc", nulls: "first" } },
        { createdAt: "asc" }
      ],
      take: CONTACT_LIMIT
    })
  ]);
  const obligation = MOR_OBLIGATIONS[org.jurisdiction];
  const deadlines = open.flatMap((r) => {
    let due;
    try {
      ({ due } = reportingDeadline(org.jurisdiction, {
        occurredAt: r.occurredAt ?? r.createdAt,
        awareAt: r.awareAt ?? r.createdAt
      }));
    } catch {
      return [];
    }
    return [
      {
        /* `submittedAt` is deliberately NOT passed: it means "the duty
           was discharged", and every row reaching this line is one where
           it demonstrably was not. */
        status: deadlineStatus(due, now, { obligation }),
        /* NULL, NOT ZERO, where the instrument sets no window. Zero
           rendered as "soonest is today", which is a deadline invented
           for an obligation deliberately left open. */
        daysLeft: due === null ? null : Math.ceil((due.getTime() - now.getTime()) / 864e5)
      }
    ];
  });
  return digestFor({
    deadlines,
    currencies: training.map((t) => {
      const verdict = currencyOf({ completedOn: t.completedOn, expiresOn: t.expiresOn }, now);
      return { state: verdict.state, daysLeft: verdict.daysLeft };
    }),
    untriaged,
    overdueActions: overdue.map((a) => ({
      daysLeft: Math.ceil((a.dueOn.getTime() - now.getTime()) / 864e5)
    })),
    contacts: contacts.map((contact) => ({
      state: freshnessOf(contact, now),
      daysLeft: daysUntilStale(contact, now)
    }))
  });
}

// apps/api/src/mail.ts
function senderAddress(config2) {
  return config2.replyTo ?? config2.from.match(/<([^>]+)>/)?.[1] ?? "safety@usalamasms.com";
}
function unsubscribeLine(config2) {
  return `Unsubscribe from trial emails: mailto:${senderAddress(config2)}?subject=Unsubscribe%20trial%20emails`;
}
var PHRASE = Object.freeze({
  DEADLINE: (n) => n === 1 ? "1 reporting deadline needs attention" : `${n} reporting deadlines need attention`,
  CURRENCY: (n) => n === 1 ? "1 training currency is lapsing" : `${n} training currencies are lapsing`,
  UNTRIAGED: (n) => n === 1 ? "1 report is waiting to be triaged" : `${n} reports are waiting to be triaged`,
  ACTION_OVERDUE: (n) => n === 1 ? "1 corrective action is overdue" : `${n} corrective actions are overdue`,
  CONTACT: (n) => n === 1 ? "1 emergency contact needs verification" : `${n} emergency contacts need verification`
});
function subjectFor(digest) {
  const urgent = digest.urgency === "NOW" ? "Action needed today" : "Safety record update";
  const kinds = digest.items.length;
  return `UsalamaSMS \u2014 ${urgent} (${kinds} ${kinds === 1 ? "item" : "items"})`;
}
function when(item) {
  if (item.soonestDays === null) return "";
  if (item.soonestDays < 0) return ` \u2014 soonest overdue by ${Math.abs(item.soonestDays)} days`;
  if (item.soonestDays === 0) return " \u2014 soonest is today";
  if (item.soonestDays === 1) return " \u2014 soonest is tomorrow";
  return ` \u2014 soonest in ${item.soonestDays} days`;
}
function bodyFor(digest, baseUrl) {
  const lines = digest.items.map((item) => `- ${PHRASE[item.kind](item.count)}${when(item)}
  ${baseUrl}${item.href}`);
  return [
    "This is the daily summary from your safety management system.",
    "",
    ...lines,
    "",
    /* WORDED AROUND THE WORDS THE TEST FORBIDS, and that is the right
       way round. The assertion scans the WHOLE transmitted payload for
       "narrative", "reporter" and "anonymous" — a blunt check, and its
       bluntness is the point: it cannot be fooled by a field added
       later or by a clever interpolation. The first version of this
       footer said "safety narratives are never sent by email" and
       tripped it. Loosening the regex to allow the word in static copy
       would have traded a check that cannot be argued with for one that
       needs a maintainer to be careful. Changing four words of prose
       costs nothing and leaves the guard absolute. */
    "Counts only. Open the product to see what any of them are \u2014",
    "what a report says is never sent by email."
  ].join("\n");
}
async function sendDigest(digest, to, config2, fetchImpl = fetch) {
  if (!isWorthSending(digest)) return { status: "NOTHING_TO_SAY" };
  if (!config2.apiKey) return { status: "NOT_CONFIGURED" };
  try {
    const response = await fetchImpl("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: "Bearer " + config2.apiKey,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        from: config2.from,
        ...config2.replyTo ? { reply_to: config2.replyTo } : {},
        to,
        subject: subjectFor(digest),
        text: bodyFor(digest, config2.baseUrl)
      })
    });
    if (!response.ok) {
      return { status: "FAILED", reason: `provider responded ${response.status}` };
    }
    let id = "";
    try {
      const payload = await response.json();
      id = payload.id ?? "";
    } catch {
    }
    return { status: "SENT", id };
  } catch (error) {
    return {
      status: "FAILED",
      reason: error instanceof Error ? error.message : "transport failed"
    };
  }
}
function trialDigestSubject(digest) {
  switch (digest.stage) {
    case 1:
      return "Welcome to UsalamaSMS. Your 60-day trial starts today.";
    case 7:
      return "Week 1 check-in from UsalamaSMS";
    case 30:
      return "Halfway through your UsalamaSMS trial";
    case 45:
      return "15 days left in your UsalamaSMS trial";
    case 55:
      return "5 days left in your UsalamaSMS trial";
    case 60:
      return "Your UsalamaSMS trial ends today";
  }
}
function trialDigestBody(digest, config2) {
  const lines = digest.stage === 1 ? [
    "Welcome to UsalamaSMS. Your 60-day trial starts today. Here's your onboarding checklist.",
    "",
    "- [ ] File your first report",
    "- [ ] Complete the SMS maturity assessment",
    "- [ ] Add one hazard to the risk register",
    "- [ ] Create your first SPI",
    "- [ ] Invite your team (2+ members)",
    "",
    `Open the dashboard: ${config2.baseUrl}/today`
  ] : digest.stage === 7 ? [
    `Week 1 check-in. You have ${digest.daysRemaining} days remaining.`,
    `${digest.onboardingComplete} of 4 shared onboarding steps complete.`,
    "The fifth step is the maturity assessment, and it is kept on the device where it was filled in.",
    "",
    `Open the dashboard: ${config2.baseUrl}/today`
  ] : digest.stage === 30 ? [
    `Halfway through your trial. ${digest.reports} ${digest.reports === 1 ? "report" : "reports"} filed, ${digest.hazards} ${digest.hazards === 1 ? "hazard" : "hazards"} registered.`,
    "",
    `Open the dashboard: ${config2.baseUrl}/today`
  ] : digest.stage === 45 ? [
    "15 days left. Your data is yours forever, even if you do not subscribe. Export anytime.",
    "",
    `Open export: ${config2.baseUrl}/account`
  ] : digest.stage === 55 ? [
    `5 days left. Here's what you built: ${digest.reports} ${digest.reports === 1 ? "report" : "reports"}, ${digest.hazards} ${digest.hazards === 1 ? "hazard" : "hazards"}, ${digest.closedActions} ${digest.closedActions === 1 ? "closed action" : "closed actions"}. Ready to subscribe?`,
    "",
    `Open the dashboard: ${config2.baseUrl}/today`
  ] : [
    "Your trial ends today. Subscribe to keep full access, or continue with free reporting.",
    "",
    `Open the dashboard: ${config2.baseUrl}/today`
  ];
  return [
    ...lines,
    "",
    unsubscribeLine(config2)
  ].join("\n");
}
async function sendTrialDigest(digest, to, config2, fetchImpl = fetch) {
  if (!config2.apiKey) return { status: "NOT_CONFIGURED" };
  try {
    const response = await fetchImpl("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: "Bearer " + config2.apiKey,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        from: config2.from,
        ...config2.replyTo ? { reply_to: config2.replyTo } : {},
        to,
        subject: trialDigestSubject(digest),
        text: trialDigestBody(digest, config2)
      })
    });
    if (!response.ok) return { status: "FAILED", reason: `provider responded ${response.status}` };
    let id = "";
    try {
      const payload = await response.json();
      id = payload.id ?? "";
    } catch {
    }
    return { status: "SENT", id };
  } catch (error) {
    return {
      status: "FAILED",
      reason: error instanceof Error ? error.message : "transport failed"
    };
  }
}
function mailConfigFromEnv(env = process.env) {
  return {
    apiKey: env.RESEND_API_KEY || void 0,
    baseUrl: (env.PUBLIC_BASE_URL || "https://usalamasms.com").replace(/\/+$/, ""),
    from: "UsalamaSMS <safety@usalamasms.com>",
    /* Set MAIL_REPLY_TO to a mailbox somebody actually reads. Until it
       is set, no Reply-To is sent at all — which is honest: a reply
       fails visibly rather than disappearing into a void the sender
       believes is monitored. An empty string is not an address, so a
       variable created and never filled in stays absent. */
    replyTo: env.MAIL_REPLY_TO || void 0,
    platformNotice: env.PLATFORM_NOTICE_EMAIL || void 0
  };
}

// packages/shared/src/index.ts
import { z } from "zod";

// packages/shared/src/regulatory-source.ts
var REGULATORY_SOURCE_LABELS = Object.freeze({
  PRIMARY: "primary instrument read",
  REGIONAL_GUIDANCE: "regional guidance",
  PROVISIONAL: "primary instrument unread",
  OPERATOR_DECLARED: "operator declared"
});
var REGIONAL_FRAMEWORK_LABELS = Object.freeze({
  CASSOA: "CASSOA / East African Community harmonisation"
});

// packages/shared/src/taxonomy.ts
var OTHER = "__OTHER__";
var AERODROMES = [
  { code: "HKJK", label: "Nairobi / Jomo Kenyatta (HKJK)", country: "KE" },
  { code: "HKNW", label: "Nairobi / Wilson (HKNW)", country: "KE" },
  { code: "HKMO", label: "Mombasa / Moi (HKMO)", country: "KE" },
  { code: "HKKI", label: "Kisumu (HKKI)", country: "KE" },
  { code: "HKEL", label: "Eldoret (HKEL)", country: "KE" },
  { code: "HKML", label: "Malindi (HKML)", country: "KE" },
  { code: "HKLU", label: "Lamu (HKLU)", country: "KE" },
  { code: "HKLO", label: "Lodwar (HKLO)", country: "KE" },
  { code: "HKUK", label: "Ukunda / Diani (HKUK)", country: "KE" },
  { code: "HKNI", label: "Nyeri (HKNI)", country: "KE" },
  /* THE NORTHERN NETWORK.
       Added after reading a real operator's Safety Risk Analysis for
       Wajir — the document names "Wajir International Airport (ICAO:
       HKWJ)" and this list did not contain it. An operator whose own SRA
       concerns an aerodrome the taxonomy cannot express is an operator
       whose reports all land in the free-text escape hatch, which is
       precisely the GROUP BY problem the dropdowns exist to prevent.
  
       HKWJ is evidenced by that document. The rest are the northern and
       northeastern fields the same network serves; verify each against
       the current AIP before a customer's compliance depends on it. */
  { code: "HKWJ", label: "Wajir (HKWJ)", country: "KE" },
  { code: "HKGA", label: "Garissa (HKGA)", country: "KE" },
  { code: "HKMA", label: "Mandera (HKMA)", country: "KE" },
  { code: "HKMB", label: "Marsabit (HKMB)", country: "KE" },
  { code: "HKLK", label: "Lokichogio (HKLK)", country: "KE" },
  { code: "HKKT", label: "Kitale (HKKT)", country: "KE" },
  { code: "HKNY", label: "Nanyuki (HKNY)", country: "KE" },
  { code: "HKAM", label: "Amboseli (HKAM)", country: "KE" },
  /* ==================================================================
       THE EAST AFRICAN COMMUNITY, AND SOMALIA.
  
       The note above this list argued that a Kenyan operator filing about
       a sector into Entebbe should type it, because a dropdown entry
       implies the product knows Uganda's obligations. That reasoning was
       sound about ONE thing and wrong about the field it was applied to.
  
       WHERE AN OCCURRENCE HAPPENED AND WHOSE RULES GOVERN IT ARE TWO
       SEPARATE QUESTIONS, and this form already asks them separately —
       `location` here, and "Which authority does this operation answer
       to?" from JURISDICTION_OPTIONS. An aerodrome in this list makes no
       claim about deadlines; the jurisdiction field does, and it still
       covers what regulations.ts can actually compute. So the coupling
       the old note feared does not exist in the markup.
  
       What the old arrangement DID cost is the thing dropdowns exist for.
       Every EAC sector landed in the free-text escape hatch, so an
       operator flying Nairobi–Entebbe–Kigali could not count events by
       place, and neither the risk picture nor an indicator keyed to an
       aerodrome could see them. Untaggable is uncountable — the same
       defect the ground-operations categories had.
  
       Somalia is included because it acceded to the EAC, and because the
       Kenyan charter and survey operators this product is built for fly
       there constantly.
  
       EVERY CODE BELOW WAS VERIFIED, not recalled, and the check earned
       its keep: Juba is HJJJ and recall said HSSJ; Bosaso is HCMF and
       recall said HCMV. Two wrong ICAO codes in an aviation product is
       precisely the class of error this repository refuses to ship.
       Verify against the current AIP before a customer's compliance
       depends on any of them.
       ================================================================== */
  { code: "HUEN", label: "Entebbe (HUEN)", country: "UG" },
  { code: "HTDA", label: "Dar es Salaam / Julius Nyerere (HTDA)", country: "TZ" },
  { code: "HTKJ", label: "Kilimanjaro (HTKJ)", country: "TZ" },
  { code: "HTZA", label: "Zanzibar / Abeid Amani Karume (HTZA)", country: "TZ" },
  { code: "HTMW", label: "Mwanza (HTMW)", country: "TZ" },
  { code: "HTAR", label: "Arusha (HTAR)", country: "TZ" },
  { code: "HRYR", label: "Kigali (HRYR)", country: "RW" },
  { code: "HBBA", label: "Bujumbura (HBBA)", country: "BI" },
  { code: "HJJJ", label: "Juba (HJJJ)", country: "SS" },
  { code: "FZAA", label: "Kinshasa / N'Djili (FZAA)", country: "CD" },
  { code: "FZNA", label: "Goma (FZNA)", country: "CD" },
  { code: "FZQA", label: "Lubumbashi (FZQA)", country: "CD" },
  { code: "HCMM", label: "Mogadishu / Aden Adde (HCMM)", country: "SO" },
  { code: "HCMH", label: "Hargeisa / Egal (HCMH)", country: "SO" },
  { code: "HCMI", label: "Berbera (HCMI)", country: "SO" },
  { code: "HCMK", label: "Kismayo (HCMK)", country: "SO" },
  { code: "HCMF", label: "Bosaso (HCMF)", country: "SO" }
];
var AIRCRAFT_TYPES = [
  { code: "DH8D", label: "DHC-8-400 (Dash 8 Q400)", category: "Turboprop" },
  { code: "DH8C", label: "DHC-8-300", category: "Turboprop" },
  { code: "AT76", label: "ATR 72-600", category: "Turboprop" },
  { code: "AT75", label: "ATR 72-500", category: "Turboprop" },
  { code: "AT46", label: "ATR 42-600", category: "Turboprop" },
  { code: "C208", label: "Cessna 208 Caravan", category: "Turboprop" },
  { code: "C20B", label: "Cessna 208B Grand Caravan", category: "Turboprop" },
  { code: "BE20", label: "Beechcraft King Air 200", category: "Turboprop" },
  { code: "DHC6", label: "DHC-6 Twin Otter", category: "Turboprop" },
  { code: "L410", label: "LET L-410", category: "Turboprop" },
  { code: "F406", label: "Reims F406 Caravan II", category: "Turboprop" },
  /* The Fokker 50 was missing while the Fokker 70 was here, which made
     the list unable to describe the commonest mid-tier East African
     fleet shape: 50s on the regional turboprop routes and 70s on the
     jet ones, from one operator. A type list that cannot name half a
     customer's fleet sends that half to the free-text escape, and free
     text is the half nobody can count. */
  { code: "F50", label: "Fokker 50", category: "Turboprop" },
  /* THE 737 CLASSICS, and their absence was the same shape as the
     Fokker 50's. The list carried the NG and the MAX — the fleet a
     well-capitalised flag carrier buys — and neither of the two
     variants an East African operator is most likely to be flying. The
     -300 and -400 are the backbone of regional freight and charter
     across the continent: cheap to acquire, still certified, and
     over-represented in exactly the operations this product exists for.
     An operator whose whole jet fleet fell into the free-text escape
     hatch is an operator whose jet occurrences cannot be grouped. */
  { code: "B733", label: "Boeing 737-300", category: "Jet" },
  { code: "B734", label: "Boeing 737-400", category: "Jet" },
  { code: "B738", label: "Boeing 737-800", category: "Jet" },
  { code: "B38M", label: "Boeing 737 MAX 8", category: "Jet" },
  { code: "B788", label: "Boeing 787-8", category: "Jet" },
  { code: "E190", label: "Embraer E190", category: "Jet" },
  { code: "CRJ9", label: "Bombardier CRJ900", category: "Jet" },
  /* Same source as HKWJ above: the SRA is written for an F70 fleet and
     this list could not name the aircraft it is about. */
  { code: "F70", label: "Fokker 70", category: "Jet" },
  { code: "F100", label: "Fokker 100", category: "Jet" },
  { code: "A320", label: "Airbus A320", category: "Jet" },
  { code: "C172", label: "Cessna 172", category: "Piston" },
  { code: "C206", label: "Cessna 206", category: "Piston" },
  { code: "BE58", label: "Beechcraft Baron 58", category: "Piston" },
  { code: "R44", label: "Robinson R44", category: "Rotorcraft" },
  { code: "AS50", label: "Airbus AS350", category: "Rotorcraft" },
  { code: "B06", label: "Bell 206", category: "Rotorcraft" }
];
var HRC_CATEGORIES = [
  { code: "CFIT", label: "Controlled flight into terrain", group: "In flight", nasp: true },
  { code: "LOC-I", label: "Loss of control in flight", group: "In flight", nasp: true },
  { code: "MAC", label: "Loss of separation or near mid-air", group: "In flight", nasp: true },
  { code: "BWI", label: "Bird or wildlife strike", group: "In flight", nasp: true, cictt: "BIRD" },
  { code: "TURB", label: "Turbulence encounter", group: "In flight", nasp: false },
  { code: "RE", label: "Runway excursion", group: "Runway", nasp: true },
  { code: "RI", label: "Runway incursion", group: "Runway", nasp: true },
  { code: "ARC", label: "Heavy, long or abnormal landing", group: "Runway", nasp: false },
  { code: "RAMP", label: "Ground handling \u2014 loading, servicing, marshalling", group: "On the ground", nasp: false },
  { code: "GCOL", label: "Ground collision", group: "On the ground", nasp: false },
  { code: "LOC-G", label: "Loss of control while taxiing", group: "On the ground", nasp: false },
  { code: "GTOW", label: "Towing or pushback", group: "On the ground", nasp: false },
  { code: "SCF-PP", label: "Engine or propeller failure", group: "Technical", nasp: false },
  { code: "SCF-NP", label: "Other system or component failure", group: "Technical", nasp: false },
  { code: "FUEL", label: "Fuel \u2014 quantity, contamination or starvation", group: "Technical", nasp: false }
];
var NASP_HIGH_RISK = HRC_CATEGORIES.filter((c) => c.nasp);
var AERODROME_CODES = new Set(AERODROMES.map((a) => a.code));
var AIRCRAFT_CODES = new Set(AIRCRAFT_TYPES.map((a) => a.code));
function isKnownOrFreeText(value, known) {
  if (value === OTHER) return false;
  if (known.has(value)) return true;
  if (/^[A-Z0-9]{3,4}$/.test(value)) return false;
  return value.length > 0 && value.length <= 120;
}
function isValidLocation(value) {
  return isKnownOrFreeText(value, AERODROME_CODES);
}
function isValidAircraftType(value) {
  return isKnownOrFreeText(value, AIRCRAFT_CODES);
}

// packages/shared/src/glossary.ts
var SMS_ACRONYMS = Object.freeze({
  AAID: "Aircraft Accident Investigation Department",
  ADREP: "Accident/incident data reporting",
  AIA: "Accident investigation authority",
  ALARP: "As low as reasonably practicable",
  ALOSP: "Acceptable level of safety performance",
  AMO: "Approved maintenance organisation",
  ANS: "Air navigation services",
  AOC: "Air operator certificate",
  ATO: "Approved training organisation",
  ATS: "Air traffic service(s)",
  CAA: "Civil aviation authority",
  CAST: "Commercial Aviation Safety Team",
  CICTT: "CAST/ICAO Common Taxonomy Team",
  CVR: "Cockpit voice recorder",
  D3M: "Data-driven decision-making",
  ERP: "Emergency response plan",
  FDA: "Flight data analysis",
  FDR: "Flight data recorder",
  FRMS: "Fatigue risk management system",
  GASP: "Global aviation safety plan",
  ICAO: "International Civil Aviation Organization",
  ISTARS: "Integrated safety trend analysis and reporting system",
  KCAA: "Kenya Civil Aviation Authority",
  LOSA: "Line operations safety audit",
  MOT: "Ministry of Transport",
  OHSMS: "Occupational health and safety management system",
  OSHE: "Occupational safety, health and environment",
  PIRG: "Planning and implementation regional group",
  QMS: "Quality management system",
  RASG: "Regional aviation safety group",
  RSOO: "Regional safety oversight organization",
  SAG: "Safety action group",
  SARPS: "Standards and Recommended Practices",
  SDCPS: "Safety data collection and processing system",
  SEMS: "Security management system",
  SMM: "Safety management manual",
  SMP: "Safety Management Panel",
  SMS: "Safety management system",
  SPI: "Safety performance indicator",
  SPT: "Safety performance target",
  SRB: "Safety review board",
  SRC: "Safety review committee",
  SRBS: "Safety risk-based surveillance",
  SRM: "Safety risk management",
  SSO: "State safety oversight",
  SSP: "State safety programme",
  TNA: "Training needs analysis",
  USOAP: "Universal Safety Oversight Audit Programme"
});
var OCCURRENCE_CLASSES = Object.freeze([
  {
    key: "ACCIDENT",
    label: "Accident",
    test: "Someone was killed or seriously injured, the aircraft was damaged in a way that affects its strength or performance and needs major repair, or the aircraft is missing or completely inaccessible.",
    reportable: true,
    note: "Damage limited to one engine, propellers, wing tips, antennas, tyres, brakes, wheels, fairings, panels, landing gear doors, windscreens or small dents in the skin does NOT make it an accident on its own."
  },
  {
    key: "SERIOUS_INCIDENT",
    label: "Serious incident",
    test: "Nobody was hurt and the aircraft was not damaged like that, but the circumstances say an accident very nearly happened.",
    reportable: true,
    // The glossary's own sentence. It is the clearest thing in the
    // document and it is what most reporters get wrong.
    note: "The difference between an accident and a serious incident lies only in the result."
  },
  {
    key: "INCIDENT",
    label: "Incident",
    test: "Something happened in the operation of an aircraft that affected safety, or could have.",
    reportable: false,
    note: "Not reportable to the regulator as an occurrence in every case, and still worth filing: the incidents are where the accidents are visible first."
  }
]);
var SERIOUS_INJURY_TESTS = Object.freeze([
  "hospital for more than 48 hours, starting within seven days of the injury",
  "a broken bone \u2014 except a simple break of a finger, toe or the nose",
  "cuts causing severe bleeding, or nerve, muscle or tendon damage"
]);
var DEFINITIONS = Object.freeze({
  Hazard: "A condition or an object with the potential to cause or contribute to an aircraft incident or accident.",
  "Safety risk": "The predicted probability and severity of the consequences or outcomes of a hazard.",
  Defences: "Specific mitigating actions, preventive controls or recovery measures put in place to prevent the realization of a hazard or its escalation into an undesirable consequence.",
  "Safety data": "A defined set of facts or set of safety values collected from various aviation-related sources, which is used to maintain or improve safety.",
  "Safety information": "Safety data processed, organized or analysed in a given context so as to make it useful for safety management purposes.",
  "Safety performance indicator": "A data-based parameter used for monitoring and assessing safety performance.",
  "Safety performance target": "The State or service provider's planned or intended target for a safety performance indicator over a given period that aligns with the safety objectives.",
  Trigger: "An established level or criteria value for a particular safety performance indicator that serves to initiate an action required.",
  "Accountable executive": "A single, identifiable person having responsibility for the effective and efficient performance of the service provider's SMS.",
  "Change management": "A formal process to manage changes within an organization in a systematic manner, so that changes which may impact identified hazards and risk mitigation strategies are accounted for before the implementation of such changes."
});
var GLOSSARY_SOURCE = Object.freeze({
  instrument: "KCAA SMS course glossary (ICAO Annex 19 / Doc 9859 definitions)",
  transcribedOn: "2026-08-11",
  /** Definitions move with Annex amendments; Amendment 2 applies 26 Nov 2026. */
  reviewCycleMonths: 24
});

// packages/shared/src/risk.ts
var SEVERITY_VALUE = {
  A_CATASTROPHIC: 5,
  B_HAZARDOUS: 4,
  C_MAJOR: 3,
  D_MINOR: 2,
  E_NEGLIGIBLE: 1
};
var LIKELIHOOD_VALUE = {
  FREQUENT: 5,
  OCCASIONAL: 4,
  REMOTE: 3,
  IMPROBABLE: 2,
  EXTREMELY_IMPROBABLE: 1
};
function valueOf(sev, lik) {
  const s = SEVERITY_VALUE[sev];
  const l = LIKELIHOOD_VALUE[lik];
  if (s === void 0 || l === void 0) {
    throw new RangeError(
      `not on the Doc 9859 scale: severity ${JSON.stringify(sev)}, likelihood ${JSON.stringify(lik)}`
    );
  }
  return { s, l };
}
var RED = /* @__PURE__ */ new Set(["5x5", "5x4", "5x3", "4x5", "4x4", "3x5"]);
var AMBER = /* @__PURE__ */ new Set(["5x2", "5x1", "4x3", "4x2", "3x4", "3x3", "2x5", "2x4", "1x5"]);
function tolerability(sev, lik) {
  const { s, l } = valueOf(sev, lik);
  const key = `${s}x${l}`;
  if (RED.has(key)) return "INTOLERABLE";
  if (AMBER.has(key)) return "TOLERABLE";
  return "ACCEPTABLE";
}

// packages/shared/src/permissions.ts
var PERMISSIONS = {
  FRONTLINE: /* @__PURE__ */ new Set([
    "report.create",
    "report.read.own",
    "document.read",
    "training.read.own"
  ]),
  SAFETY_OFFICER: /* @__PURE__ */ new Set([
    "report.create",
    "report.read.own",
    "report.read.org",
    "report.triage",
    "hazard.manage",
    "risk.assess",
    "spi.read",
    "document.read",
    "training.read.own"
  ]),
  SAFETY_MANAGER: /* @__PURE__ */ new Set([
    "report.create",
    "report.read.own",
    "report.read.org",
    "report.triage",
    "report.investigate",
    "report.close",
    "report.deidentify.review",
    "hazard.manage",
    "risk.assess",
    "risk.accept.tolerable",
    "spi.configure",
    "spi.read",
    "moc.create",
    "document.read",
    "document.manage",
    "training.read.own",
    "training.manage",
    "audit.read",
    // The post that actually runs the SMS: it drafts the policy, keeps
    // the accountability matrix, exercises the plan, conducts the
    // internal audit and publishes the bulletins. It does NOT sign the
    // policy and does NOT verify its own findings.
    "policy.draft",
    "accountability.manage",
    "appointment.manage",
    "erp.manage",
    "sms.audit.conduct",
    "communication.publish",
    // The post that would be asked for the record in an audit is the
    // post that can take a copy of it.
    "org.export",
    // And the post that maintains the manual maintains the words in it.
    "config.manage"
  ]),
  INVESTIGATOR: /* @__PURE__ */ new Set([
    "report.read.org",
    "report.investigate",
    "hazard.manage",
    "risk.assess",
    "spi.read",
    "document.read",
    "training.read.own"
  ]),
  KEY_MANAGEMENT: /* @__PURE__ */ new Set([
    "report.read.org",
    "risk.accept.tolerable",
    "spi.read",
    "moc.create",
    "moc.approve",
    "document.read",
    "training.read.own",
    "audit.read",
    /* VERIFICATION, not conduct. Whoever ran the audit saying their own
       corrective action worked is the weakest evidence in an assurance
       programme, so closing a finding and verifying it are held by
       different posts by construction rather than by convention. */
    "sms.audit.verify"
  ]),
  ACCOUNTABLE_EXECUTIVE: /* @__PURE__ */ new Set([
    /* `risk.accept.tolerable` and NOT an intolerable counterpart — see
       the note in the union above. The amber band is this post's to
       carry precisely because accepting it is a judgement about cost
       against safety; the red band is nobody's, at any level. */
    "report.read.org",
    "risk.accept.tolerable",
    /* FILING, AND ITS ABSENCE WAS NEVER A DECISION.
           ==========================================================
           This role could not file a report. No test asserted that it
           should not — which in this repository is the signature of an
           unexamined default rather than a judgement — and it was found by
           walking the sequence a design partner walks, not by reading the
           matrix.
    
           IT MADE THE PRODUCT'S OWN GATE UNREACHABLE. Signup creates
           exactly one account and it is this one, so a new operator's first
           and only user filed a report, watched the sync answer `forbidden`
           per item, and read "your role cannot submit this report type" on
           a device with nowhere else to go. docs/02-STRATEGY.md sets
           Phase 1's gate as "a frontline user files a report offline and it
           arrives"; nobody could reach it without first appointing a second
           person. /today's first-run sequence then made it worse by opening
           with "File the first report".
    
           AND IT IS WRONG ON THE INSTRUMENT, which is the reason rather
           than the convenience. Annex 19's reporting system is for ALL
           personnel. The accountable executive is personnel, is the post
           ACCOUNTABLE for the safety management system, and was the one
           person in the organisation structurally unable to perform its
           most basic act.
    
           SYSTEM_ADMIN and PLATFORM_ADMIN still cannot file, and that stays
           deliberate: the administrator is a technical post held away from
           the safety record on purpose — the escalation rule in
           routes.auth.ts rests on exactly that — and the platform
           administrator is the vendor, who must never write into a tenant's
           safety record. */
    "report.create",
    "spi.read",
    "moc.approve",
    "document.read",
    "audit.read",
    "training.read.own",
    "config.manage",
    /* APPOINTING THE PEOPLE, because signup creates exactly one of these
       and nothing else could create a second user at all. Every operator
       that ever signed up had one account, in an organisation containing
       nobody able to add a safety officer — so the reporting system had
       no reporters. Under Annex 19 this post is the one answerable for
       the SMS; deciding who staffs it is squarely its function. */
    "user.manage",
    /* SIGNING THE POLICY IS THIS ROLE'S ALONE, and it is the only
       permission in this file held by exactly one role. Element 1.1 is
       not "there is a policy" — it is that the person who can move money
       and schedule has put their name to it. A safety manager signing on
       their behalf is the finding, not the evidence. */
    "policy.sign",
    // And appointing the key personnel, which is the same authority.
    "appointment.manage",
    /* And holding the operator's own copy. Data ownership that depends
       on the safety manager still being employed is not ownership. */
    "org.export"
  ]),
  REGULATOR_INSPECTOR: /* @__PURE__ */ new Set([
    "regulator.oversight",
    "audit.read",
    "spi.read",
    "document.read"
  ]),
  /* THE SHORTEST SET IN THIS MATRIX, ON PURPOSE.
  
       A vendor account that could read one narrative could read every
       narrative in every tenant, which is a worse position than any
       single operator can put itself in. So it holds the two powers it
       needs to run a business and nothing else: no report permission, no
       hazard, no audit, no export, not even `org.manage` — creating an
       operator is `platform.operator.provision` and administering one
       afterwards belongs to that operator.
  
       tests/platform.test.ts asserts this set is disjoint from
       NARRATIVE_PERMISSIONS, and that it holds no permission any other
       role uses to reach a safety record. */
  PLATFORM_ADMIN: /* @__PURE__ */ new Set([
    "platform.operator.provision",
    "platform.entitlement.manage"
  ]),
  SYSTEM_ADMIN: /* @__PURE__ */ new Set([
    "org.manage",
    "user.manage",
    "audit.read",
    // Account administration extends to who holds which post; it stops
    // short of authoring or signing any of the safety documentation.
    "appointment.manage"
  ])
};
function can(role, p) {
  return PERMISSIONS[role].has(p);
}

// packages/shared/src/index.ts
var RoleEnum = z.enum([
  "FRONTLINE",
  "SAFETY_OFFICER",
  "SAFETY_MANAGER",
  "INVESTIGATOR",
  "KEY_MANAGEMENT",
  "ACCOUNTABLE_EXECUTIVE",
  "REGULATOR_INSPECTOR",
  "SYSTEM_ADMIN",
  /* The vendor, not the operator — see permissions.ts. It is in this
     enum because it is a value the Role column holds, and NOT in any
     screen's role picker: an operator cannot create one, because a
     tenant that could mint a platform administrator would be a tenant
     that could read the others. */
  "PLATFORM_ADMIN"
]);
var ReportTypeEnum = z.enum(["MOR", "VCR", "HAZARD", "SUGGESTION", "NEAR_MISS", "FATIGUE"]);
var HrcEnum = z.enum(["RE", "RI", "LOC_I", "CFIT", "MAC", "BWI"]);
var FlightPhaseEnum = z.enum([
  "STANDING",
  "PUSHBACK",
  "TAXI",
  "TAKEOFF",
  "INITIAL_CLIMB",
  "CLIMB",
  "CRUISE",
  "DESCENT",
  "APPROACH",
  "LANDING",
  "LANDING_ROLL",
  "GO_AROUND",
  "GROUND_HANDLING",
  "MAINTENANCE"
]);
var SeverityEnum = z.enum([
  "A_CATASTROPHIC",
  "B_HAZARDOUS",
  "C_MAJOR",
  "D_MINOR",
  "E_NEGLIGIBLE"
]);
var LikelihoodEnum = z.enum([
  "FREQUENT",
  "OCCASIONAL",
  "REMOTE",
  "IMPROBABLE",
  "EXTREMELY_IMPROBABLE"
]);
var TolerabilityEnum = z.enum(["INTOLERABLE", "TOLERABLE", "ACCEPTABLE"]);
var CreateReportSchema = z.object({
  clientId: z.string().uuid(),
  // offline idempotency key
  type: ReportTypeEnum,
  title: z.string().min(3).max(200),
  narrative: z.string().min(10).max(2e4),
  occurredAt: z.coerce.date().optional(),
  /**
   * When the reporter became aware. Optional on the wire — the server
   * defaults it to receipt time, which is the earliest moment it can
   * prove — but NEVER defaulted to occurredAt. See regulations.ts.
   */
  awareAt: z.coerce.date().optional(),
  jurisdiction: z.enum(JURISDICTIONS).default("KE"),
  // Validated against the taxonomy, not merely length-checked. The
  // dropdown constrains the form; this constrains the REQUEST, which is
  // what a future integration or a replayed payload actually sends.
  location: z.string().max(120).refine(isValidLocation, {
    message: "location must be an aerodrome code from the taxonomy, or a description"
  }).optional(),
  aircraftType: z.string().max(120).refine(isValidAircraftType, {
    message: "aircraftType must be a type code from the taxonomy, or a description"
  }).optional(),
  phase: FlightPhaseEnum.optional(),
  hrcTags: z.array(HrcEnum).max(6).default([]),
  /**
   * WHAT THE REPORTER THINKS SHOULD BE DONE.
   *
   * Taken from the operator hazard report form the design partner uses:
   * "Reporter's Recommendations" is a first-class section there, above
   * the safety office's own analysis, and this product did not have it.
   *
   * It is the cheapest safety intelligence in the system. The person who
   * saw the hazard is usually the person who knows the fix, and asking
   * costs one optional field. Leaving it out means the fix arrives, if
   * at all, from someone who was not there.
   *
   * Optional and always will be: making it required would put a second
   * writing task between a ramp agent and filing, which is how report
   * volume dies.
   */
  reporterRecommendation: z.string().max(2e3).optional(),
  /**
   * WHAT A FATIGUE REPORT CARRIES THAT NO OTHER REPORT DOES.
   *
   * NESTED RATHER THAN FLAT, unlike location and aircraftType above,
   * and the nesting is the point: every one of these is meaningless
   * unless the type is FATIGUE, and an optional object says that in the
   * shape rather than in a comment. The refinement below then makes it
   * impossible to attach a duty to a bird strike.
   *
   * EVERY FIELD IS OPTIONAL INSIDE IT. A crew member who cannot
   * remember their rest to the half hour must still be able to file —
   * a form that refuses an incomplete fatigue report converts a report
   * into silence, which is the one outcome this product cannot afford.
   * fatigue.ts reports the shortfall as INCOMPLETE rather than guessing.
   */
  fatigue: z.object({
    flightTimeHours: z.number().min(0).max(24).optional(),
    dutyHours: z.number().min(0).max(48).optional(),
    restBeforeHours: z.number().min(0).max(168).optional(),
    sectors: z.number().int().min(0).max(40).optional(),
    sleepPrior24Hours: z.number().min(0).max(24).optional(),
    /* LOCAL hours, 0..23. The window of circadian low belongs to the
       reporter's body clock, so a UTC timestamp would need an
       acclimatisation model this product does not have. */
    startLocalHour: z.number().int().min(0).max(23).optional(),
    endLocalHour: z.number().int().min(0).max(23).optional(),
    /* Samn-Perelli. Bounded to the scale so a client cannot invent an
       eighth level that every threshold comparison then mis-reads. */
    samnPerelli: z.number().int().min(1).max(7).optional()
  }).optional(),
  isAnonymous: z.boolean().default(false)
}).refine(
  (r) => r.type !== "MOR" || r.occurredAt !== void 0,
  { message: "MOR requires occurredAt to compute the regulatory deadline", path: ["occurredAt"] }
).refine(
  (r) => !r.awareAt || !r.occurredAt || r.awareAt.getTime() >= r.occurredAt.getTime(),
  { message: "awareAt cannot precede occurredAt", path: ["awareAt"] }
).refine(
  /* A DUTY CANNOT BE ATTACHED TO A BIRD STRIKE. The fatigue block is
     read by the fatigue picture and by nothing else, so a block riding
     on a HAZARD would be data that no screen displays and no query
     counts — invisible rather than wrong, which is worse. Rejected at
     the door with a message naming the field, rather than silently
     dropped on the way to the database. */
  (r) => !r.fatigue || r.type === "FATIGUE",
  { message: "duty details belong to a FATIGUE report", path: ["fatigue"] }
);
var RiskAssessInputSchema = z.object({
  // uuid, not cuid. The old schema mixed both, so an id that satisfied
  // one endpoint was rejected by the next for no reason a caller could see.
  hazardId: z.string().uuid(),
  consequence: z.string().min(5).max(1e3),
  severity: SeverityEnum,
  likelihood: LikelihoodEnum,
  alarpJustification: z.string().max(4e3).optional()
}).refine(
  // ALARP is the whole point of the amber band: a tolerable risk is
  // tolerable only if it has been driven as low as reasonably
  // practicable, and the justification is the evidence of that. An
  // unjustified TOLERABLE is an unaccepted risk wearing a green badge.
  (r) => tolerability(r.severity, r.likelihood) !== "TOLERABLE" || !!r.alarpJustification,
  { message: "A TOLERABLE (ALARP) risk requires an alarpJustification", path: ["alarpJustification"] }
);
var LoginSchema = z.object({
  email: z.string().trim().toLowerCase().email(),
  password: z.string().min(12),
  mfaCode: z.string().length(6).optional()
});
var SyncItemSchema = z.object({
  clientId: z.string().uuid(),
  entityType: z.enum(["safetyReport", "hazard", "riskAssessment"]),
  op: z.enum(["CREATE", "UPDATE", "DELETE"]),
  payload: z.unknown(),
  clientUpdatedAt: z.coerce.date(),
  baseVersion: z.string().optional()
  // server updatedAt seen when the client last read
});
var SyncBatchSchema = z.object({
  deviceId: z.string().min(8).max(64),
  items: z.array(SyncItemSchema).max(100)
});

// packages/shared/src/pricing.ts
var BANDS = Object.freeze([
  Object.freeze({
    id: "starter",
    name: "Starter",
    fleet: "1 or 2, RPAS or a single heliport",
    usdMonthly: 39,
    who: "A drone operator, a heliport, or a maintenance organisation serving one \u2014 captured by Annex 19 Amendment 2 and building an SMS from nothing.",
    adds: "Every Annex 19 element, same as every other band. What is smaller is the operation, not the obligation."
  }),
  Object.freeze({
    id: "single",
    name: "Single aircraft",
    fleet: "1 aircraft",
    usdMonthly: 79,
    who: "An owner-operator, a flight school with one type, a survey outfit."
  }),
  Object.freeze({
    id: "small",
    name: "Small operator",
    fleet: "2 to 9 aircraft",
    usdMonthly: 239,
    who: "The charter, medevac and survey operators this product was built for."
  }),
  Object.freeze({
    id: "fleet",
    name: "Fleet",
    fleet: "10 or more aircraft",
    usdMonthly: 549,
    who: "A scheduled operator, or a group holding several AOCs.",
    adds: "The export in a scheduled batch, and a second AOC priced rather than assumed.",
    perExtraAocUsdMonthly: 149
  })
]);
var EVERY_BAND_INCLUDES = Object.freeze([
  "Unlimited people filing reports \u2014 always, on every band.",
  "Unlimited reports, hazards, risk assessments and corrective actions.",
  "Offline filing on any handset, with the report held until there is signal.",
  "The operator's own copy of its whole record, exportable at any time.",
  "Every Annex 19 element the product covers, with no element behind a tier."
]);
var TRIAL_DAYS = 60;
var COMMITMENTS = Object.freeze([
  `${TRIAL_DAYS} days to try it, with no card and no limit on what you file \u2014 and extended on request if you are part way round your first hazard. Taking one all the way round the loop is the only way to judge an SMS, and we would rather give you the time than have you decide on half of it.`,
  "Your people file for free, always. There is no seat to buy, so there is no version of this where leaving the line crew out saves you money.",
  "If a subscription ever lapses, your people can still file and you can still export your entire record. The safety office tools pause; the reporting never does.",
  "The record is yours on the way out as well as the way in \u2014 every report, hazard, assessment and action, exportable at any time, in a format you can read without us.",
  "Every Annex 19 element this product covers is on every band. Nothing regulatory sits behind a higher tier."
]);
var PRICING_STILL_OPEN = Object.freeze([
  "The collection rail, and therefore the shilling price. Nothing on the site takes money yet; an operator starts a trial and is invoiced when the rail exists."
]);

// packages/shared/src/subscription.ts
var GRACE_DAYS = 14;
var DAY_MS2 = 864e5;
function trialEndsFrom(startedOn) {
  return new Date(startedOn.getTime() + TRIAL_DAYS * DAY_MS2);
}
function stateOn(dates, asOf) {
  const now = asOf.getTime();
  const paid = dates.paidThrough?.getTime() ?? null;
  if (paid !== null) {
    if (now <= paid) return "ACTIVE";
    return now <= paid + GRACE_DAYS * DAY_MS2 ? "GRACE" : "LAPSED";
  }
  return now <= dates.trialEndsOn.getTime() ? "TRIAL" : "LAPSED";
}
var ALL_CAPABILITIES = Object.freeze([
  /** A reporter filing. */
  "FILE_REPORT",
  /** An operator reading or exporting its own record. */
  "READ_OWN_RECORD",
  "EXPORT_OWN_RECORD",
  /** The safety office's working surfaces. This is the product. */
  "TRIAGE",
  "EDIT_REGISTER",
  "RECORD_INDICATOR_PERIOD",
  "GENERATE_DOCUMENT"
]);
var SURVIVES_LAPSE = Object.freeze({
  FILE_REPORT: true,
  READ_OWN_RECORD: true,
  EXPORT_OWN_RECORD: true,
  TRIAGE: false,
  EDIT_REGISTER: false,
  RECORD_INDICATOR_PERIOD: false,
  GENERATE_DOCUMENT: false
});

// netlify/functions/digest.mts
var client = null;
function connect() {
  if (client) return client;
  let managed;
  try {
    managed = getConnectionString();
  } catch (error) {
    if (!(error instanceof MissingDatabaseConnectionError)) throw error;
  }
  const url = managed ?? process.env["DATABASE_URL"] ?? process.env["SUPABASE_DATABASE_URL"];
  if (!url) throw new Error("no Netlify Database or DATABASE_URL connection");
  client = new PrismaClient({ adapter: new PrismaPg({ connectionString: url }) });
  return client;
}
var ORG_LIMIT = 200;
var RECIPIENT_LIMIT = 20;
var DAY2 = 864e5;
function utcDay(d) {
  return Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate());
}
function trialDayFor(startedOn, now) {
  return Math.floor((utcDay(now) - utcDay(startedOn)) / DAY2) + 1;
}
function trialStageFor(day) {
  switch (day) {
    case 1:
    case 7:
    case 30:
    case 45:
    case 55:
    case 60:
      return day;
    default:
      return null;
  }
}
async function handler() {
  const now = /* @__PURE__ */ new Date();
  const config2 = mailConfigFromEnv();
  if (!config2.apiKey) {
    return Response.json({
      ran: now.toISOString(),
      status: "NOT_CONFIGURED",
      detail: "No RESEND_API_KEY. Digests were computed for nobody and sent to nobody."
    });
  }
  let prisma;
  try {
    prisma = connect();
  } catch (error) {
    return Response.json({
      ran: now.toISOString(),
      status: "FAILED",
      detail: error instanceof Error ? error.message : "no database connection"
    });
  }
  const orgs = await prisma.org.findMany({
    select: { id: true, createdAt: true, trialEndsOn: true, paidThrough: true },
    take: ORG_LIMIT
  });
  let sent = 0;
  let trialSent = 0;
  let silent = 0;
  const failures = [];
  for (const org of orgs) {
    try {
      const people = await prisma.user.findMany({
        where: { orgId: org.id, active: true },
        select: { email: true, role: true },
        take: RECIPIENT_LIMIT
      });
      const recipients = people.filter((p) => can(p.role, "report.read.org")).map((p) => p.email);
      if (recipients.length === 0) {
        silent += 1;
        continue;
      }
      const digest = await computeDigest(prisma, org.id, now);
      let saidSomething = false;
      if (digest && isWorthSending(digest)) {
        saidSomething = true;
        for (const to of recipients) {
          const outcome = await sendDigest(digest, to, config2);
          if (outcome.status === "SENT") sent += 1;
          else if (outcome.status === "FAILED") {
            failures.push({ orgId: org.id, reason: outcome.reason });
          }
        }
      }
      const dates = {
        trialEndsOn: org.trialEndsOn ?? trialEndsFrom(org.createdAt),
        paidThrough: org.paidThrough
      };
      const trialState = stateOn(dates, now);
      const trialDay = trialDayFor(org.createdAt, now);
      const stage = trialState === "TRIAL" ? trialStageFor(trialDay) : null;
      if (stage) {
        saidSomething = true;
        const [reports, hazards, teamMembers, indicators, closedActions] = await Promise.all([
          prisma.safetyReport.count({ where: { orgId: org.id, retractedAt: null } }),
          prisma.hazard.count({ where: { orgId: org.id } }),
          prisma.user.count({ where: { orgId: org.id, active: true } }),
          prisma.spi.count({ where: { orgId: org.id } }),
          prisma.correctiveAction.count({ where: { orgId: org.id, verifiedOn: { not: null }, cancelledOn: null } })
        ]);
        const onboardingComplete = Number(reports > 0) + Number(hazards > 0) + Number(indicators > 0) + Number(teamMembers >= 2);
        for (const to of recipients) {
          const outcome = await sendTrialDigest({
            stage,
            daysRemaining: Math.max(0, TRIAL_DAYS - trialDay),
            reports,
            hazards,
            closedActions,
            onboardingComplete
          }, to, config2);
          if (outcome.status === "SENT") trialSent += 1;
          else if (outcome.status === "FAILED") {
            failures.push({ orgId: org.id, reason: outcome.reason });
          }
        }
      }
      if (!saidSomething) silent += 1;
    } catch (error) {
      failures.push({
        orgId: org.id,
        reason: error instanceof Error ? error.message : "digest failed"
      });
    }
  }
  return Response.json({
    ran: now.toISOString(),
    status: failures.length ? "PARTIAL" : "OK",
    orgs: orgs.length,
    /* STATED, because a run that hit the cap looks exactly like a
       complete one from a count alone. */
    truncated: orgs.length === ORG_LIMIT,
    sent,
    trialSent,
    nothingToSay: silent,
    failures
  });
}
var config = {
  /* 05:00 UTC — 08:00 in Nairobi. See the note at the top. */
  schedule: "0 5 * * *"
};
export {
  config,
  handler as default
};
