
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);

var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// packages/shared/src/regulations.ts
function reportingHours(jurisdiction, occurrenceClass) {
  const obligation = MOR_OBLIGATIONS[jurisdiction];
  return (occurrenceClass && obligation.hoursByClass?.[occurrenceClass]) ?? obligation.hours;
}
function reportingDeadline(jurisdiction, times, occurrenceClass) {
  const obligation = MOR_OBLIGATIONS[jurisdiction];
  const anchor = obligation.clockStart === "AWARENESS" ? times.awareAt : times.occurredAt;
  if (Number.isNaN(anchor.getTime())) {
    throw new Error(
      `reportingDeadline: ${obligation.clockStart === "AWARENESS" ? "awareAt" : "occurredAt"} is not a valid date`
    );
  }
  if (times.awareAt.getTime() < times.occurredAt.getTime()) {
    throw new Error("reportingDeadline: awareAt precedes occurredAt");
  }
  const hours = reportingHours(jurisdiction, occurrenceClass);
  return {
    due: hours === null ? null : new Date(anchor.getTime() + hours * 36e5),
    obligation,
    hours
  };
}
function deadlineStatus(due, now, options = {}) {
  const { submittedAt, obligation, dueSoonHours } = options;
  if (due === null) return submittedAt ? "MET" : "WITHOUT_DELAY";
  if (submittedAt) {
    return submittedAt.getTime() <= due.getTime() ? "MET" : "OVERDUE";
  }
  if (now.getTime() > due.getTime()) return "OVERDUE";
  const windowMs = dueSoonHours !== void 0 ? dueSoonHours * 36e5 : obligation?.hours != null ? obligation.hours * DUE_SOON_FRACTION * 36e5 : DEFAULT_DUE_SOON_HOURS * 36e5;
  return due.getTime() - now.getTime() <= windowMs ? "DUE_SOON" : "PENDING";
}
var JURISDICTIONS, MOR_OBLIGATIONS, DUE_SOON_FRACTION, DEFAULT_DUE_SOON_HOURS;
var init_regulations = __esm({
  "packages/shared/src/regulations.ts"() {
    "use strict";
    JURISDICTIONS = ["ICAO", "KE", "UG", "TZ", "RW", "BI", "SS", "CD", "SO"];
    MOR_OBLIGATIONS = {
      ICAO: {
        jurisdiction: "ICAO",
        authority: "ICAO Standards and Recommended Practices",
        sourceLevel: "PRIMARY",
        hours: null,
        clockStart: "AWARENESS",
        instrument: "ICAO Annex 13, Chapter 4, 4.1 \u2014 notification with a minimum of delay and by the most suitable and quickest means available; with Annex 19 (Safety Management), which requires the State to operate mandatory and voluntary safety reporting systems and leaves the reporting period to the State",
        verifiedOn: "2026-08-12",
        instrumentIssued: "2016-07-01",
        reviewCycleMonths: 36,
        note: "NO FIXED PERIOD, and that is the finding rather than a gap in this row. The 72 hours widely quoted as an ICAO figure is the EU's, from Regulation (EU) No 376/2014 \u2014 misattribution common enough that three rows of this very table once carried it as an 'ICAO-common' default. Use this baseline where the State's own instrument has not been read: notify without delay, and obtain the period from the authority of the State of the operator."
      },
      KE: {
        jurisdiction: "KE",
        authority: "Kenya Civil Aviation Authority",
        sourceLevel: "PRIMARY",
        regionalFramework: "CASSOA",
        /* The strictest of the three below, used when the class is not yet
           known. Never a middle value: an unknown occurrence is treated as
           the one with the least time, because the cost of being early is
           an inconvenience and the cost of being late is a breach. */
        hours: 24,
        /* Regulation 12(1), verbatim: a service provider shall notify and
           make mandatory occurrence reports "to the Authority within 24
           hours, in the case of accident, 48 hours in the case of serious
           incidents and 72 hours in the case of incidents and other safety
           related occurrences." */
        hoursByClass: { ACCIDENT: 24, SERIOUS_INCIDENT: 48, INCIDENT: 72 },
        clockStart: "AWARENESS",
        /* ================================================================
               IT USED TO BE OUR READING. IT IS NOW THE AUTHORITY'S WORDS.
        
               This carried `clockStartUnstated: true` and a note saying that
               L.N. 32 states a period and never says what starts it, so
               awareness was the product's own inference and the screens said
               so. That was honest and it was the best available answer until
               somebody read the governing Advisory Circular.
        
               CAA-AC-SMS004A (January 2023), paragraph 3.3.6.1, Note 1:
        
                 "The reporting period is normally understood to start from
                  when the incident took place or from the time when the
                  reporter determined that there was, or could have been, a
                  potentially hazardous or unsafe condition."
        
               So the Authority does state it, in the instrument sitting above
               this row rather than in the row's own. Awareness is not our
               inference; it is the second limb of the Authority's sentence,
               and the first limb collapses into it — for an occurrence
               somebody knew about as it happened, "when it took place" and
               "when the reporter determined" are the same moment. There is no
               case where the awareness anchor is later than the AC allows.
        
               THE AC PREDATES L.N. 32 AND IS STILL THE REFERENCE. Its own
               deadline table — incident 72 hours, serious incident 48,
               accident 24 — is the same table regulation 12(1) later enacted,
               so it is confirmatory rather than superseded, and the owner's
               instruction was to use it on that basis.
        
               The two facts now come from two instruments, which is why the
               clock start carries its own citation rather than borrowing the
               deadline's. Conflating them would attribute a sentence to L.N. 32
               that L.N. 32 does not contain — the exact misattribution the
               header of this file exists to complain about. */
        clockStartInstrument: "KCAA Advisory Circular CAA-AC-SMS004A (January 2023), paragraph 3.3.6.1, Note 1",
        instrument: "Civil Aviation (Safety Management) Regulations, 2025 (L.N. 32 of 2026, Kenya Gazette Supplement No. 43, 3 March 2026), regulation 12(1)",
        verifiedOn: "2026-08-12",
        /* The date of gazettement, which is the date the instrument bears.
           Note the citation year and the notice year differ — the
           Regulations are cited as of 2025 and were gazetted in 2026, and
           both appear above because an operator searching either will find
           it. */
        instrumentIssued: "2026-03-03",
        reviewCycleMonths: 60,
        note: "THREE PERIODS, NOT ONE, and which applies depends on how the occurrence classifies: 24 hours for an accident, 48 for a serious incident, 72 for an incident or other safety related occurrence. This product previously showed 24 hours for all of them, from KCAA Advisory Circular CAA-AC-SMS004A (January 2023) \u2014 guidance, and now superseded. Regulation 18 of these Regulations revokes L.N. 91/2018.",
        /* THE SECOND CALL, and the reason this field exists at all.
               Regulation 12(1) above is owed to KCAA. Annex 13 puts an
               independent duty on the operator to notify the investigators,
               and the AAID is a different organisation under a different
               ministry. Immediately, and not within any of the three periods
               above — the periods are about the paperwork to the regulator.
        
               THE PROSE STAYS SHORT because this module is in the entry chunk
               that a reporter at a remote strip downloads before filing
               anything. The reasoning belongs in comments, which minify away;
               string values do not. Raising the entry budget to carry an
               argument is a cost paid by the person this product exists for. */
        accidentNotification: {
          authority: "Aircraft Accident Investigation Department (AAID), Kenya",
          url: "https://aaid.transport.go.ke/",
          appliesTo: ["ACCIDENT", "SERIOUS_INCIDENT"],
          basis: "Annex 13 to the Convention on International Civil Aviation.",
          domesticInstrumentRead: false,
          note: "Immediate, and separate from the report to the Authority. Confirm their numbers from the AAID and record them in your emergency contact directory."
        }
      },
      // ------------------------------------------------------------------
      // EAC MEMBER STATES — PROVISIONAL
      //
      // All seven rows below are PROVISIONAL. No primary instrument has been
      // read for any of them. Each row cites ICAO Annex 13, which binds all
      // Chicago Convention signatories and sets the floor: notification with
      // a minimum of delay. The period is null — no fixed figure enters this
      // registry without a citation.
      //
      // To graduate a row from provisional: read the State's own civil
      // aviation regulations and advisory circulars, confirm the period and
      // the clock start, and replace this note with a dated citation.
      // ------------------------------------------------------------------
      UG: {
        jurisdiction: "UG",
        authority: "Uganda Civil Aviation Authority",
        sourceLevel: "PROVISIONAL",
        regionalFramework: "CASSOA",
        hours: null,
        clockStart: "AWARENESS",
        instrument: "ICAO Annex 13, Chapter 4 \u2014 notification with a minimum of delay, by the most suitable and quickest means available. Uganda's own civil aviation regulations have not been read against this row.",
        verifiedOn: "2026-08-19",
        instrumentIssued: "2016-07-01",
        reviewCycleMonths: 12,
        note: "PROVISIONAL \u2014 primary instrument (Uganda Civil Aviation Act and any advisory circulars on occurrence reporting) has not been read. Use ICAO baseline: notify without delay and confirm the period with UCAA directly."
      },
      TZ: {
        jurisdiction: "TZ",
        authority: "Tanzania Civil Aviation Authority",
        sourceLevel: "PROVISIONAL",
        regionalFramework: "CASSOA",
        hours: null,
        clockStart: "AWARENESS",
        instrument: "ICAO Annex 13, Chapter 4 \u2014 notification with a minimum of delay, by the most suitable and quickest means available. Tanzania's own civil aviation regulations have not been read against this row.",
        verifiedOn: "2026-08-19",
        instrumentIssued: "2016-07-01",
        reviewCycleMonths: 12,
        note: "PROVISIONAL \u2014 primary instrument (Tanzania Civil Aviation Act and TCAA regulations on occurrence reporting) has not been read. Use ICAO baseline: notify without delay and confirm the period with TCAA directly."
      },
      RW: {
        jurisdiction: "RW",
        authority: "Rwanda Civil Aviation Authority",
        sourceLevel: "PROVISIONAL",
        regionalFramework: "CASSOA",
        hours: null,
        clockStart: "AWARENESS",
        instrument: "ICAO Annex 13, Chapter 4 \u2014 notification with a minimum of delay, by the most suitable and quickest means available. Rwanda's own civil aviation regulations have not been read against this row.",
        verifiedOn: "2026-08-19",
        instrumentIssued: "2016-07-01",
        reviewCycleMonths: 12,
        note: "PROVISIONAL \u2014 primary instrument (Rwanda Civil Aviation Law and RCAA regulations on occurrence reporting) has not been read. Use ICAO baseline: notify without delay and confirm the period with RCAA directly."
      },
      BI: {
        jurisdiction: "BI",
        authority: "Agence Nationale de l'Aviation Civile du Burundi",
        sourceLevel: "PROVISIONAL",
        regionalFramework: "CASSOA",
        hours: null,
        clockStart: "AWARENESS",
        instrument: "ICAO Annex 13, Chapter 4 \u2014 notification with a minimum of delay, by the most suitable and quickest means available. Burundi's own civil aviation regulations have not been read against this row.",
        verifiedOn: "2026-08-19",
        instrumentIssued: "2016-07-01",
        reviewCycleMonths: 12,
        note: "PROVISIONAL \u2014 primary instrument (Burundi civil aviation law and ANAC-BI regulations on occurrence reporting) has not been read. Use ICAO baseline: notify without delay and confirm the period with ANAC-BI directly."
      },
      SS: {
        jurisdiction: "SS",
        authority: "South Sudan Civil Aviation Authority",
        sourceLevel: "PROVISIONAL",
        regionalFramework: "CASSOA",
        hours: null,
        clockStart: "AWARENESS",
        instrument: "ICAO Annex 13, Chapter 4 \u2014 notification with a minimum of delay, by the most suitable and quickest means available. South Sudan's own civil aviation regulations have not been read against this row.",
        verifiedOn: "2026-08-19",
        instrumentIssued: "2016-07-01",
        reviewCycleMonths: 12,
        note: "PROVISIONAL \u2014 primary instrument (South Sudan Civil Aviation Act and SSCAA regulations on occurrence reporting) has not been read. Use ICAO baseline: notify without delay and confirm the period with SSCAA directly."
      },
      CD: {
        jurisdiction: "CD",
        authority: "Direction G\xE9n\xE9rale de l'Aviation Civile (DRC)",
        sourceLevel: "PROVISIONAL",
        regionalFramework: "CASSOA",
        hours: null,
        clockStart: "AWARENESS",
        instrument: "ICAO Annex 13, Chapter 4 \u2014 notification with a minimum of delay, by the most suitable and quickest means available. DRC's own civil aviation regulations have not been read against this row.",
        verifiedOn: "2026-08-19",
        instrumentIssued: "2016-07-01",
        reviewCycleMonths: 12,
        note: "PROVISIONAL \u2014 primary instrument (DRC civil aviation code and DGAC regulations on occurrence reporting) has not been read. Use ICAO baseline: notify without delay and confirm the period with DGAC-DRC directly."
      },
      SO: {
        jurisdiction: "SO",
        authority: "Somali Civil Aviation Authority",
        sourceLevel: "PROVISIONAL",
        regionalFramework: "CASSOA",
        hours: null,
        clockStart: "AWARENESS",
        instrument: "ICAO Annex 13, Chapter 4 \u2014 notification with a minimum of delay, by the most suitable and quickest means available. Somalia's own civil aviation regulations have not been read against this row.",
        verifiedOn: "2026-08-19",
        instrumentIssued: "2016-07-01",
        reviewCycleMonths: 12,
        note: "PROVISIONAL \u2014 primary instrument (Somalia Civil Aviation Law and SCAA regulations on occurrence reporting) has not been read. Use ICAO baseline: notify without delay and confirm the period with SCAA directly."
      }
    };
    DUE_SOON_FRACTION = 0.25;
    DEFAULT_DUE_SOON_HOURS = 6;
  }
});

// packages/shared/src/regulatory-source.ts
var REGULATORY_SOURCE_LABELS, REGIONAL_FRAMEWORK_LABELS;
var init_regulatory_source = __esm({
  "packages/shared/src/regulatory-source.ts"() {
    "use strict";
    REGULATORY_SOURCE_LABELS = Object.freeze({
      PRIMARY: "primary instrument read",
      REGIONAL_GUIDANCE: "regional guidance",
      PROVISIONAL: "primary instrument unread",
      OPERATOR_DECLARED: "operator declared"
    });
    REGIONAL_FRAMEWORK_LABELS = Object.freeze({
      CASSOA: "CASSOA / East African Community harmonisation"
    });
  }
});

// packages/shared/src/taxonomy.ts
function isKnownOrFreeText(value, known) {
  if (value === OTHER) return false;
  if (known.has(value)) return true;
  if (/^[A-Z0-9]{3,4}$/.test(value)) return false;
  return value.length > 0 && value.length <= 120;
}
function isValidLocation(value) {
  return isKnownOrFreeText(value, AERODROME_CODES);
}
function isValidAircraftType(value) {
  return isKnownOrFreeText(value, AIRCRAFT_CODES);
}
var OTHER, AERODROMES, AIRCRAFT_TYPES, HRC_CATEGORIES, NASP_HIGH_RISK, AERODROME_CODES, AIRCRAFT_CODES;
var init_taxonomy = __esm({
  "packages/shared/src/taxonomy.ts"() {
    "use strict";
    OTHER = "__OTHER__";
    AERODROMES = [
      { code: "HKJK", label: "Nairobi / Jomo Kenyatta (HKJK)", country: "KE" },
      { code: "HKNW", label: "Nairobi / Wilson (HKNW)", country: "KE" },
      { code: "HKMO", label: "Mombasa / Moi (HKMO)", country: "KE" },
      { code: "HKKI", label: "Kisumu (HKKI)", country: "KE" },
      { code: "HKEL", label: "Eldoret (HKEL)", country: "KE" },
      { code: "HKML", label: "Malindi (HKML)", country: "KE" },
      { code: "HKLU", label: "Lamu (HKLU)", country: "KE" },
      { code: "HKLO", label: "Lodwar (HKLO)", country: "KE" },
      { code: "HKUK", label: "Ukunda / Diani (HKUK)", country: "KE" },
      { code: "HKNI", label: "Nyeri (HKNI)", country: "KE" },
      /* THE NORTHERN NETWORK.
           Added after reading a real operator's Safety Risk Analysis for
           Wajir — the document names "Wajir International Airport (ICAO:
           HKWJ)" and this list did not contain it. An operator whose own SRA
           concerns an aerodrome the taxonomy cannot express is an operator
           whose reports all land in the free-text escape hatch, which is
           precisely the GROUP BY problem the dropdowns exist to prevent.
      
           HKWJ is evidenced by that document. The rest are the northern and
           northeastern fields the same network serves; verify each against
           the current AIP before a customer's compliance depends on it. */
      { code: "HKWJ", label: "Wajir (HKWJ)", country: "KE" },
      { code: "HKGA", label: "Garissa (HKGA)", country: "KE" },
      { code: "HKMA", label: "Mandera (HKMA)", country: "KE" },
      { code: "HKMB", label: "Marsabit (HKMB)", country: "KE" },
      { code: "HKLK", label: "Lokichogio (HKLK)", country: "KE" },
      { code: "HKKT", label: "Kitale (HKKT)", country: "KE" },
      { code: "HKNY", label: "Nanyuki (HKNY)", country: "KE" },
      { code: "HKAM", label: "Amboseli (HKAM)", country: "KE" },
      /* ==================================================================
           THE EAST AFRICAN COMMUNITY, AND SOMALIA.
      
           The note above this list argued that a Kenyan operator filing about
           a sector into Entebbe should type it, because a dropdown entry
           implies the product knows Uganda's obligations. That reasoning was
           sound about ONE thing and wrong about the field it was applied to.
      
           WHERE AN OCCURRENCE HAPPENED AND WHOSE RULES GOVERN IT ARE TWO
           SEPARATE QUESTIONS, and this form already asks them separately —
           `location` here, and "Which authority does this operation answer
           to?" from JURISDICTION_OPTIONS. An aerodrome in this list makes no
           claim about deadlines; the jurisdiction field does, and it still
           covers what regulations.ts can actually compute. So the coupling
           the old note feared does not exist in the markup.
      
           What the old arrangement DID cost is the thing dropdowns exist for.
           Every EAC sector landed in the free-text escape hatch, so an
           operator flying Nairobi–Entebbe–Kigali could not count events by
           place, and neither the risk picture nor an indicator keyed to an
           aerodrome could see them. Untaggable is uncountable — the same
           defect the ground-operations categories had.
      
           Somalia is included because it acceded to the EAC, and because the
           Kenyan charter and survey operators this product is built for fly
           there constantly.
      
           EVERY CODE BELOW WAS VERIFIED, not recalled, and the check earned
           its keep: Juba is HJJJ and recall said HSSJ; Bosaso is HCMF and
           recall said HCMV. Two wrong ICAO codes in an aviation product is
           precisely the class of error this repository refuses to ship.
           Verify against the current AIP before a customer's compliance
           depends on any of them.
           ================================================================== */
      { code: "HUEN", label: "Entebbe (HUEN)", country: "UG" },
      { code: "HTDA", label: "Dar es Salaam / Julius Nyerere (HTDA)", country: "TZ" },
      { code: "HTKJ", label: "Kilimanjaro (HTKJ)", country: "TZ" },
      { code: "HTZA", label: "Zanzibar / Abeid Amani Karume (HTZA)", country: "TZ" },
      { code: "HTMW", label: "Mwanza (HTMW)", country: "TZ" },
      { code: "HTAR", label: "Arusha (HTAR)", country: "TZ" },
      { code: "HRYR", label: "Kigali (HRYR)", country: "RW" },
      { code: "HBBA", label: "Bujumbura (HBBA)", country: "BI" },
      { code: "HJJJ", label: "Juba (HJJJ)", country: "SS" },
      { code: "FZAA", label: "Kinshasa / N'Djili (FZAA)", country: "CD" },
      { code: "FZNA", label: "Goma (FZNA)", country: "CD" },
      { code: "FZQA", label: "Lubumbashi (FZQA)", country: "CD" },
      { code: "HCMM", label: "Mogadishu / Aden Adde (HCMM)", country: "SO" },
      { code: "HCMH", label: "Hargeisa / Egal (HCMH)", country: "SO" },
      { code: "HCMI", label: "Berbera (HCMI)", country: "SO" },
      { code: "HCMK", label: "Kismayo (HCMK)", country: "SO" },
      { code: "HCMF", label: "Bosaso (HCMF)", country: "SO" }
    ];
    AIRCRAFT_TYPES = [
      { code: "DH8D", label: "DHC-8-400 (Dash 8 Q400)", category: "Turboprop" },
      { code: "DH8C", label: "DHC-8-300", category: "Turboprop" },
      { code: "AT76", label: "ATR 72-600", category: "Turboprop" },
      { code: "AT75", label: "ATR 72-500", category: "Turboprop" },
      { code: "AT46", label: "ATR 42-600", category: "Turboprop" },
      { code: "C208", label: "Cessna 208 Caravan", category: "Turboprop" },
      { code: "C20B", label: "Cessna 208B Grand Caravan", category: "Turboprop" },
      { code: "BE20", label: "Beechcraft King Air 200", category: "Turboprop" },
      { code: "DHC6", label: "DHC-6 Twin Otter", category: "Turboprop" },
      { code: "L410", label: "LET L-410", category: "Turboprop" },
      { code: "F406", label: "Reims F406 Caravan II", category: "Turboprop" },
      /* The Fokker 50 was missing while the Fokker 70 was here, which made
         the list unable to describe the commonest mid-tier East African
         fleet shape: 50s on the regional turboprop routes and 70s on the
         jet ones, from one operator. A type list that cannot name half a
         customer's fleet sends that half to the free-text escape, and free
         text is the half nobody can count. */
      { code: "F50", label: "Fokker 50", category: "Turboprop" },
      /* THE 737 CLASSICS, and their absence was the same shape as the
         Fokker 50's. The list carried the NG and the MAX — the fleet a
         well-capitalised flag carrier buys — and neither of the two
         variants an East African operator is most likely to be flying. The
         -300 and -400 are the backbone of regional freight and charter
         across the continent: cheap to acquire, still certified, and
         over-represented in exactly the operations this product exists for.
         An operator whose whole jet fleet fell into the free-text escape
         hatch is an operator whose jet occurrences cannot be grouped. */
      { code: "B733", label: "Boeing 737-300", category: "Jet" },
      { code: "B734", label: "Boeing 737-400", category: "Jet" },
      { code: "B738", label: "Boeing 737-800", category: "Jet" },
      { code: "B38M", label: "Boeing 737 MAX 8", category: "Jet" },
      { code: "B788", label: "Boeing 787-8", category: "Jet" },
      { code: "E190", label: "Embraer E190", category: "Jet" },
      { code: "CRJ9", label: "Bombardier CRJ900", category: "Jet" },
      /* Same source as HKWJ above: the SRA is written for an F70 fleet and
         this list could not name the aircraft it is about. */
      { code: "F70", label: "Fokker 70", category: "Jet" },
      { code: "F100", label: "Fokker 100", category: "Jet" },
      { code: "A320", label: "Airbus A320", category: "Jet" },
      { code: "C172", label: "Cessna 172", category: "Piston" },
      { code: "C206", label: "Cessna 206", category: "Piston" },
      { code: "BE58", label: "Beechcraft Baron 58", category: "Piston" },
      { code: "R44", label: "Robinson R44", category: "Rotorcraft" },
      { code: "AS50", label: "Airbus AS350", category: "Rotorcraft" },
      { code: "B06", label: "Bell 206", category: "Rotorcraft" }
    ];
    HRC_CATEGORIES = [
      { code: "CFIT", label: "Controlled flight into terrain", group: "In flight", nasp: true },
      { code: "LOC-I", label: "Loss of control in flight", group: "In flight", nasp: true },
      { code: "MAC", label: "Loss of separation or near mid-air", group: "In flight", nasp: true },
      { code: "BWI", label: "Bird or wildlife strike", group: "In flight", nasp: true, cictt: "BIRD" },
      { code: "TURB", label: "Turbulence encounter", group: "In flight", nasp: false },
      { code: "RE", label: "Runway excursion", group: "Runway", nasp: true },
      { code: "RI", label: "Runway incursion", group: "Runway", nasp: true },
      { code: "ARC", label: "Heavy, long or abnormal landing", group: "Runway", nasp: false },
      { code: "RAMP", label: "Ground handling \u2014 loading, servicing, marshalling", group: "On the ground", nasp: false },
      { code: "GCOL", label: "Ground collision", group: "On the ground", nasp: false },
      { code: "LOC-G", label: "Loss of control while taxiing", group: "On the ground", nasp: false },
      { code: "GTOW", label: "Towing or pushback", group: "On the ground", nasp: false },
      { code: "SCF-PP", label: "Engine or propeller failure", group: "Technical", nasp: false },
      { code: "SCF-NP", label: "Other system or component failure", group: "Technical", nasp: false },
      { code: "FUEL", label: "Fuel \u2014 quantity, contamination or starvation", group: "Technical", nasp: false }
    ];
    NASP_HIGH_RISK = HRC_CATEGORIES.filter((c) => c.nasp);
    AERODROME_CODES = new Set(AERODROMES.map((a) => a.code));
    AIRCRAFT_CODES = new Set(AIRCRAFT_TYPES.map((a) => a.code));
  }
});

// packages/shared/src/glossary.ts
var SMS_ACRONYMS, OCCURRENCE_CLASSES, SERIOUS_INJURY_TESTS, DEFINITIONS, GLOSSARY_SOURCE;
var init_glossary = __esm({
  "packages/shared/src/glossary.ts"() {
    "use strict";
    SMS_ACRONYMS = Object.freeze({
      AAID: "Aircraft Accident Investigation Department",
      ADREP: "Accident/incident data reporting",
      AIA: "Accident investigation authority",
      ALARP: "As low as reasonably practicable",
      ALOSP: "Acceptable level of safety performance",
      AMO: "Approved maintenance organisation",
      ANS: "Air navigation services",
      AOC: "Air operator certificate",
      ATO: "Approved training organisation",
      ATS: "Air traffic service(s)",
      CAA: "Civil aviation authority",
      CAST: "Commercial Aviation Safety Team",
      CICTT: "CAST/ICAO Common Taxonomy Team",
      CVR: "Cockpit voice recorder",
      D3M: "Data-driven decision-making",
      ERP: "Emergency response plan",
      FDA: "Flight data analysis",
      FDR: "Flight data recorder",
      FRMS: "Fatigue risk management system",
      GASP: "Global aviation safety plan",
      ICAO: "International Civil Aviation Organization",
      ISTARS: "Integrated safety trend analysis and reporting system",
      KCAA: "Kenya Civil Aviation Authority",
      LOSA: "Line operations safety audit",
      MOT: "Ministry of Transport",
      OHSMS: "Occupational health and safety management system",
      OSHE: "Occupational safety, health and environment",
      PIRG: "Planning and implementation regional group",
      QMS: "Quality management system",
      RASG: "Regional aviation safety group",
      RSOO: "Regional safety oversight organization",
      SAG: "Safety action group",
      SARPS: "Standards and Recommended Practices",
      SDCPS: "Safety data collection and processing system",
      SEMS: "Security management system",
      SMM: "Safety management manual",
      SMP: "Safety Management Panel",
      SMS: "Safety management system",
      SPI: "Safety performance indicator",
      SPT: "Safety performance target",
      SRB: "Safety review board",
      SRC: "Safety review committee",
      SRBS: "Safety risk-based surveillance",
      SRM: "Safety risk management",
      SSO: "State safety oversight",
      SSP: "State safety programme",
      TNA: "Training needs analysis",
      USOAP: "Universal Safety Oversight Audit Programme"
    });
    OCCURRENCE_CLASSES = Object.freeze([
      {
        key: "ACCIDENT",
        label: "Accident",
        test: "Someone was killed or seriously injured, the aircraft was damaged in a way that affects its strength or performance and needs major repair, or the aircraft is missing or completely inaccessible.",
        reportable: true,
        note: "Damage limited to one engine, propellers, wing tips, antennas, tyres, brakes, wheels, fairings, panels, landing gear doors, windscreens or small dents in the skin does NOT make it an accident on its own."
      },
      {
        key: "SERIOUS_INCIDENT",
        label: "Serious incident",
        test: "Nobody was hurt and the aircraft was not damaged like that, but the circumstances say an accident very nearly happened.",
        reportable: true,
        // The glossary's own sentence. It is the clearest thing in the
        // document and it is what most reporters get wrong.
        note: "The difference between an accident and a serious incident lies only in the result."
      },
      {
        key: "INCIDENT",
        label: "Incident",
        test: "Something happened in the operation of an aircraft that affected safety, or could have.",
        reportable: false,
        note: "Not reportable to the regulator as an occurrence in every case, and still worth filing: the incidents are where the accidents are visible first."
      }
    ]);
    SERIOUS_INJURY_TESTS = Object.freeze([
      "hospital for more than 48 hours, starting within seven days of the injury",
      "a broken bone \u2014 except a simple break of a finger, toe or the nose",
      "cuts causing severe bleeding, or nerve, muscle or tendon damage"
    ]);
    DEFINITIONS = Object.freeze({
      Hazard: "A condition or an object with the potential to cause or contribute to an aircraft incident or accident.",
      "Safety risk": "The predicted probability and severity of the consequences or outcomes of a hazard.",
      Defences: "Specific mitigating actions, preventive controls or recovery measures put in place to prevent the realization of a hazard or its escalation into an undesirable consequence.",
      "Safety data": "A defined set of facts or set of safety values collected from various aviation-related sources, which is used to maintain or improve safety.",
      "Safety information": "Safety data processed, organized or analysed in a given context so as to make it useful for safety management purposes.",
      "Safety performance indicator": "A data-based parameter used for monitoring and assessing safety performance.",
      "Safety performance target": "The State or service provider's planned or intended target for a safety performance indicator over a given period that aligns with the safety objectives.",
      Trigger: "An established level or criteria value for a particular safety performance indicator that serves to initiate an action required.",
      "Accountable executive": "A single, identifiable person having responsibility for the effective and efficient performance of the service provider's SMS.",
      "Change management": "A formal process to manage changes within an organization in a systematic manner, so that changes which may impact identified hazards and risk mitigation strategies are accounted for before the implementation of such changes."
    });
    GLOSSARY_SOURCE = Object.freeze({
      instrument: "KCAA SMS course glossary (ICAO Annex 19 / Doc 9859 definitions)",
      transcribedOn: "2026-08-11",
      /** Definitions move with Annex amendments; Amendment 2 applies 26 Nov 2026. */
      reviewCycleMonths: 24
    });
  }
});

// packages/shared/src/risk.ts
function valueOf(sev, lik) {
  const s = SEVERITY_VALUE[sev];
  const l = LIKELIHOOD_VALUE[lik];
  if (s === void 0 || l === void 0) {
    throw new RangeError(
      `not on the Doc 9859 scale: severity ${JSON.stringify(sev)}, likelihood ${JSON.stringify(lik)}`
    );
  }
  return { s, l };
}
function riskScore(sev, lik) {
  const { s, l } = valueOf(sev, lik);
  return s * l;
}
function tolerability(sev, lik) {
  const { s, l } = valueOf(sev, lik);
  const key = `${s}x${l}`;
  if (RED.has(key)) return "INTOLERABLE";
  if (AMBER.has(key)) return "TOLERABLE";
  return "ACCEPTABLE";
}
var SEVERITY_VALUE, LIKELIHOOD_VALUE, SEVERITY_SCALE, LIKELIHOOD_SCALE, RED, AMBER;
var init_risk = __esm({
  "packages/shared/src/risk.ts"() {
    "use strict";
    SEVERITY_VALUE = {
      A_CATASTROPHIC: 5,
      B_HAZARDOUS: 4,
      C_MAJOR: 3,
      D_MINOR: 2,
      E_NEGLIGIBLE: 1
    };
    LIKELIHOOD_VALUE = {
      FREQUENT: 5,
      OCCASIONAL: 4,
      REMOTE: 3,
      IMPROBABLE: 2,
      EXTREMELY_IMPROBABLE: 1
    };
    SEVERITY_SCALE = [
      { key: "A_CATASTROPHIC", code: "A", label: "Catastrophic" },
      { key: "B_HAZARDOUS", code: "B", label: "Hazardous" },
      { key: "C_MAJOR", code: "C", label: "Major" },
      { key: "D_MINOR", code: "D", label: "Minor" },
      { key: "E_NEGLIGIBLE", code: "E", label: "Negligible" }
    ];
    LIKELIHOOD_SCALE = [
      { key: "FREQUENT", code: "5", label: "Frequent" },
      { key: "OCCASIONAL", code: "4", label: "Occasional" },
      { key: "REMOTE", code: "3", label: "Remote" },
      { key: "IMPROBABLE", code: "2", label: "Improbable" },
      { key: "EXTREMELY_IMPROBABLE", code: "1", label: "Extremely improbable" }
    ];
    RED = /* @__PURE__ */ new Set(["5x5", "5x4", "5x3", "4x5", "4x4", "3x5"]);
    AMBER = /* @__PURE__ */ new Set(["5x2", "5x1", "4x3", "4x2", "3x4", "3x3", "2x5", "2x4", "1x5"]);
  }
});

// packages/shared/src/permissions.ts
function can(role, p) {
  return PERMISSIONS[role].has(p);
}
function readsNarrative(role) {
  return [...NARRATIVE_PERMISSIONS].some((p) => can(role, p));
}
function mayCreateRole(creator, target) {
  if (target === "PLATFORM_ADMIN") return false;
  if (!can(creator, "user.manage")) return false;
  if (!readsNarrative(creator) && readsNarrative(target)) return false;
  return true;
}
function mayResetCredential(actor, target) {
  if (target === "PLATFORM_ADMIN") return false;
  if (!can(actor, "user.manage")) return false;
  if (!readsNarrative(actor) && readsNarrative(target)) return false;
  return true;
}
var PERMISSIONS, NARRATIVE_PERMISSIONS;
var init_permissions = __esm({
  "packages/shared/src/permissions.ts"() {
    "use strict";
    PERMISSIONS = {
      FRONTLINE: /* @__PURE__ */ new Set([
        "report.create",
        "report.read.own",
        "document.read",
        "training.read.own"
      ]),
      SAFETY_OFFICER: /* @__PURE__ */ new Set([
        "report.create",
        "report.read.own",
        "report.read.org",
        "report.triage",
        "hazard.manage",
        "risk.assess",
        "spi.read",
        "document.read",
        "training.read.own"
      ]),
      SAFETY_MANAGER: /* @__PURE__ */ new Set([
        "report.create",
        "report.read.own",
        "report.read.org",
        "report.triage",
        "report.investigate",
        "report.close",
        "report.deidentify.review",
        "hazard.manage",
        "risk.assess",
        "risk.accept.tolerable",
        "spi.configure",
        "spi.read",
        "moc.create",
        "document.read",
        "document.manage",
        "training.read.own",
        "training.manage",
        "audit.read",
        // The post that actually runs the SMS: it drafts the policy, keeps
        // the accountability matrix, exercises the plan, conducts the
        // internal audit and publishes the bulletins. It does NOT sign the
        // policy and does NOT verify its own findings.
        "policy.draft",
        "accountability.manage",
        "appointment.manage",
        "erp.manage",
        "sms.audit.conduct",
        "communication.publish",
        // The post that would be asked for the record in an audit is the
        // post that can take a copy of it.
        "org.export",
        // And the post that maintains the manual maintains the words in it.
        "config.manage"
      ]),
      INVESTIGATOR: /* @__PURE__ */ new Set([
        "report.read.org",
        "report.investigate",
        "hazard.manage",
        "risk.assess",
        "spi.read",
        "document.read",
        "training.read.own"
      ]),
      KEY_MANAGEMENT: /* @__PURE__ */ new Set([
        "report.read.org",
        "risk.accept.tolerable",
        "spi.read",
        "moc.create",
        "moc.approve",
        "document.read",
        "training.read.own",
        "audit.read",
        /* VERIFICATION, not conduct. Whoever ran the audit saying their own
           corrective action worked is the weakest evidence in an assurance
           programme, so closing a finding and verifying it are held by
           different posts by construction rather than by convention. */
        "sms.audit.verify"
      ]),
      ACCOUNTABLE_EXECUTIVE: /* @__PURE__ */ new Set([
        /* `risk.accept.tolerable` and NOT an intolerable counterpart — see
           the note in the union above. The amber band is this post's to
           carry precisely because accepting it is a judgement about cost
           against safety; the red band is nobody's, at any level. */
        "report.read.org",
        "risk.accept.tolerable",
        /* FILING, AND ITS ABSENCE WAS NEVER A DECISION.
               ==========================================================
               This role could not file a report. No test asserted that it
               should not — which in this repository is the signature of an
               unexamined default rather than a judgement — and it was found by
               walking the sequence a design partner walks, not by reading the
               matrix.
        
               IT MADE THE PRODUCT'S OWN GATE UNREACHABLE. Signup creates
               exactly one account and it is this one, so a new operator's first
               and only user filed a report, watched the sync answer `forbidden`
               per item, and read "your role cannot submit this report type" on
               a device with nowhere else to go. docs/02-STRATEGY.md sets
               Phase 1's gate as "a frontline user files a report offline and it
               arrives"; nobody could reach it without first appointing a second
               person. /today's first-run sequence then made it worse by opening
               with "File the first report".
        
               AND IT IS WRONG ON THE INSTRUMENT, which is the reason rather
               than the convenience. Annex 19's reporting system is for ALL
               personnel. The accountable executive is personnel, is the post
               ACCOUNTABLE for the safety management system, and was the one
               person in the organisation structurally unable to perform its
               most basic act.
        
               SYSTEM_ADMIN and PLATFORM_ADMIN still cannot file, and that stays
               deliberate: the administrator is a technical post held away from
               the safety record on purpose — the escalation rule in
               routes.auth.ts rests on exactly that — and the platform
               administrator is the vendor, who must never write into a tenant's
               safety record. */
        "report.create",
        "spi.read",
        "moc.approve",
        "document.read",
        "audit.read",
        "training.read.own",
        "config.manage",
        /* APPOINTING THE PEOPLE, because signup creates exactly one of these
           and nothing else could create a second user at all. Every operator
           that ever signed up had one account, in an organisation containing
           nobody able to add a safety officer — so the reporting system had
           no reporters. Under Annex 19 this post is the one answerable for
           the SMS; deciding who staffs it is squarely its function. */
        "user.manage",
        /* SIGNING THE POLICY IS THIS ROLE'S ALONE, and it is the only
           permission in this file held by exactly one role. Element 1.1 is
           not "there is a policy" — it is that the person who can move money
           and schedule has put their name to it. A safety manager signing on
           their behalf is the finding, not the evidence. */
        "policy.sign",
        // And appointing the key personnel, which is the same authority.
        "appointment.manage",
        /* And holding the operator's own copy. Data ownership that depends
           on the safety manager still being employed is not ownership. */
        "org.export"
      ]),
      REGULATOR_INSPECTOR: /* @__PURE__ */ new Set([
        "regulator.oversight",
        "audit.read",
        "spi.read",
        "document.read"
      ]),
      /* THE SHORTEST SET IN THIS MATRIX, ON PURPOSE.
      
           A vendor account that could read one narrative could read every
           narrative in every tenant, which is a worse position than any
           single operator can put itself in. So it holds the two powers it
           needs to run a business and nothing else: no report permission, no
           hazard, no audit, no export, not even `org.manage` — creating an
           operator is `platform.operator.provision` and administering one
           afterwards belongs to that operator.
      
           tests/platform.test.ts asserts this set is disjoint from
           NARRATIVE_PERMISSIONS, and that it holds no permission any other
           role uses to reach a safety record. */
      PLATFORM_ADMIN: /* @__PURE__ */ new Set([
        "platform.operator.provision",
        "platform.entitlement.manage"
      ]),
      SYSTEM_ADMIN: /* @__PURE__ */ new Set([
        "org.manage",
        "user.manage",
        "audit.read",
        // Account administration extends to who holds which post; it stops
        // short of authoring or signing any of the safety documentation.
        "appointment.manage"
      ])
    };
    NARRATIVE_PERMISSIONS = /* @__PURE__ */ new Set([
      "report.read.own",
      "report.read.org",
      "report.triage",
      "report.investigate",
      "report.deidentify.review"
    ]);
  }
});

// packages/shared/src/index.ts
import { z } from "zod";
var RoleEnum, ReportTypeEnum, HrcEnum, FlightPhaseEnum, SeverityEnum, LikelihoodEnum, TolerabilityEnum, CreateReportSchema, RiskAssessInputSchema, LoginSchema, SyncItemSchema, SyncBatchSchema;
var init_src = __esm({
  "packages/shared/src/index.ts"() {
    "use strict";
    init_regulations();
    init_regulatory_source();
    init_taxonomy();
    init_glossary();
    init_taxonomy();
    init_regulations();
    init_risk();
    init_risk();
    init_permissions();
    RoleEnum = z.enum([
      "FRONTLINE",
      "SAFETY_OFFICER",
      "SAFETY_MANAGER",
      "INVESTIGATOR",
      "KEY_MANAGEMENT",
      "ACCOUNTABLE_EXECUTIVE",
      "REGULATOR_INSPECTOR",
      "SYSTEM_ADMIN",
      /* The vendor, not the operator — see permissions.ts. It is in this
         enum because it is a value the Role column holds, and NOT in any
         screen's role picker: an operator cannot create one, because a
         tenant that could mint a platform administrator would be a tenant
         that could read the others. */
      "PLATFORM_ADMIN"
    ]);
    ReportTypeEnum = z.enum(["MOR", "VCR", "HAZARD", "SUGGESTION", "NEAR_MISS", "FATIGUE"]);
    HrcEnum = z.enum(["RE", "RI", "LOC_I", "CFIT", "MAC", "BWI"]);
    FlightPhaseEnum = z.enum([
      "STANDING",
      "PUSHBACK",
      "TAXI",
      "TAKEOFF",
      "INITIAL_CLIMB",
      "CLIMB",
      "CRUISE",
      "DESCENT",
      "APPROACH",
      "LANDING",
      "LANDING_ROLL",
      "GO_AROUND",
      "GROUND_HANDLING",
      "MAINTENANCE"
    ]);
    SeverityEnum = z.enum([
      "A_CATASTROPHIC",
      "B_HAZARDOUS",
      "C_MAJOR",
      "D_MINOR",
      "E_NEGLIGIBLE"
    ]);
    LikelihoodEnum = z.enum([
      "FREQUENT",
      "OCCASIONAL",
      "REMOTE",
      "IMPROBABLE",
      "EXTREMELY_IMPROBABLE"
    ]);
    TolerabilityEnum = z.enum(["INTOLERABLE", "TOLERABLE", "ACCEPTABLE"]);
    CreateReportSchema = z.object({
      clientId: z.string().uuid(),
      // offline idempotency key
      type: ReportTypeEnum,
      title: z.string().min(3).max(200),
      narrative: z.string().min(10).max(2e4),
      occurredAt: z.coerce.date().optional(),
      /**
       * When the reporter became aware. Optional on the wire — the server
       * defaults it to receipt time, which is the earliest moment it can
       * prove — but NEVER defaulted to occurredAt. See regulations.ts.
       */
      awareAt: z.coerce.date().optional(),
      jurisdiction: z.enum(JURISDICTIONS).default("KE"),
      // Validated against the taxonomy, not merely length-checked. The
      // dropdown constrains the form; this constrains the REQUEST, which is
      // what a future integration or a replayed payload actually sends.
      location: z.string().max(120).refine(isValidLocation, {
        message: "location must be an aerodrome code from the taxonomy, or a description"
      }).optional(),
      aircraftType: z.string().max(120).refine(isValidAircraftType, {
        message: "aircraftType must be a type code from the taxonomy, or a description"
      }).optional(),
      phase: FlightPhaseEnum.optional(),
      hrcTags: z.array(HrcEnum).max(6).default([]),
      /**
       * WHAT THE REPORTER THINKS SHOULD BE DONE.
       *
       * Taken from the operator hazard report form the design partner uses:
       * "Reporter's Recommendations" is a first-class section there, above
       * the safety office's own analysis, and this product did not have it.
       *
       * It is the cheapest safety intelligence in the system. The person who
       * saw the hazard is usually the person who knows the fix, and asking
       * costs one optional field. Leaving it out means the fix arrives, if
       * at all, from someone who was not there.
       *
       * Optional and always will be: making it required would put a second
       * writing task between a ramp agent and filing, which is how report
       * volume dies.
       */
      reporterRecommendation: z.string().max(2e3).optional(),
      /**
       * WHAT A FATIGUE REPORT CARRIES THAT NO OTHER REPORT DOES.
       *
       * NESTED RATHER THAN FLAT, unlike location and aircraftType above,
       * and the nesting is the point: every one of these is meaningless
       * unless the type is FATIGUE, and an optional object says that in the
       * shape rather than in a comment. The refinement below then makes it
       * impossible to attach a duty to a bird strike.
       *
       * EVERY FIELD IS OPTIONAL INSIDE IT. A crew member who cannot
       * remember their rest to the half hour must still be able to file —
       * a form that refuses an incomplete fatigue report converts a report
       * into silence, which is the one outcome this product cannot afford.
       * fatigue.ts reports the shortfall as INCOMPLETE rather than guessing.
       */
      fatigue: z.object({
        flightTimeHours: z.number().min(0).max(24).optional(),
        dutyHours: z.number().min(0).max(48).optional(),
        restBeforeHours: z.number().min(0).max(168).optional(),
        sectors: z.number().int().min(0).max(40).optional(),
        sleepPrior24Hours: z.number().min(0).max(24).optional(),
        /* LOCAL hours, 0..23. The window of circadian low belongs to the
           reporter's body clock, so a UTC timestamp would need an
           acclimatisation model this product does not have. */
        startLocalHour: z.number().int().min(0).max(23).optional(),
        endLocalHour: z.number().int().min(0).max(23).optional(),
        /* Samn-Perelli. Bounded to the scale so a client cannot invent an
           eighth level that every threshold comparison then mis-reads. */
        samnPerelli: z.number().int().min(1).max(7).optional()
      }).optional(),
      isAnonymous: z.boolean().default(false)
    }).refine(
      (r) => r.type !== "MOR" || r.occurredAt !== void 0,
      { message: "MOR requires occurredAt to compute the regulatory deadline", path: ["occurredAt"] }
    ).refine(
      (r) => !r.awareAt || !r.occurredAt || r.awareAt.getTime() >= r.occurredAt.getTime(),
      { message: "awareAt cannot precede occurredAt", path: ["awareAt"] }
    ).refine(
      /* A DUTY CANNOT BE ATTACHED TO A BIRD STRIKE. The fatigue block is
         read by the fatigue picture and by nothing else, so a block riding
         on a HAZARD would be data that no screen displays and no query
         counts — invisible rather than wrong, which is worse. Rejected at
         the door with a message naming the field, rather than silently
         dropped on the way to the database. */
      (r) => !r.fatigue || r.type === "FATIGUE",
      { message: "duty details belong to a FATIGUE report", path: ["fatigue"] }
    );
    RiskAssessInputSchema = z.object({
      // uuid, not cuid. The old schema mixed both, so an id that satisfied
      // one endpoint was rejected by the next for no reason a caller could see.
      hazardId: z.string().uuid(),
      consequence: z.string().min(5).max(1e3),
      severity: SeverityEnum,
      likelihood: LikelihoodEnum,
      alarpJustification: z.string().max(4e3).optional()
    }).refine(
      // ALARP is the whole point of the amber band: a tolerable risk is
      // tolerable only if it has been driven as low as reasonably
      // practicable, and the justification is the evidence of that. An
      // unjustified TOLERABLE is an unaccepted risk wearing a green badge.
      (r) => tolerability(r.severity, r.likelihood) !== "TOLERABLE" || !!r.alarpJustification,
      { message: "A TOLERABLE (ALARP) risk requires an alarpJustification", path: ["alarpJustification"] }
    );
    LoginSchema = z.object({
      email: z.string().trim().toLowerCase().email(),
      password: z.string().min(12),
      mfaCode: z.string().length(6).optional()
    });
    SyncItemSchema = z.object({
      clientId: z.string().uuid(),
      entityType: z.enum(["safetyReport", "hazard", "riskAssessment"]),
      op: z.enum(["CREATE", "UPDATE", "DELETE"]),
      payload: z.unknown(),
      clientUpdatedAt: z.coerce.date(),
      baseVersion: z.string().optional()
      // server updatedAt seen when the client last read
    });
    SyncBatchSchema = z.object({
      deviceId: z.string().min(8).max(64),
      items: z.array(SyncItemSchema).max(100)
    });
  }
});

// packages/shared/src/pricing.ts
function bandForFleet(aircraft) {
  const byId = (id) => BANDS.find((b) => b.id === id);
  if (!Number.isFinite(aircraft) || aircraft < 1) return byId("single");
  if (aircraft === 1) return byId("single");
  if (aircraft <= 9) return byId("small");
  return byId("fleet");
}
var BANDS, EVERY_BAND_INCLUDES, TRIAL_DAYS, COMMITMENTS, PRICING_STILL_OPEN;
var init_pricing = __esm({
  "packages/shared/src/pricing.ts"() {
    "use strict";
    BANDS = Object.freeze([
      Object.freeze({
        id: "starter",
        name: "Starter",
        fleet: "1 or 2, RPAS or a single heliport",
        usdMonthly: 39,
        who: "A drone operator, a heliport, or a maintenance organisation serving one \u2014 captured by Annex 19 Amendment 2 and building an SMS from nothing.",
        adds: "Every Annex 19 element, same as every other band. What is smaller is the operation, not the obligation."
      }),
      Object.freeze({
        id: "single",
        name: "Single aircraft",
        fleet: "1 aircraft",
        usdMonthly: 79,
        who: "An owner-operator, a flight school with one type, a survey outfit."
      }),
      Object.freeze({
        id: "small",
        name: "Small operator",
        fleet: "2 to 9 aircraft",
        usdMonthly: 239,
        who: "The charter, medevac and survey operators this product was built for."
      }),
      Object.freeze({
        id: "fleet",
        name: "Fleet",
        fleet: "10 or more aircraft",
        usdMonthly: 549,
        who: "A scheduled operator, or a group holding several AOCs.",
        adds: "The export in a scheduled batch, and a second AOC priced rather than assumed.",
        perExtraAocUsdMonthly: 149
      })
    ]);
    EVERY_BAND_INCLUDES = Object.freeze([
      "Unlimited people filing reports \u2014 always, on every band.",
      "Unlimited reports, hazards, risk assessments and corrective actions.",
      "Offline filing on any handset, with the report held until there is signal.",
      "The operator's own copy of its whole record, exportable at any time.",
      "Every Annex 19 element the product covers, with no element behind a tier."
    ]);
    TRIAL_DAYS = 60;
    COMMITMENTS = Object.freeze([
      `${TRIAL_DAYS} days to try it, with no card and no limit on what you file \u2014 and extended on request if you are part way round your first hazard. Taking one all the way round the loop is the only way to judge an SMS, and we would rather give you the time than have you decide on half of it.`,
      "Your people file for free, always. There is no seat to buy, so there is no version of this where leaving the line crew out saves you money.",
      "If a subscription ever lapses, your people can still file and you can still export your entire record. The safety office tools pause; the reporting never does.",
      "The record is yours on the way out as well as the way in \u2014 every report, hazard, assessment and action, exportable at any time, in a format you can read without us.",
      "Every Annex 19 element this product covers is on every band. Nothing regulatory sits behind a higher tier."
    ]);
    PRICING_STILL_OPEN = Object.freeze([
      "The collection rail, and therefore the shilling price. Nothing on the site takes money yet; an operator starts a trial and is invoiced when the rail exists."
    ]);
  }
});

// packages/shared/src/subscription.ts
function trialEndsFrom(startedOn) {
  return new Date(startedOn.getTime() + TRIAL_DAYS * DAY_MS);
}
function stateOn(dates, asOf) {
  const now = asOf.getTime();
  const paid = dates.paidThrough?.getTime() ?? null;
  if (paid !== null) {
    if (now <= paid) return "ACTIVE";
    return now <= paid + GRACE_DAYS * DAY_MS ? "GRACE" : "LAPSED";
  }
  return now <= dates.trialEndsOn.getTime() ? "TRIAL" : "LAPSED";
}
function allows(state, capability) {
  if (state !== "LAPSED") return true;
  return SURVIVES_LAPSE[capability];
}
function daysUntilChange(dates, asOf) {
  const paid = dates.paidThrough?.getTime() ?? null;
  const edge = paid !== null ? paid + (asOf.getTime() > paid ? GRACE_DAYS * DAY_MS : 0) : dates.trialEndsOn.getTime();
  return Math.ceil((edge - asOf.getTime()) / DAY_MS);
}
var GRACE_DAYS, DAY_MS, ALL_CAPABILITIES, SURVIVES_LAPSE;
var init_subscription = __esm({
  "packages/shared/src/subscription.ts"() {
    "use strict";
    init_pricing();
    GRACE_DAYS = 14;
    DAY_MS = 864e5;
    ALL_CAPABILITIES = Object.freeze([
      /** A reporter filing. */
      "FILE_REPORT",
      /** An operator reading or exporting its own record. */
      "READ_OWN_RECORD",
      "EXPORT_OWN_RECORD",
      /** The safety office's working surfaces. This is the product. */
      "TRIAGE",
      "EDIT_REGISTER",
      "RECORD_INDICATOR_PERIOD",
      "GENERATE_DOCUMENT"
    ]);
    SURVIVES_LAPSE = Object.freeze({
      FILE_REPORT: true,
      READ_OWN_RECORD: true,
      EXPORT_OWN_RECORD: true,
      TRIAGE: false,
      EDIT_REGISTER: false,
      RECORD_INDICATOR_PERIOD: false,
      GENERATE_DOCUMENT: false
    });
  }
});

// apps/api/src/deident.ts
function deIdentify(narrative) {
  let text2 = narrative;
  const removed = {};
  for (const { category, pattern, replacement, keep } of DEIDENT_PATTERNS) {
    pattern.lastIndex = 0;
    let count = 0;
    text2 = text2.replace(pattern, (match) => {
      if (keep?.(match)) return match;
      count++;
      return replacement;
    });
    if (count > 0) removed[category] = (removed[category] ?? 0) + count;
  }
  const residual = findResidual(text2);
  return { text: text2, removed, residual, cleanByPattern: residual.length === 0 };
}
function findResidual(text2) {
  const found = [];
  const seen = /* @__PURE__ */ new Set();
  const push = (value, reason) => {
    const key = `${reason}:${value}`;
    if (seen.has(key)) return;
    seen.add(key);
    found.push({ text: value, reason });
  };
  for (const m of text2.matchAll(/\b([A-Z][a-z]{2,})\s+([A-Z][a-z]{2,})\b/g)) {
    const first = m[1];
    const second = m[2];
    if (!first || !second) continue;
    if (COMMON_CAPITALISED.has(first) || COMMON_CAPITALISED.has(second)) continue;
    push(m[0], "looks like a personal name");
  }
  for (const m of text2.matchAll(/\b([A-Z][a-z]{3,})\b/g)) {
    const word = m[1];
    if (!word) continue;
    if (COMMON_CAPITALISED.has(word)) continue;
    if (found.some((f) => f.text.includes(word))) continue;
    push(word, "unrecognised capitalised word \u2014 may be a surname or place");
  }
  for (const m of text2.matchAll(/\b\d{6,}\b/g)) {
    push(m[0], "long numeric string \u2014 may be a licence, staff or phone number");
  }
  for (const m of text2.matchAll(/\bI\s+was\s+the\s+only\s+\w+/gi)) {
    push(m[0], "self-identifying by uniqueness of role \u2014 no scrubber can fix this");
  }
  return found;
}
var NOT_AN_IDENTIFIER, NUMERIC_LEADING_PREFIXES, REGISTRATION_PREFIXES, REG_ALTERNATION, DEIDENT_PATTERNS, COMMON_CAPITALISED;
var init_deident = __esm({
  "apps/api/src/deident.ts"() {
    "use strict";
    init_src();
    NOT_AN_IDENTIFIER = /* @__PURE__ */ new Set([
      /* THE SAFETY-MANAGEMENT VOCABULARY, from the KCAA glossary.
           Read from packages/shared/src/glossary.ts rather than retyped, so
           the redactor and the interface cannot disagree about what a word is.
      
           These matter more than they look. "AOC", "SMS", "SPI", "FDA",
           "ERP", "CVR" and "FDR" are all two-to-three capital letters, which
           is exactly the shape of a flight-number prefix — so without this,
           "the AOC holder was notified" redacts to "the [FLT] holder was
           notified", and the sentence a safety office needs is gone. The
           de-identifier is supposed to remove who wrote it, not what it says.
      
           Spread FIRST so a duplicate below is harmless. */
      ...Object.keys(SMS_ACRONYMS),
      // Aerodrome and approach
      "RWY",
      "TWY",
      "SID",
      "STAR",
      "ILS",
      "LOC",
      "GS",
      "VOR",
      "NDB",
      "DME",
      "GP",
      "PAPI",
      "VASI",
      "ALS",
      "RCC",
      "PCN",
      "ACN",
      "TORA",
      "TODA",
      "ASDA",
      "LDA",
      // Altitude, pressure, performance
      "FL",
      "MSL",
      "AGL",
      "AAL",
      "QNH",
      "QFE",
      "QFF",
      "ISA",
      "OAT",
      "MDA",
      "DA",
      "DH",
      "MDH",
      "TAS",
      "IAS",
      "CAS",
      "GS",
      "MTOW",
      "MLW",
      "ZFW",
      "TOW",
      "LDW",
      "VR",
      "VI",
      "V1",
      "V2",
      "VREF",
      "VMO",
      "MMO",
      "ROC",
      "ROD",
      // Visibility and weather
      "RVR",
      "CAVOK",
      "TAF",
      "ATIS",
      "METAR",
      "SIGMET",
      "AIRMET",
      "CB",
      "TCU",
      "TS",
      // Systems and warnings
      "APU",
      "ECAM",
      "EICAS",
      "FMS",
      "FMC",
      "MCP",
      "TCAS",
      "RA",
      "TA",
      "GPWS",
      "EGPWS",
      "XPDR",
      "SSR",
      "ADS",
      "CPDLC",
      "IRS",
      "ADC",
      "AOA",
      "EGT",
      "ITT",
      "RPM",
      "N1",
      "N2",
      "EPR",
      "FF",
      "CG",
      // Documents and procedures
      "MEL",
      "CDL",
      "QRH",
      "SOP",
      "AFM",
      "FCOM",
      "AMM",
      "IPC",
      "SB",
      "AD",
      "EO",
      "ATA",
      "OM",
      "CAME",
      "MOE",
      "CAP",
      "AC",
      "AIC",
      "AIP",
      // Time and ops
      "ETA",
      "ETD",
      "ATD",
      "EOBT",
      "TOBT",
      "CTOT",
      "STD",
      "STA",
      "PAX",
      "ULD",
      "FOD",
      "PPE",
      "GSE",
      "PBB",
      "GPU",
      "ACU",
      // Regulatory
      "CAT",
      "LVP",
      "LVO",
      "RVSM",
      "RNP",
      "RNAV",
      "PBN",
      "MNPS",
      "ETOPS",
      "EDTO",
      // Units
      "KG",
      "LB",
      "FT",
      "NM",
      "KM",
      "KT",
      "KTS",
      "HPA",
      "INHG",
      "USG",
      "LTR",
      "DEG"
    ]);
    NUMERIC_LEADING_PREFIXES = /* @__PURE__ */ new Set(["60"]);
    REGISTRATION_PREFIXES = [
      "5Y",
      // Kenya — the State of Registry
      "9U",
      // Burundi
      "ET",
      // Ethiopia
      "5Z",
      // Kenya, earlier allocation — still on legacy records
      "9S",
      // DR Congo
      "9Q",
      // DR Congo
      "ST",
      // Sudan
      "5A",
      // Libya
      "60"
      // Somalia
    ];
    REG_ALTERNATION = REGISTRATION_PREFIXES.map((p) => p.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join("|");
    DEIDENT_PATTERNS = [
      // Registrations: 5Y-ABC, 5YABC, 9XR-AB, 60-XYZ.
      //
      // A space separator is NOT accepted. "5Y ABC" is a rarer way to write
      // a registration than "60 KTS" is to write a speed, and the space form
      // cost more in false positives than it bought in coverage.
      {
        category: "REG",
        pattern: new RegExp(`\\b(?:${REG_ALTERNATION})-?[A-Z]{2,4}\\b`, "g"),
        replacement: "[REG]",
        keep: (m) => {
          const prefix = REGISTRATION_PREFIXES.find((p) => m.startsWith(p));
          return prefix !== void 0 && NUMERIC_LEADING_PREFIXES.has(prefix) && !m.includes("-");
        }
      },
      // Flight numbers: two or three letters then 1-4 digits.
      //
      // The letters must not be an aviation abbreviation — see
      // NOT_AN_IDENTIFIER above for what this guard is worth.
      {
        category: "FLT",
        pattern: /\b([A-Z]{2,3})\s?(\d{1,4})\b/g,
        replacement: "[FLT]",
        keep: (m) => {
          const letters = /^[A-Z]{2,3}/.exec(m)?.[0];
          return letters === void 0 || NOT_AN_IDENTIFIER.has(letters);
        }
      },
      // ISO dates and common written forms.
      { category: "DATE", pattern: /\b\d{4}-\d{2}-\d{2}\b/g, replacement: "[DATE]" },
      { category: "DATE", pattern: /\b\d{1,2}[/.]\d{1,2}[/.]\d{2,4}\b/g, replacement: "[DATE]" },
      {
        category: "DATE",
        pattern: /\b\d{1,2}\s+(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.?\s+\d{2,4}\b/gi,
        replacement: "[DATE]"
      },
      /* A WRITTEN DATE WITH NO YEAR. "on 14 March", "March 14".
           The pattern above required a year, so "I raised it with the Chief
           Pilot on 14 March" kept its date — and a date is one of the
           sharpest identifiers in a small operator, because it narrows a
           shift roster to the two or three people who were on it. Found by a
           test asserting a reporter's recommendation had been scrubbed and
           watching the name go while the date stayed.
      
           Both orders, because reporters write both. */
      {
        category: "DATE",
        pattern: /\b\d{1,2}(?:st|nd|rd|th)?\s+(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.?(?!\s+\d)/gi,
        replacement: "[DATE]"
      },
      {
        category: "DATE",
        pattern: /\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.?\s+\d{1,2}(?:st|nd|rd|th)?\b(?!\s*[:.]\d)/gi,
        replacement: "[DATE]"
      },
      /* A BARE WEEKDAY. "on Tuesday", "the Friday night shift".
           Weaker than a date and still a roster narrower on an operation with
           one aircraft and a six-person crew list.
      
           FULL NAMES ONLY, and this is the whole point of the rule. The first
           version accepted the three-letter abbreviations case-insensitively,
           which is how it managed to redact these:
      
             "The aircraft SAT on stand 4 for two hours."
             "The SUN was low and glare affected the approach."
             "SUN glare on short final made the PAPI hard to read."
             "The tug was WED to the nose gear."
      
           Sat, Sun, Wed and Mar are ordinary English words, and "sun glare on
           short final" is one of the most common sentences in an approach
           report. This module's own header says over-scrubbing does not fail
           safe — it destroys the only reason the report was shared, while
           looking like caution — and the abbreviation list did exactly that
           within an hour of being written.
      
           "Monday" is never another word. "Mon" is. So: full names, and a
           reporter who writes "Tue" keeps their Tuesday, which is the safe
           direction to be wrong in. */
      {
        category: "DATE",
        pattern: /\b(?:Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)\b/gi,
        replacement: "[DAY]"
      },
      // Zulu / local times, which narrow a shift roster to one crew.
      { category: "TIME", pattern: /\b(?:[01]\d|2[0-3])[:.]?[0-5]\d\s?(?:Z|UTC|hrs?|L)\b/gi, replacement: "[TIME]" },
      // Phone numbers across the EAC country codes, not Kenya alone.
      {
        category: "PHONE",
        pattern: /(?:\+?(?:254|256|255|250|257|251)|\b0)\s?7\d{2}[\s-]?\d{3}[\s-]?\d{3}\b/g,
        replacement: "[PHONE]"
      },
      { category: "PHONE", pattern: /\+\d{1,3}[\s-]?\d[\d\s-]{6,13}\d\b/g, replacement: "[PHONE]" },
      { category: "EMAIL", pattern: /[\w.+-]+@[\w-]+\.[\w.]+/g, replacement: "[EMAIL]" },
      { category: "URL", pattern: /\bhttps?:\/\/\S+/gi, replacement: "[URL]" },
      // Geographic coordinates — a lat/long fixes an event to one approach.
      {
        category: "COORD",
        pattern: /\b\d{1,3}[°º]\s?\d{1,2}['′]\s?\d{1,2}(?:\.\d+)?["″]?\s?[NSEW]\b/g,
        replacement: "[COORD]"
      },
      // Licence and staff numbers.
      { category: "ID", pattern: /\b(?:licen[cs]e|lic|staff|employee|emp|badge)[\s.#:-]*[A-Z0-9-]{3,}\b/gi, replacement: "[ID]" },
      // Titled names — the original pattern, widened.
      {
        category: "CREW",
        pattern: /\b(?:Capt(?:ain)?|F\/?O|First\s+Officer|S\/?O|Eng(?:ineer)?|Tech(?:nician)?|Mr|Mrs|Ms|Dr|Prof|AME|LAE|ATCO|Controller|Dispatcher|Purser|CSD|FA)\.?\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+){0,2}\b/g,
        replacement: "[CREW]"
      },
      // Names introduced by a role phrase: "the captain, John Otieno".
      {
        category: "NAME",
        pattern: /\b(?:named|called|reported\s+by|filed\s+by|signed\s+by|operated\s+by|flown\s+by|handled\s+by)\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+){0,2}\b/g,
        replacement: "[NAME]"
      }
    ];
    COMMON_CAPITALISED = /* @__PURE__ */ new Set([
      "The",
      "A",
      "An",
      "I",
      "We",
      "It",
      "He",
      "She",
      "They",
      "This",
      "That",
      "There",
      "On",
      "In",
      "At",
      "As",
      "After",
      "Before",
      "During",
      "When",
      "While",
      "Then",
      "Aircraft",
      "Airport",
      "Approach",
      "Tower",
      "Ground",
      "Apron",
      "Ramp",
      "Runway",
      "Taxiway",
      "Gate",
      "Stand",
      "Flight",
      "Crew",
      "Captain",
      "Engineer",
      "Officer",
      "Company",
      "Operations",
      "Maintenance",
      "Safety",
      "Security",
      "Cabin",
      "Cockpit",
      "ATC",
      "ATIS",
      "METAR",
      "NOTAM",
      "PIC",
      "MEL",
      "QRH",
      "SOP",
      "TCAS",
      "GPWS",
      "EGPWS",
      "FOD",
      "PPE",
      "VFR",
      "IFR",
      "VMC",
      "IMC",
      "RVR",
      "QNH",
      "QFE",
      "Monday",
      "Tuesday",
      "Wednesday",
      "Thursday",
      "Friday",
      "Saturday",
      "Sunday",
      "January",
      "February",
      "March",
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December",
      "REG",
      "FLT",
      "DATE",
      "TIME",
      "PHONE",
      "EMAIL",
      "CREW",
      "NAME",
      "ID",
      "URL",
      "COORD",
      // Weather, terrain and ops words that recur in narratives and are not
      // names. Without these the residual list fills with "Wind", "Rain",
      // "Left", "Right" — and a reviewer who scrolls past forty false
      // positives stops reading the one that matters.
      "Wind",
      "Rain",
      "Snow",
      "Ice",
      "Fog",
      "Mist",
      "Cloud",
      "Turbulence",
      "Windshear",
      "Left",
      "Right",
      "Centre",
      "Center",
      "North",
      "South",
      "East",
      "West",
      "Takeoff",
      "Landing",
      "Departure",
      "Arrival",
      "Descent",
      "Climb",
      "Cruise",
      "Taxi",
      "Pushback",
      "Boarding",
      "Turnaround",
      "Sector",
      "Stand",
      "Bay",
      "Engine",
      "Brake",
      "Brakes",
      "Flap",
      "Flaps",
      "Gear",
      "Rudder",
      "Aileron",
      "Elevator",
      "Spoiler",
      "Thrust",
      "Reverser",
      "Autopilot",
      "Autothrottle",
      "Checklist",
      "Briefing",
      "Clearance",
      "Handover",
      "Shift",
      "Roster",
      "Duty",
      "Fuel",
      "Cargo",
      "Baggage",
      "Freight",
      "Load",
      "Weight",
      "Balance",
      "Report",
      "Reported",
      "Incident",
      "Occurrence",
      "Hazard",
      "Event",
      "Finding",
      "Manual",
      "Procedure",
      "Policy",
      "Training",
      "Licence",
      "License",
      "Rating",
      "Company",
      "Operator",
      "Station",
      "Base",
      "Line",
      "Hangar",
      "Workshop"
    ]);
  }
});

// apps/api/src/audit-material.ts
function canonicalJson(value) {
  return JSON.stringify(sortKeys(value));
}
function sortKeys(value) {
  if (Array.isArray(value)) return value.map(sortKeys);
  if (value && typeof value === "object" && !(value instanceof Date)) {
    return Object.fromEntries(
      Object.keys(value).sort().map((k) => [k, sortKeys(value[k])])
    );
  }
  return value;
}
function auditMaterial(row) {
  return [
    row.orgId,
    row.userId ?? "",
    row.action,
    row.entityType,
    row.entityId,
    canonicalJson(row.detail ?? null),
    row.prevHash,
    row.createdAt.toISOString()
  ].join("|");
}
var init_audit_material = __esm({
  "apps/api/src/audit-material.ts"() {
    "use strict";
  }
});

// apps/api/src/core.ts
import { createHash, createHmac, randomBytes } from "node:crypto";
import jwt from "jsonwebtoken";
import argon2 from "argon2";
import { PrismaClient } from "@prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";
import { getConnectionString, MissingDatabaseConnectionError } from "@netlify/database";
function requireEnv(name) {
  const v = process.env[name];
  if (!v) {
    console.error(`FATAL: missing env ${name}`);
    process.exit(1);
  }
  return v;
}
function databaseUrl() {
  let managed;
  try {
    managed = getConnectionString();
  } catch (error) {
    if (!(error instanceof MissingDatabaseConnectionError)) throw error;
  }
  const explicit = process.env["DATABASE_URL"];
  const fromExtension = process.env["SUPABASE_DATABASE_URL"];
  const url = managed ?? explicit ?? fromExtension;
  if (!url) {
    fatal(
      "no database connection string.\n  Connect Netlify Database or set DATABASE_URL to a Postgres URI."
    );
  }
  if (!/^postgres(ql)?:\/\//.test(url)) {
    const which = managed ? "NETLIFY_DB_URL" : explicit ? "DATABASE_URL" : "SUPABASE_DATABASE_URL";
    fatal(
      `${which} is not a Postgres connection string.
  Got a URL beginning "${url.slice(0, url.indexOf(":") + 3)}".
` + (which === "SUPABASE_DATABASE_URL" ? "  The Netlify Supabase extension sets SUPABASE_DATABASE_URL to the\n  project's REST API base, not to a database connection string \u2014\n  it is meant for createClient(), which this API does not use.\n  Set DATABASE_URL explicitly; it takes precedence.\n" : "") + "  See docs/06-DEPLOYMENT.md."
    );
  }
  return url;
}
function fatal(message) {
  console.error(`FATAL: ${message}`);
  process.exit(1);
}
async function verifyPassword(hash, pw) {
  return argon2.verify(hash, pw);
}
function issueAccessToken(c) {
  return jwt.sign({ ...c, typ: "access" }, ENV.JWT_SECRET, {
    algorithm: "HS256",
    expiresIn: ENV.ACCESS_TTL,
    issuer: "usalamasms"
  });
}
async function issueRefreshToken(userId) {
  const raw = randomBytes(48).toString("base64url");
  await prisma.refreshToken.create({
    data: {
      userId,
      tokenHash: hmac(raw),
      expiresAt: new Date(Date.now() + ENV.REFRESH_TTL_MS)
    }
  });
  return raw;
}
function sha256(s) {
  return createHash("sha256").update(s, "utf8").digest("hex");
}
function hmac(s) {
  return createHmac("sha256", ENV.JWT_SECRET).update(s, "utf8").digest("hex");
}
async function authenticate(req, reply) {
  const header = req.headers.authorization;
  if (!header?.startsWith("Bearer ")) {
    reply.code(401).send({ error: "authentication_required" });
    return;
  }
  try {
    const claims = jwt.verify(header.slice(7), ENV.JWT_SECRET, {
      algorithms: ["HS256"],
      issuer: "usalamasms"
    });
    if (claims.typ !== "access") throw new Error("wrong token type");
    req.auth = claims;
  } catch {
    reply.code(401).send({ error: "invalid_token" });
  }
}
function requirePermission(p) {
  return async (req, reply) => {
    if (!req.auth) {
      reply.code(401).send({ error: "authentication_required" });
      return;
    }
    if (!can(req.auth.role, p)) {
      reply.code(403).send({ error: "forbidden", permission: p });
      return;
    }
  };
}
function requireEntitlement(capability) {
  return async (req, reply) => {
    if (!req.auth) {
      reply.code(401).send({ error: "authentication_required" });
      return;
    }
    const org = await prisma.org.findUnique({
      where: { id: req.auth.org },
      /* fleetSize comes back so the refusal can name a PRICE rather
         than a policy. See the 402 body below. */
      select: { trialEndsOn: true, paidThrough: true, createdAt: true, fleetSize: true }
    });
    if (!org) {
      reply.code(401).send({ error: "invalid_token" });
      return;
    }
    const state = stateOn(
      {
        trialEndsOn: org.trialEndsOn ?? trialEndsFrom(org.createdAt),
        paidThrough: org.paidThrough
      },
      /* @__PURE__ */ new Date()
    );
    if (allows(state, capability)) return;
    const band = typeof org.fleetSize === "number" && org.fleetSize > 0 ? bandForFleet(org.fleetSize) : null;
    reply.code(402).send({
      error: "subscription_lapsed",
      state,
      capability,
      /* Named rather than implied. An operator meeting this response
         needs to know immediately that their people can still report
         and their record is still theirs. */
      stillAvailable: ["FILE_REPORT", "READ_OWN_RECORD", "EXPORT_OWN_RECORD"],
      /* Null rather than a default band. See above. */
      band: band ? { id: band.id, name: band.name, fleet: band.fleet, usdMonthly: band.usdMonthly } : null,
      fleetSize: org.fleetSize ?? null
    });
  };
}
function tenantWhere(req) {
  if (!req.auth) throw new Error("tenantWhere called before authenticate");
  return { orgId: req.auth.org };
}
async function appendAudit(params) {
  await prisma.$transaction(async (tx) => {
    const orgKey = lockKeyFor(params.orgId);
    await tx.$executeRaw`SELECT pg_advisory_xact_lock(${AUDIT_LOCK_NAMESPACE}::int, ${orgKey}::int)`;
    const last = await tx.auditLog.findFirst({
      where: { orgId: params.orgId },
      orderBy: { seq: "desc" },
      select: { hash: true }
    });
    const prevHash = last?.hash ?? GENESIS;
    const createdAt = /* @__PURE__ */ new Date();
    await tx.auditLog.create({
      data: {
        orgId: params.orgId,
        userId: params.userId,
        action: params.action,
        entityType: params.entityType,
        entityId: params.entityId,
        detail: params.detail ?? void 0,
        createdAt,
        prevHash,
        hash: sha256(
          auditMaterial({ ...params, detail: params.detail ?? null, prevHash, createdAt })
        )
      }
    });
  });
}
function lockKeyFor(orgId) {
  return parseInt(sha256(orgId).slice(0, 8), 16) | 0;
}
async function verifyAuditChain(orgId) {
  const PAGE = 1e3;
  let prev = GENESIS;
  let checked = 0;
  let cursor;
  let total = 0;
  for (; ; ) {
    const rows = await prisma.auditLog.findMany({
      where: { orgId, ...cursor === void 0 ? {} : { seq: { gt: cursor } } },
      orderBy: { seq: "asc" },
      take: PAGE
    });
    if (rows.length === 0) break;
    total += rows.length;
    cursor = rows[rows.length - 1].seq;
    const verdict = verifyPage(rows, prev, checked);
    if (verdict.failure) return verdict.failure;
    prev = verdict.prev;
    checked = verdict.checked;
    if (rows.length < PAGE) break;
  }
  if (total === 0) {
    return { ok: false, rowsChecked: 0 };
  }
  return { ok: true, rowsChecked: checked };
}
function verifyPage(rows, startPrev, startChecked) {
  let prev = startPrev;
  let checked = startChecked;
  for (const r of rows) {
    if (r.prevHash !== prev) {
      return { prev, checked, failure: { ok: false, rowsChecked: checked, brokenLinkAtSeq: String(r.seq) } };
    }
    const expected = sha256(
      auditMaterial({
        orgId: r.orgId,
        userId: r.userId,
        action: r.action,
        entityType: r.entityType,
        entityId: r.entityId,
        detail: r.detail,
        prevHash: r.prevHash,
        createdAt: r.createdAt
      })
    );
    if (expected !== r.hash) {
      return {
        prev,
        checked,
        failure: { ok: false, rowsChecked: checked, contentAlteredAtSeq: String(r.seq) }
      };
    }
    prev = r.hash;
    checked++;
  }
  return { prev, checked };
}
async function deIdentifyVcr(reportId, reviewerId, options = {}) {
  const result = await prisma.$transaction(async (tx) => {
    const report = await tx.safetyReport.findUniqueOrThrow({ where: { id: reportId } });
    if (report.type !== "VCR") throw new Error("de-identification pipeline is VCR-only");
    if (report.isDeIdentified) throw new Error("report is already de-identified");
    const SEPARATOR = "\n\n\0RECOMMENDATION\0\n\n";
    const combined = report.reporterRecommendation ? `${report.narrative}${SEPARATOR}${report.reporterRecommendation}` : report.narrative;
    const scrubbed = deIdentify(combined);
    if (scrubbed.residual.length > 0 && !options.reviewerAcceptedResidual) {
      throw new ResidualIdentifiersError(scrubbed.residual);
    }
    const [scrubbedNarrative, scrubbedRecommendation] = scrubbed.text.split(SEPARATOR);
    await tx.safetyReport.update({
      where: { id: reportId },
      data: {
        deIdentifiedNarrative: scrubbedNarrative ?? scrubbed.text,
        narrative: "[REDACTED \u2014 de-identified copy distributed]",
        // Replaced rather than nulled: a missing recommendation and a
        // redacted one are different facts, and the second is the one
        // a reader of the bulletin should be told.
        ...report.reporterRecommendation ? { reporterRecommendation: scrubbedRecommendation ?? "[REDACTED]" } : {},
        reporterId: null,
        // hard removal, not encryption
        isDeIdentified: true,
        deIdentifiedAt: /* @__PURE__ */ new Date()
      }
    });
    await appendAuditTx(tx, {
      orgId: report.orgId,
      userId: reviewerId,
      action: "report.deidentify",
      entityType: "SafetyReport",
      entityId: reportId,
      detail: {
        removed: scrubbed.removed,
        residualCount: scrubbed.residual.length,
        reviewerAcceptedResidual: options.reviewerAcceptedResidual ?? false
      }
    });
    return { residual: scrubbed.residual };
  });
  return result;
}
async function appendAuditTx(tx, params) {
  await tx.$executeRaw`SELECT pg_advisory_xact_lock(${AUDIT_LOCK_NAMESPACE}::int, ${lockKeyFor(params.orgId)}::int)`;
  const last = await tx.auditLog.findFirst({
    where: { orgId: params.orgId },
    orderBy: { seq: "desc" },
    select: { hash: true }
  });
  const prevHash = last?.hash ?? GENESIS;
  const createdAt = /* @__PURE__ */ new Date();
  await tx.auditLog.create({
    data: {
      orgId: params.orgId,
      userId: params.userId,
      action: params.action,
      entityType: params.entityType,
      entityId: params.entityId,
      detail: params.detail ?? void 0,
      createdAt,
      prevHash,
      hash: sha256(
        auditMaterial({ ...params, detail: params.detail ?? null, prevHash, createdAt })
      )
    }
  });
}
var ENV, prisma, GENESIS, AUDIT_LOCK_NAMESPACE, ResidualIdentifiersError;
var init_core = __esm({
  "apps/api/src/core.ts"() {
    "use strict";
    init_src();
    init_pricing();
    init_subscription();
    init_deident();
    init_audit_material();
    init_audit_material();
    init_deident();
    ENV = {
      JWT_SECRET: requireEnv("JWT_SECRET"),
      // Read HERE, at startup, not lazily inside reporterDupToken(). The old
      // code called requireEnv() from inside a request handler, so a missing
      // salt in production did not fail the deploy — it called process.exit(1)
      // in the middle of serving a request, killing the process on the first
      // VCR that happened to arrive. Fail fast means fail at boot.
      DEIDENT_SALT: requireEnv("DEIDENT_SALT"),
      ACCESS_TTL: "15m",
      REFRESH_TTL_MS: 30 * 24 * 3600 * 1e3
    };
    prisma = new PrismaClient({
      adapter: new PrismaPg({ connectionString: databaseUrl() })
    });
    GENESIS = "0".repeat(64);
    AUDIT_LOCK_NAMESPACE = 21313;
    ResidualIdentifiersError = class extends Error {
      constructor(residual) {
        super(
          `de-identification left ${residual.length} possible identifier(s); a reviewer must confirm before distribution`
        );
        this.residual = residual;
        this.name = "ResidualIdentifiersError";
      }
      residual;
    };
  }
});

// apps/api/src/routes.sync.ts
import { Prisma as Prisma2 } from "@prisma/client";
async function syncRoutes(app) {
  app.post("/api/v1/sync/batch", {
    // Authentication only. Authorisation is per item, below.
    preHandler: [authenticate],
    config: { rateLimit: { max: 60, timeWindow: "1 minute" } }
  }, async (req, reply) => {
    const parsed = SyncBatchSchema.safeParse(req.body);
    if (!parsed.success) return reply.code(400).send({ error: "invalid_batch" });
    const { deviceId, items } = parsed.data;
    const auth = req.auth;
    const results = [];
    for (const item of items) {
      const needed = REQUIRED_PERMISSION[`${item.entityType}:${item.op}`];
      if (!needed || !can(auth.role, needed)) {
        results.push({ clientId: item.clientId, status: "forbidden" });
        continue;
      }
      const existing = await prisma.syncReceipt.findFirst({
        where: { clientId: item.clientId, orgId: auth.org, op: item.op }
      });
      if (existing) {
        results.push({ clientId: item.clientId, status: "duplicate" });
        continue;
      }
      if (item.entityType === "safetyReport" && item.op === "CREATE") {
        const body = CreateReportSchema.safeParse(item.payload);
        if (!body.success) {
          results.push({ clientId: item.clientId, status: "rejected" });
          continue;
        }
        const d = body.data;
        let created;
        try {
          created = await prisma.$transaction(async (tx) => {
            const report = await tx.safetyReport.create({
              data: {
                orgId: auth.org,
                clientId: d.clientId,
                type: d.type,
                title: d.title,
                narrative: d.narrative,
                reporterRecommendation: d.reporterRecommendation,
                occurredAt: d.occurredAt,
                // When the obligation started running. Defaulted to receipt
                // time — the earliest moment the server can actually prove
                // — and never to occurredAt. See packages/shared/src/
                // regulations.ts for why that distinction is the difference
                // between a 24-hour window and no window at all.
                awareAt: d.awareAt ?? /* @__PURE__ */ new Date(),
                jurisdiction: d.jurisdiction,
                location: d.location,
                aircraftType: d.aircraftType,
                phase: d.phase,
                hrcTags: d.hrcTags,
                /* THE DUTY THE REPORTER WAS TIRED ON, flattened out of the
                   nested block the wire carries. Nested on the request
                   because the fields are meaningless off a FATIGUE report
                   and the schema says so; flat in the table because the
                   fatigue picture aggregates across them and a JSON column
                   cannot be indexed or averaged without unpacking every
                   row. CreateReportSchema has already refused a block on
                   any other type, so no guard is needed here. */
                fatigueFlightTimeHours: d.fatigue?.flightTimeHours,
                fatigueDutyHours: d.fatigue?.dutyHours,
                fatigueRestBeforeHours: d.fatigue?.restBeforeHours,
                fatigueSectors: d.fatigue?.sectors,
                fatigueSleepPrior24: d.fatigue?.sleepPrior24Hours,
                fatigueStartLocalHour: d.fatigue?.startLocalHour,
                fatigueEndLocalHour: d.fatigue?.endLocalHour,
                fatigueSamnPerelli: d.fatigue?.samnPerelli,
                isAnonymous: d.isAnonymous,
                reporterId: d.isAnonymous ? null : auth.sub
                // NOTE: no regulatorDeadline column is written. Charter
                // rule 6 — regulatory status is computed from today's
                // date, never stored. A stored deadline is a deadline that
                // stays wrong after occurredAt is corrected, and after the
                // regulator changes the rule.
              }
            });
            await tx.syncReceipt.create({
              data: {
                clientId: item.clientId,
                orgId: auth.org,
                entityType: "safetyReport",
                op: "CREATE",
                ...d.isAnonymous ? { userId: null, deviceId: null } : { deviceId, userId: auth.sub }
              }
            });
            await appendAuditTx(tx, {
              orgId: auth.org,
              // Likewise: an audit entry naming the reporter of an
              // anonymous report defeats the anonymity it is meant to
              // protect. The action is recorded; the actor is not.
              userId: d.isAnonymous ? void 0 : auth.sub,
              action: "report.create.sync",
              entityType: "SafetyReport",
              entityId: report.id,
              detail: d.isAnonymous ? { type: d.type, anonymous: true } : { deviceId, type: d.type, anonymous: false }
            });
            return report;
          });
        } catch (err) {
          if (!(err instanceof Prisma2.PrismaClientKnownRequestError) || err.code !== "P2002") {
            throw err;
          }
          req.log.info(
            { clientId: item.clientId },
            "report already stored under this clientId \u2014 concurrent flush or a retried batch"
          );
          results.push({ clientId: item.clientId, status: "duplicate" });
          continue;
        }
        results.push({
          clientId: item.clientId,
          status: "applied",
          serverUpdatedAt: created.updatedAt.toISOString()
        });
        continue;
      }
      if (item.op === "UPDATE") {
        const current = await prisma.safetyReport.findFirst({
          where: { clientId: item.clientId, orgId: auth.org }
        });
        if (!current) {
          results.push({ clientId: item.clientId, status: "rejected" });
          continue;
        }
        if (item.baseVersion && item.baseVersion !== current.updatedAt.toISOString()) {
          try {
            await prisma.syncReceipt.create({
              data: {
                // A conflict receipt is a distinct event, not a second
                // receipt for the same clientId — suffixed so it cannot
                // collide with the idempotency key it describes.
                clientId: `${item.clientId}:conflict:${current.updatedAt.toISOString()}`,
                orgId: auth.org,
                entityType: item.entityType,
                op: "UPDATE",
                conflict: true,
                resolution: "server_wins",
                // ======================================================
                // THE SAME ANONYMITY RULE AS THE CREATE PATH, and it was
                // missing here.
                //
                // The CREATE receipt above is careful: for an anonymous
                // report it stores a keyed device hash and nulls both
                // userId and deviceId. This receipt wrote userId and
                // deviceId unconditionally — under a clientId that
                // CONTAINS the anonymous report's own key as a prefix:
                //
                //     SELECT s."userId"
                //       FROM "SafetyReport" r
                //       JOIN "SyncReceipt"  s
                //         ON s."clientId" LIKE r."clientId" || ':conflict:%'
                //      WHERE r."isAnonymous"
                //
                // The comment on the CREATE path says a confidential
                // reporting system that can be un-anonymised by a join
                // is not a confidential reporting system, it is a list.
                // That was true of this row. The suffix meant the guard
                // test's exact-equality join could not see it, so the
                // control read as enforced while the side door stood
                // open — which is why that test now joins on a prefix.
                //
                // `current` is the row being updated, so its own
                // isAnonymous is the authority here rather than anything
                // the client sent.
                // ======================================================
                ...current.isAnonymous ? { userId: null, deviceId: null } : { deviceId, userId: auth.sub }
              }
            });
          } catch (err) {
            if (!(err instanceof Prisma2.PrismaClientKnownRequestError) || err.code !== "P2002") {
              throw err;
            }
            req.log.info(
              { clientId: item.clientId },
              "conflict receipt already recorded \u2014 retried batch after a lost response"
            );
          }
          results.push({
            clientId: item.clientId,
            status: "conflict",
            serverUpdatedAt: current.updatedAt.toISOString()
          });
          continue;
        }
        results.push({ clientId: item.clientId, status: "rejected" });
        continue;
      }
      if (item.entityType === "safetyReport" && item.op === "DELETE") {
        const current = await prisma.safetyReport.findFirst({
          where: { clientId: item.clientId, orgId: auth.org }
        });
        if (!current) {
          results.push({ clientId: item.clientId, status: "rejected" });
          continue;
        }
        if (current.retractedAt) {
          results.push({ clientId: item.clientId, status: "duplicate" });
          continue;
        }
        const mine = current.reporterId !== null && current.reporterId === auth.sub;
        if (!mine) {
          results.push({ clientId: item.clientId, status: "forbidden" });
          continue;
        }
        const reason = typeof item.payload?.reason === "string" ? String(item.payload.reason).trim().slice(0, 500) : null;
        try {
          await prisma.$transaction(async (tx) => {
            const claimed = await tx.safetyReport.updateMany({
              where: { id: current.id, orgId: auth.org, retractedAt: null },
              data: {
                retractedAt: /* @__PURE__ */ new Date(),
                retractedById: auth.sub,
                retractedReason: reason
              }
            });
            if (claimed.count === 0) return;
            await tx.syncReceipt.create({
              data: {
                clientId: `${item.clientId}:retracted`,
                orgId: auth.org,
                entityType: item.entityType,
                op: "DELETE",
                /* THE THIRD PLACE TO GET ANONYMITY WRONG, and the design
                   note says so in as many words. The conflict receipt
                   already got it wrong once, under a clientId carrying
                   the anonymous report's own key as a prefix. The
                   authority is the STORED row, never anything the client
                   sent. A retraction of an anonymous report cannot reach
                   here — the narrowing above refuses it — but the rule
                   is written rather than assumed, because the reason it
                   cannot is four lines away and could move. */
                ...current.isAnonymous ? { userId: null, deviceId: null } : { deviceId, userId: auth.sub }
              }
            });
            await appendAuditTx(tx, {
              orgId: auth.org,
              userId: auth.sub,
              action: "report.retracted",
              entityType: "SafetyReport",
              entityId: current.id,
              /* The reason is the reporter's own words about their own
                 correction, and it travels with the chain. What does NOT
                 travel is anything from the report itself. */
              detail: { hasReason: Boolean(reason) }
            });
          });
        } catch (err) {
          if (!(err instanceof Prisma2.PrismaClientKnownRequestError) || err.code !== "P2002") {
            throw err;
          }
          req.log.info(
            { clientId: item.clientId },
            "retraction receipt already recorded \u2014 retried batch after a lost response"
          );
        }
        results.push({ clientId: item.clientId, status: "applied" });
        continue;
      }
      results.push({ clientId: item.clientId, status: "rejected" });
    }
    if (results.length !== items.length) {
      req.log.error(
        { sent: items.length, returned: results.length },
        "sync batch produced fewer results than items \u2014 client outbox would stall"
      );
      return reply.code(500).send({ error: "incomplete_batch" });
    }
    return reply.send({ results });
  });
}
var REQUIRED_PERMISSION;
var init_routes_sync = __esm({
  "apps/api/src/routes.sync.ts"() {
    "use strict";
    init_src();
    init_core();
    REQUIRED_PERMISSION = {
      "safetyReport:CREATE": "report.create",
      "safetyReport:UPDATE": "report.triage",
      /* RETRACTION IS THE REPORTER'S OWN ACT, so it is report.create and not
         report.triage. The person who filed a hazard twice is the person who
         needs the first one to stop appearing, and requiring the safety
         office's permission would mean nobody can correct their own mistake
         without asking. The handler below narrows it further than the
         permission does — a reporter may retract what THEY filed, not what
         the operator filed. */
      "safetyReport:DELETE": "report.create",
      "hazard:CREATE": "hazard.manage",
      "hazard:UPDATE": "hazard.manage",
      "riskAssessment:CREATE": "risk.assess",
      "riskAssessment:UPDATE": "risk.assess"
    };
  }
});

// packages/shared/src/signup.ts
import { z as z2 } from "zod";
var SignupSchema;
var init_signup = __esm({
  "packages/shared/src/signup.ts"() {
    "use strict";
    init_regulations();
    SignupSchema = z2.object({
      /* The operator, as it appears on the certificate. Not "the company
         name": an AOC holder's legal name is what an inspector matches
         against, and the printed record carries it. */
      orgName: z2.string().trim().min(2).max(160),
      /* Optional because a new operator in certification does not have one
         yet, and refusing them an account until they do would exclude the
         customer who needs the SMS EARLIEST — the whole point of the
         certification pathway is that the SMS exists before the AOC. */
      aocNumber: z2.string().trim().max(60).optional(),
      jurisdiction: z2.enum(JURISDICTIONS).default("KE"),
      /** How many aircraft, which decides the pricing band and nothing else. */
      fleet: z2.number().int().min(1).max(2e3).optional(),
      /* ---- THE OPERATOR'S PROFILE, AND WHY IT IS ASKED HERE ----
       *
       * `fleet` is a number and answers what it costs. These three answer
       * what the safety office is looking at, and they are the
       * DENOMINATORS every rate this product computes has been missing.
       * "Four runway excursions" against two Caravans out of Wilson is a
       * different fact from four across a mixed turboprop fleet on the
       * northern network, and nothing could tell those apart.
       *
       * ASKED ONCE, AT THE ONE MOMENT SOMEBODY IS ALREADY DESCRIBING THEIR
       * OPERATION. A profile that has to be filled in later from a settings
       * screen is a profile that stays empty, and an empty denominator
       * makes every rate on every dashboard a count.
       *
       * ALL THREE OPTIONAL, AND THE ACCOUNT IS CREATED WITHOUT THEM. This
       * is the only unauthenticated route that writes, and the customer it
       * exists for is a safety manager evaluating the product on a Sunday
       * evening. A required multi-select between them and a working account
       * is a required field that loses the customer, not one that gets
       * answered — and the profile is worth more filled in honestly later
       * than guessed at now.
       *
       * VALIDATED AGAINST THE SHARED LISTS, so the columns group. Bounded
       * and de-duplicated because an unbounded array on an unauthenticated
       * route is an unbounded write. */
      fleetTypes: z2.array(z2.string().trim().max(16)).max(40).optional(),
      bases: z2.array(z2.string().trim().toUpperCase().max(8)).max(40).optional(),
      operationTypes: z2.array(z2.string().trim().toUpperCase().max(32)).max(10).optional(),
      name: z2.string().trim().min(2).max(120),
      email: z2.string().trim().toLowerCase().email(),
      password: z2.string().min(12)
    });
  }
});

// packages/shared/src/adrep.ts
function isValidAdrepValue(key, code) {
  const field = FIELD_BY_KEY.get(key);
  if (!field) return false;
  return field.options.some((o) => o.code === code);
}
var INJURY_LEVELS, AIRCRAFT_DAMAGE_LEVELS, LIGHT_CONDITIONS, MET_CONDITIONS, OPERATION_TYPES, ADREP_FIELDS, FIELD_BY_KEY;
var init_adrep = __esm({
  "packages/shared/src/adrep.ts"() {
    "use strict";
    INJURY_LEVELS = Object.freeze([
      { code: "NONE", label: "None", hint: "Nobody was hurt." },
      {
        code: "MINOR",
        label: "Minor",
        hint: "Somebody was hurt, below Annex 13's serious-injury definition."
      },
      {
        code: "SERIOUS",
        label: "Serious",
        hint: "Meets Annex 13's enumerated serious-injury definition \u2014 read it before coding this."
      },
      {
        code: "FATAL",
        label: "Fatal",
        hint: "A death within thirty days of the occurrence, which is Annex 13's counting convention."
      },
      {
        code: "UNKNOWN",
        label: "Not determined",
        hint: "Looked at and could not be established \u2014 which is not the same as not yet looked at."
      }
    ]);
    AIRCRAFT_DAMAGE_LEVELS = Object.freeze([
      { code: "NONE", label: "None", hint: "No damage to the aircraft." },
      {
        code: "MINOR",
        label: "Minor",
        hint: "Damage that Annex 13's exclusion list keeps out of 'substantial'."
      },
      {
        code: "SUBSTANTIAL",
        label: "Substantial",
        hint: "Adversely affects structural strength, performance or flight characteristics \u2014 read the exclusions."
      },
      {
        code: "DESTROYED",
        label: "Destroyed",
        hint: "Beyond repair, or the aircraft is missing and inaccessible."
      },
      {
        code: "UNKNOWN",
        label: "Not determined",
        hint: "Looked at and could not be established."
      }
    ]);
    LIGHT_CONDITIONS = Object.freeze([
      { code: "DAYLIGHT", label: "Daylight", hint: "Between sunrise and sunset." },
      {
        code: "TWILIGHT",
        label: "Twilight",
        hint: "Dawn or dusk \u2014 the transition either side of daylight."
      },
      { code: "NIGHT", label: "Night", hint: "Between the end of dusk and the start of dawn." },
      {
        code: "UNKNOWN",
        label: "Not determined",
        hint: "Looked at and could not be established."
      }
    ]);
    MET_CONDITIONS = Object.freeze([
      {
        code: "VMC",
        label: "VMC \u2014 visual",
        hint: "Visibility, cloud distance and ceiling at or better than the published minima."
      },
      {
        code: "IMC",
        label: "IMC \u2014 instrument",
        hint: "Below the minima specified for VMC."
      },
      {
        code: "UNKNOWN",
        label: "Not determined",
        hint: "Looked at and could not be established."
      }
    ]);
    OPERATION_TYPES = Object.freeze([
      {
        code: "CAT_SCHEDULED",
        label: "Commercial air transport \u2014 scheduled",
        hint: "A published timetable, or a series regular enough to be one, open to public booking."
      },
      {
        code: "CAT_NON_SCHEDULED",
        label: "Commercial air transport \u2014 non-scheduled",
        hint: "Charter and special flights for remuneration outside a timetable."
      },
      {
        code: "AERIAL_WORK",
        label: "Aerial work",
        hint: "The flight is the job \u2014 survey, patrol, spraying, search, photography."
      },
      {
        code: "TRAINING",
        label: "Flight instruction or training",
        hint: "Instructional flight, checking or a training detail."
      },
      {
        code: "GENERAL_AVIATION",
        label: "General aviation",
        hint: "Private or corporate flying that is none of the above."
      },
      {
        code: "STATE",
        label: "State flight",
        hint: "Military, customs, police or another State service."
      },
      {
        code: "UNKNOWN",
        label: "Not determined",
        hint: "Looked at and could not be established."
      }
    ]);
    ADREP_FIELDS = Object.freeze([
      {
        key: "injuryLevel",
        question: "Worst injury to any person",
        source: "ICAO Annex 13",
        options: INJURY_LEVELS
      },
      {
        key: "aircraftDamage",
        question: "Damage to the aircraft",
        source: "ICAO Annex 13",
        options: AIRCRAFT_DAMAGE_LEVELS
      },
      {
        key: "lightCondition",
        question: "Light at the time",
        source: "ADREP / ECCAIRS",
        options: LIGHT_CONDITIONS
      },
      {
        key: "metCondition",
        question: "Meteorological conditions",
        source: "ADREP / ECCAIRS",
        options: MET_CONDITIONS
      },
      {
        key: "operationType",
        question: "Type of operation",
        source: "ADREP / ECCAIRS",
        options: OPERATION_TYPES
      }
    ]);
    FIELD_BY_KEY = new Map(ADREP_FIELDS.map((f) => [f.key, f]));
  }
});

// packages/shared/src/reset.ts
import { z as z3 } from "zod";
var RESET_TTL_MINUTES, MIN_PASSWORD_LENGTH, ForgotSchema, ResetSchema, RESET_REQUESTED_ANSWER, RESET_REFUSED_ANSWER;
var init_reset = __esm({
  "packages/shared/src/reset.ts"() {
    "use strict";
    RESET_TTL_MINUTES = 60;
    MIN_PASSWORD_LENGTH = 12;
    ForgotSchema = z3.object({
      email: z3.string().trim().toLowerCase().email().max(320)
    });
    ResetSchema = z3.object({
      token: z3.string().trim().min(32).max(256),
      newPassword: z3.string().min(MIN_PASSWORD_LENGTH)
    });
    RESET_REQUESTED_ANSWER = `If that address belongs to an account here, a link to set a new password is on its way to it. The link lasts ${RESET_TTL_MINUTES} minutes and can be used once. Nothing about your account has changed yet.`;
    RESET_REFUSED_ANSWER = "That link cannot be used. It may have expired, or already been used, or been replaced by a newer one. Ask for another and use the most recent email.";
  }
});

// packages/shared/src/digest.ts
function worst(levels) {
  let best = null;
  for (const level of levels) {
    if (best === null || RANK[level] > RANK[best]) best = level;
  }
  return best;
}
function highest(items) {
  return worst(items.map((i) => i.urgency));
}
function soonest(days) {
  const known = days.filter((d) => d !== null);
  return known.length ? Math.min(...known) : null;
}
function digestFor(input) {
  const items = [];
  const deadlines = input.deadlines.filter((d) => DEADLINE_URGENCY[d.status] !== null);
  if (deadlines.length) {
    items.push({
      kind: "DEADLINE",
      urgency: worst(deadlines.map((d) => DEADLINE_URGENCY[d.status])),
      count: deadlines.length,
      soonestDays: soonest(deadlines.map((d) => d.daysLeft)),
      href: "/triage"
    });
  }
  const currencies = input.currencies.filter((c) => CURRENCY_URGENCY[c.state] !== null);
  if (currencies.length) {
    items.push({
      kind: "CURRENCY",
      urgency: worst(currencies.map((c) => CURRENCY_URGENCY[c.state])),
      count: currencies.length,
      soonestDays: soonest(currencies.map((c) => c.daysLeft)),
      href: "/sms"
    });
  }
  if (input.untriaged > 0) {
    items.push({
      kind: "UNTRIAGED",
      urgency: "SOON",
      count: input.untriaged,
      soonestDays: null,
      href: "/triage"
    });
  }
  if (input.overdueActions.length) {
    items.push({
      kind: "ACTION_OVERDUE",
      urgency: "TODAY",
      count: input.overdueActions.length,
      soonestDays: soonest(input.overdueActions.map((a) => a.daysLeft)),
      href: "/toolkits/register"
    });
  }
  const contacts = input.contacts.filter((contact) => CONTACT_URGENCY[contact.state] !== null);
  if (contacts.length) {
    items.push({
      kind: "CONTACT",
      urgency: worst(contacts.map((contact) => CONTACT_URGENCY[contact.state])),
      count: contacts.length,
      soonestDays: soonest(contacts.map((contact) => contact.daysLeft)),
      href: "/sms"
    });
  }
  return Object.freeze({ items: Object.freeze(items), urgency: highest(items) });
}
function isWorthSending(digest) {
  return digest.items.length > 0;
}
var RANK, DEADLINE_URGENCY, CURRENCY_URGENCY, CONTACT_URGENCY;
var init_digest = __esm({
  "packages/shared/src/digest.ts"() {
    "use strict";
    RANK = Object.freeze({
      NOW: 3,
      TODAY: 2,
      SOON: 1
    });
    DEADLINE_URGENCY = Object.freeze({
      /* Already late. There is no softer word for this. */
      OVERDUE: "NOW",
      /* An obligation the instrument words as "without delay" — it has no
         computed window to be due soon within, so it is always NOW. */
      WITHOUT_DELAY: "NOW",
      DUE_SOON: "TODAY",
      /* Outstanding with time in hand. Deliberately silent: a digest that
         lists every open obligation every day is a list, not a warning. */
      PENDING: null,
      /* Done. */
      MET: null
    });
    CURRENCY_URGENCY = Object.freeze({
      LAPSED: "TODAY",
      DUE_SOON: "SOON",
      CURRENT: null,
      NO_EXPIRY: null
    });
    CONTACT_URGENCY = Object.freeze({
      NEVER_VERIFIED: "TODAY",
      STALE: "TODAY",
      DUE_SOON: "SOON",
      CURRENT: null
    });
  }
});

// apps/api/src/mail.ts
function resetSubject() {
  return "UsalamaSMS \u2014 set a new password";
}
function resetBody(link, minutes) {
  return [
    "Somebody asked to set a new password for this address.",
    "",
    "Open this link and choose one:",
    link,
    "",
    `The link works once and stops working after ${minutes} minutes.`,
    "",
    /* SAID PLAINLY, because it is the only instruction that matters to
       the one reader who did not ask for this. "Ignore this email" is
       the standard sentence and it is incomplete — it tells them to do
       nothing without telling them that doing nothing is sufficient,
       which is the part that decides whether they panic. */
    "If that was not you, nothing has happened and nothing will. The link",
    "changes nothing until it is opened, and your current password still works.",
    "",
    "Using it signs out every device this account is signed in on."
  ].join("\n");
}
async function sendPasswordReset(to, link, minutes, config2, fetchImpl = fetch) {
  if (!config2.apiKey) return { status: "NOT_CONFIGURED" };
  try {
    const response = await fetchImpl("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: "Bearer " + config2.apiKey,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        from: config2.from,
        ...config2.replyTo ? { reply_to: config2.replyTo } : {},
        to,
        subject: resetSubject(),
        text: resetBody(link, minutes)
      })
    });
    if (!response.ok) {
      return { status: "FAILED", reason: `provider responded ${response.status}` };
    }
    let id = "";
    try {
      const payload = await response.json();
      id = payload.id ?? "";
    } catch {
    }
    return { status: "SENT", id };
  } catch (error) {
    return {
      status: "FAILED",
      reason: error instanceof Error ? error.message : "transport failed"
    };
  }
}
function invitationSubject(orgName) {
  return `UsalamaSMS \u2014 your safety management account for ${orgName}`;
}
function invitationBody(orgName, email, baseUrl, trialEndsOn) {
  return [
    `An account has been created for ${orgName} on UsalamaSMS.`,
    "",
    `Sign in at: ${baseUrl}/login`,
    `Your username is this address: ${email}`,
    "",
    /* SAID BEFORE THEY GO LOOKING FOR IT. The single most likely
       failure of this email is somebody hunting for a password that is
       deliberately not in it, deciding the message is broken, and
       filing it. */
    "Your password is not in this email, on purpose \u2014 a password sent by",
    "email stays in a mailbox long after it should. Your administrator has",
    "it and will pass it to you directly. If you have not been given one,",
    "ask them rather than requesting a reset.",
    "",
    ...trialEndsOn ? [`Your trial runs until ${trialEndsOn}. Everything is available during it.`, ""] : [],
    "What to do first: file one report, so the system holds something real,",
    "and open Annex 19 Conformance to see where you stand against the twelve",
    "elements.",
    "",
    "This product holds your safety record. It does not run your safety",
    "management system \u2014 somebody still has to identify the hazard, decide",
    "the risk is tolerable, and sign their name to that."
  ].join("\n");
}
async function sendInvitation(to, orgName, trialEndsOn, config2, fetchImpl = fetch) {
  if (!config2.apiKey) return { status: "NOT_CONFIGURED" };
  try {
    const response = await fetchImpl("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: "Bearer " + config2.apiKey,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        from: config2.from,
        ...config2.replyTo ? { reply_to: config2.replyTo } : {},
        to,
        subject: invitationSubject(orgName),
        text: invitationBody(orgName, to, config2.baseUrl, trialEndsOn)
      })
    });
    if (!response.ok) {
      return { status: "FAILED", reason: `provider responded ${response.status}` };
    }
    let id = "";
    try {
      const payload = await response.json();
      id = payload.id ?? "";
    } catch {
    }
    return { status: "SENT", id };
  } catch (error) {
    return {
      status: "FAILED",
      reason: error instanceof Error ? error.message : "transport failed"
    };
  }
}
function upgradeRequestSubject(orgName) {
  return `UsalamaSMS \u2014 ${orgName} has asked to upgrade`;
}
function upgradeRequestBody(orgName, askedBy, fleetSize, band) {
  return [
    `${orgName} has asked to move onto a paid subscription.`,
    "",
    `Asked by: ${askedBy}`,
    fleetSize === null ? "Fleet size: not recorded \u2014 ask before quoting, do not assume a band." : `Fleet size: ${fleetSize}`,
    band ? `Band: ${band.name}, $${band.usdMonthly}/month` : "Band: cannot be determined without a fleet size.",
    "",
    "NOTHING HAS BEEN GRANTED. Confirm payment however you normally do,",
    "then grant the entitlement from the administration console. Until you",
    "do, their safety office stays paused \u2014 their people can still file",
    "reports and they can still export their whole record."
  ].join("\n");
}
async function sendUpgradeRequest(orgName, askedBy, fleetSize, band, config2, fetchImpl = fetch) {
  if (!config2.apiKey) return { status: "NOT_CONFIGURED" };
  if (!config2.platformNotice) return { status: "NOT_CONFIGURED" };
  try {
    const response = await fetchImpl("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: "Bearer " + config2.apiKey,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        from: config2.from,
        ...config2.replyTo ? { reply_to: config2.replyTo } : {},
        to: config2.platformNotice,
        subject: upgradeRequestSubject(orgName),
        text: upgradeRequestBody(orgName, askedBy, fleetSize, band)
      })
    });
    if (!response.ok) {
      return { status: "FAILED", reason: `provider responded ${response.status}` };
    }
    let id = "";
    try {
      const payload = await response.json();
      id = payload.id ?? "";
    } catch {
    }
    return { status: "SENT", id };
  } catch (error) {
    return {
      status: "FAILED",
      reason: error instanceof Error ? error.message : "transport failed"
    };
  }
}
function mailConfigFromEnv(env = process.env) {
  return {
    apiKey: env.RESEND_API_KEY || void 0,
    baseUrl: (env.PUBLIC_BASE_URL || "https://usalamasms.com").replace(/\/+$/, ""),
    from: "UsalamaSMS <safety@usalamasms.com>",
    /* Set MAIL_REPLY_TO to a mailbox somebody actually reads. Until it
       is set, no Reply-To is sent at all — which is honest: a reply
       fails visibly rather than disappearing into a void the sender
       believes is monitored. An empty string is not an address, so a
       variable created and never filled in stays absent. */
    replyTo: env.MAIL_REPLY_TO || void 0,
    platformNotice: env.PLATFORM_NOTICE_EMAIL || void 0
  };
}
var PHRASE;
var init_mail = __esm({
  "apps/api/src/mail.ts"() {
    "use strict";
    init_digest();
    PHRASE = Object.freeze({
      DEADLINE: (n) => n === 1 ? "1 reporting deadline needs attention" : `${n} reporting deadlines need attention`,
      CURRENCY: (n) => n === 1 ? "1 training currency is lapsing" : `${n} training currencies are lapsing`,
      UNTRIAGED: (n) => n === 1 ? "1 report is waiting to be triaged" : `${n} reports are waiting to be triaged`,
      ACTION_OVERDUE: (n) => n === 1 ? "1 corrective action is overdue" : `${n} corrective actions are overdue`,
      CONTACT: (n) => n === 1 ? "1 emergency contact needs verification" : `${n} emergency contacts need verification`
    });
  }
});

// apps/api/src/routes.auth.ts
import { z as z4 } from "zod";
import argon22 from "argon2";
import { randomBytes as randomBytes2 } from "node:crypto";
function issuePassword() {
  const bytes = randomBytes2(20);
  let out = "";
  for (const b of bytes) out += CREDENTIAL_ALPHABET[b % CREDENTIAL_ALPHABET.length];
  return `${out.slice(0, 5)}-${out.slice(5, 10)}-${out.slice(10, 15)}-${out.slice(15, 20)}`;
}
function knownOnly(sent, list) {
  if (!sent?.length) return [];
  const known = new Set(list.map((row) => row.code));
  return [...new Set(sent.filter((code) => known.has(code)))];
}
async function authRoutes(app) {
  app.post(
    "/api/v1/auth/login",
    {
      config: {
        // Tighter than the sync route by an order of magnitude. Sync is
        // a device catching up; login is the one endpoint worth
        // brute-forcing.
        rateLimit: { max: 10, timeWindow: "15 minutes" }
      }
    },
    async (req, reply) => {
      const parsed = LoginSchema.safeParse(req.body);
      if (!parsed.success) return reply.code(400).send(GENERIC_FAILURE);
      const { email, password } = parsed.data;
      const user = await prisma.user.findUnique({
        where: { email: email.toLowerCase() },
        select: { id: true, orgId: true, role: true, passwordHash: true, active: true }
      });
      const ok = await verifyPassword(user?.passwordHash ?? DUMMY_HASH, password).catch((err) => {
        req.log.error({ err: { message: String(err) } }, "password verification threw");
        return false;
      });
      if (!user || !user.active || !ok) {
        req.log.warn({ email: hmac(email.toLowerCase()) }, "login failed");
        return reply.code(401).send(GENERIC_FAILURE);
      }
      const accessToken = issueAccessToken({ sub: user.id, org: user.orgId, role: user.role });
      const refreshToken = await issueRefreshToken(user.id);
      return reply.send({
        accessToken,
        refreshToken,
        expiresIn: ENV.ACCESS_TTL,
        role: user.role,
        orgId: user.orgId
      });
    }
  );
  app.post(
    "/api/v1/auth/refresh",
    { config: { rateLimit: { max: 60, timeWindow: "15 minutes" } } },
    async (req, reply) => {
      const token = req.body?.refreshToken;
      if (typeof token !== "string" || token.length < 32) {
        return reply.code(401).send({ error: "invalid_refresh_token" });
      }
      const tokenHash = hmac(token);
      const existing = await prisma.refreshToken.findUnique({
        where: { tokenHash },
        select: { id: true, userId: true, expiresAt: true, revokedAt: true }
      });
      if (!existing) return reply.code(401).send({ error: "invalid_refresh_token" });
      if (existing.revokedAt) {
        await prisma.$transaction(async (tx) => {
          await tx.refreshToken.updateMany({
            where: { userId: existing.userId, revokedAt: null },
            data: { revokedAt: /* @__PURE__ */ new Date() }
          });
          const user2 = await tx.user.findUnique({
            where: { id: existing.userId },
            select: { orgId: true }
          });
          if (user2) {
            await appendAuditTx(tx, {
              orgId: user2.orgId,
              userId: existing.userId,
              action: "auth.refresh.reuse_detected",
              entityType: "User",
              entityId: existing.userId,
              detail: { allSessionsRevoked: true }
            });
          }
        });
        req.log.error({ userId: existing.userId }, "refresh token reuse \u2014 all sessions revoked");
        return reply.code(401).send({ error: "invalid_refresh_token" });
      }
      if (existing.expiresAt.getTime() < Date.now()) {
        return reply.code(401).send({ error: "invalid_refresh_token" });
      }
      const user = await prisma.user.findUnique({
        where: { id: existing.userId },
        select: { id: true, orgId: true, role: true, active: true }
      });
      if (!user || !user.active) return reply.code(401).send({ error: "invalid_refresh_token" });
      const burned = await prisma.refreshToken.updateMany({
        where: { id: existing.id, revokedAt: null },
        data: { revokedAt: /* @__PURE__ */ new Date() }
      });
      if (burned.count === 0) {
        await prisma.$transaction(async (tx) => {
          await tx.refreshToken.updateMany({
            where: { userId: existing.userId, revokedAt: null },
            data: { revokedAt: /* @__PURE__ */ new Date() }
          });
          await appendAuditTx(tx, {
            orgId: user.orgId,
            userId: existing.userId,
            action: "auth.refresh.reuse_detected",
            entityType: "User",
            entityId: existing.userId,
            detail: { allSessionsRevoked: true, concurrent: true }
          });
        });
        req.log.error(
          { userId: existing.userId },
          "refresh token used twice concurrently \u2014 all sessions revoked"
        );
        return reply.code(401).send({ error: "invalid_refresh_token" });
      }
      const accessToken = issueAccessToken({ sub: user.id, org: user.orgId, role: user.role });
      const refreshToken = await issueRefreshToken(user.id);
      return reply.send({ accessToken, refreshToken, expiresIn: ENV.ACCESS_TTL });
    }
  );
  app.post(
    "/api/v1/auth/signup",
    {
      config: {
        /* Five in an hour per address. A real operator signs up once;
           this is the only unauthenticated route that WRITES, and every
           successful call creates a tenant. */
        rateLimit: { max: 5, timeWindow: "1 hour" }
      }
    },
    async (req, reply) => {
      const parsed = SignupSchema.safeParse(req.body);
      if (!parsed.success) {
        return reply.code(400).send({
          error: "invalid",
          detail: parsed.error.flatten()
        });
      }
      const input = parsed.data;
      const email = input.email.toLowerCase();
      const existing = await prisma.user.findUnique({
        where: { email },
        select: { id: true }
      });
      const passwordHash = await argon22.hash(input.password, { type: argon22.argon2id });
      if (existing) {
        req.log.warn({ email: hmac(email) }, "signup refused \u2014 address already registered");
        return reply.code(409).send({
          error: "cannot_create",
          /* SAID "your administrator can reset it" UNTIL THE RESET
             ROUTES LANDED, and there was no administrator: this route
             creates one ACCOUNTABLE_EXECUTIVE, that role does not hold
             `user.manage`, and nothing anywhere creates a second user.
             So the sentence sent every locked-out customer to a person
             who does not exist. It now names the route that works. */
          message: "That account could not be created. If you already have one, sign in \u2014 and if you have forgotten the password, ask for a reset link at /reset."
        });
      }
      const created = await prisma.$transaction(async (tx) => {
        const org = await tx.org.create({
          data: {
            name: input.orgName,
            jurisdiction: input.jurisdiction,
            ...input.aocNumber ? { aocNumber: input.aocNumber } : {},
            /* THE FLEET SIZE WAS ASKED FOR AND THROWN AWAY. The signup
                           panel renders a number field, the panel posts it, and
                           SignupSchema has validated it since this route existed —
                           and this create never wrote it. So every operator that
                           ever signed up typed how many aircraft it flies, was told
                           the account was created, and left `fleetSize` null.
            
                           billableBand() returns null for a missing fleet size
                           rather than quietly invoicing the cheapest band, which is
                           the right refusal and meant the symptom was silence: no
                           error, no wrong invoice, just an operator that could not
                           be billed and nothing anywhere saying why.
            
                           That is charter rule 8 — a write that does not happen is
                           reported — failing in the one place where the report was
                           a 201. */
            ...input.fleet === void 0 ? {} : { fleetSize: input.fleet },
            /* And the profile beside it. Filtered to codes the shared
               vocabularies actually carry rather than stored as sent:
               this is the only unauthenticated route that writes, and a
               free-text aerodrome here is the second HKJK the taxonomy
               exists to prevent. An unrecognised code is DROPPED rather
               than refused — a signup that 400s because somebody's
               integration sent one unknown type is a customer lost over
               a field that was optional anyway. */
            fleetTypes: knownOnly(input.fleetTypes, AIRCRAFT_TYPES),
            bases: knownOnly(input.bases, AERODROMES),
            operationTypes: (input.operationTypes ?? []).filter(
              (c) => OPERATION_TYPES.some((o) => o.code === c)
            )
          }
        });
        const user = await tx.user.create({
          data: {
            orgId: org.id,
            email,
            name: input.name,
            passwordHash,
            /* Server-set. See property 1 above. */
            role: "ACCOUNTABLE_EXECUTIVE"
          }
        });
        await appendAuditTx(tx, {
          orgId: org.id,
          userId: user.id,
          action: "org.create",
          entityType: "Org",
          entityId: org.id
        });
        return { org, user };
      });
      const accessToken = issueAccessToken({
        sub: created.user.id,
        org: created.org.id,
        role: created.user.role
      });
      const refreshToken = await issueRefreshToken(created.user.id);
      return reply.code(201).send({
        accessToken,
        refreshToken,
        expiresIn: ENV.ACCESS_TTL,
        role: created.user.role,
        orgId: created.org.id,
        orgName: created.org.name
      });
    }
  );
  app.post(
    "/api/v1/auth/forgot",
    {
      config: {
        /* Harder than login. Login costs an attacker a guess; this
           costs a real person an email they did not ask for, and a
           product that can be made to post a hundred of them at one
           address is a product mail providers stop delivering. */
        rateLimit: { max: 5, timeWindow: "15 minutes" }
      }
    },
    async (req, reply) => {
      const parsed = ForgotSchema.safeParse(req.body);
      if (!parsed.success) {
        return reply.code(202).send({ requested: true, message: RESET_REQUESTED_ANSWER });
      }
      const email = parsed.data.email;
      const mail = mailConfigFromEnv();
      const delivery = mail.apiKey ? "CONFIGURED" : "NOT_CONFIGURED";
      const user = await prisma.user.findUnique({
        where: { email },
        select: { id: true, orgId: true, active: true }
      });
      const token = randomBytes2(32).toString("base64url");
      const tokenHash = hmac(token);
      const expiresAt = new Date(Date.now() + RESET_TTL_MINUTES * 6e4);
      if (user && user.active) {
        await prisma.$transaction(async (tx) => {
          await tx.passwordReset.updateMany({
            where: { userId: user.id, usedAt: null },
            data: { usedAt: /* @__PURE__ */ new Date() }
          });
          await tx.passwordReset.create({
            data: { userId: user.id, tokenHash, expiresAt }
          });
          await appendAuditTx(tx, {
            orgId: user.orgId,
            userId: user.id,
            action: "auth.password.reset_requested",
            entityType: "User",
            entityId: user.id,
            /* THE ACT AND THE CHANNEL, never the token. An audit entry
               holding a live reset link would make the audit export a
               credential store. */
            detail: { delivery }
          });
        });
        const outcome = await sendPasswordReset(
          email,
          `${mail.baseUrl}/reset?token=${token}`,
          RESET_TTL_MINUTES,
          mail
        );
        req.log.info({ email: hmac(email), outcome: outcome.status }, "password reset requested");
      } else {
        req.log.warn({ email: hmac(email) }, "password reset requested for no live account");
      }
      return reply.code(202).send({
        requested: true,
        delivery,
        message: RESET_REQUESTED_ANSWER
      });
    }
  );
  app.post(
    "/api/v1/auth/reset",
    {
      config: {
        /* A token is 32 random bytes, so guessing is not the threat;
           hashing is. Each call runs argon2 on a caller-supplied
           password, and an unbounded route that does that is a CPU
           exhaustion primitive pointed at the API every other request
           shares. */
        rateLimit: { max: 10, timeWindow: "15 minutes" }
      }
    },
    async (req, reply) => {
      const parsed = ResetSchema.safeParse(req.body);
      if (!parsed.success) {
        const tooShort = parsed.error.issues.some((i) => i.path[0] === "newPassword");
        return reply.code(400).send({
          error: tooShort ? "password_too_short" : "invalid",
          message: tooShort ? `A new password needs at least ${MIN_PASSWORD_LENGTH} characters.` : RESET_REFUSED_ANSWER
        });
      }
      const tokenHash = hmac(parsed.data.token);
      const existing = await prisma.passwordReset.findUnique({
        where: { tokenHash },
        select: { id: true, userId: true, expiresAt: true, usedAt: true }
      });
      const refuse = () => reply.code(400).send({ error: "reset_link_unusable", message: RESET_REFUSED_ANSWER });
      if (!existing || existing.usedAt || existing.expiresAt.getTime() < Date.now()) {
        return refuse();
      }
      const user = await prisma.user.findUnique({
        where: { id: existing.userId },
        select: { id: true, orgId: true, email: true, active: true }
      });
      if (!user || !user.active) return refuse();
      const passwordHash = await argon22.hash(parsed.data.newPassword, { type: argon22.argon2id });
      const claimed = await prisma.passwordReset.updateMany({
        where: { id: existing.id, usedAt: null },
        data: { usedAt: /* @__PURE__ */ new Date() }
      });
      if (claimed.count === 0) return refuse();
      await prisma.$transaction(async (tx) => {
        await tx.user.update({ where: { id: user.id }, data: { passwordHash } });
        await tx.passwordReset.updateMany({
          where: { userId: user.id, usedAt: null },
          data: { usedAt: /* @__PURE__ */ new Date() }
        });
        await tx.refreshToken.updateMany({
          where: { userId: user.id, revokedAt: null },
          data: { revokedAt: /* @__PURE__ */ new Date() }
        });
        await appendAuditTx(tx, {
          orgId: user.orgId,
          userId: user.id,
          action: "auth.password.reset_completed",
          entityType: "User",
          entityId: user.id,
          detail: { self: true, viaEmailLink: true, allSessionsRevoked: true }
        });
      });
      req.log.info({ user: hmac(user.email) }, "password reset completed");
      return reply.send({
        reset: true,
        message: "Password set. Every device this account was signed in on has been signed out. Sign in with the new password."
      });
    }
  );
  app.post(
    "/api/v1/auth/logout",
    { preHandler: [authenticate] },
    async (req, reply) => {
      await prisma.refreshToken.updateMany({
        where: { userId: req.auth.sub, revokedAt: null },
        data: { revokedAt: /* @__PURE__ */ new Date() }
      });
      return reply.code(204).send();
    }
  );
  app.post(
    "/api/v1/auth/admin/reset-password",
    {
      preHandler: [authenticate, requirePermission("user.manage")],
      config: { rateLimit: { max: 10, timeWindow: "15 minutes" } }
    },
    async (req, reply) => {
      const userId = typeof req.body?.userId === "string" ? req.body.userId : "";
      if (!userId) return reply.code(400).send({ error: "user_id_required" });
      const target = await prisma.user.findFirst({
        where: { id: userId, orgId: req.auth.org },
        select: { id: true, email: true, role: true }
      });
      if (!target) return reply.code(404).send({ error: "user_not_found" });
      if (!mayResetCredential(req.auth.role, target.role)) {
        return reply.code(403).send({
          error: "reset_not_permitted",
          /* NAMED rather than "forbidden". An administrator looking at
             a list of their own colleagues needs to know this is a rule
             and not a malfunction, and needs to know who to ask. */
          message: target.role === "PLATFORM_ADMIN" ? "That account belongs to the supplier of this product." : "Your role cannot reset an account that reads safety narratives \u2014 a reset hands you a working password for it. The accountable executive can, and they can also reset it themselves from the sign-in screen."
        });
      }
      const password = randomBytes2(18).toString("base64url");
      const passwordHash = await argon22.hash(password, { type: argon22.argon2id });
      await prisma.$transaction(async (tx) => {
        await tx.user.update({ where: { id: target.id }, data: { passwordHash } });
        await tx.refreshToken.updateMany({
          where: { userId: target.id, revokedAt: null },
          data: { revokedAt: /* @__PURE__ */ new Date() }
        });
        await appendAuditTx(tx, {
          orgId: req.auth.org,
          userId: req.auth.sub,
          action: "auth.password.reset",
          entityType: "User",
          entityId: target.id,
          // The subject and the actor, never the credential.
          detail: { targetEmail: target.email, targetRole: target.role }
        });
      });
      return {
        userId: target.id,
        email: target.email,
        password,
        note: "Shown once. Hand it over directly and have them change it. Every existing session for this account has been signed out."
      };
    }
  );
  app.post(
    "/api/v1/users",
    {
      preHandler: [authenticate, requirePermission("user.manage")],
      config: { rateLimit: { max: 20, timeWindow: "15 minutes" } }
    },
    async (req, reply) => {
      const auth = req.auth;
      const email = String(req.body?.email ?? "").trim().toLowerCase();
      const name = String(req.body?.name ?? "").trim();
      const roleRaw = String(req.body?.role ?? "");
      if (!email.includes("@") || email.length > 254) {
        return reply.code(400).send({ error: "email_required" });
      }
      if (name.length < 2 || name.length > 160) {
        return reply.code(400).send({ error: "name_required" });
      }
      const parsed = RoleEnum.safeParse(roleRaw);
      if (!parsed.success) return reply.code(400).send({ error: "unknown_role" });
      const role = parsed.data;
      if (!mayCreateRole(auth.role, role)) {
        return reply.code(403).send({
          error: "role_not_permitted",
          /* NAMED, because "forbidden" would read as a bug to an
             administrator who can plainly see the role in the list. */
          message: role === "PLATFORM_ADMIN" ? "That role belongs to the supplier of this product and cannot be created by an operator." : "Your role cannot create an account that reads safety narratives. Ask the accountable executive."
        });
      }
      const taken = await prisma.user.findFirst({ where: { email }, select: { id: true } });
      if (taken) return reply.code(409).send({ error: "email_already_registered" });
      const password = issuePassword();
      const passwordHash = await argon22.hash(password);
      const created = await prisma.$transaction(async (tx) => {
        const user = await tx.user.create({
          /* orgId FROM THE TOKEN, never from the body. An admin of one
             operator creating an account inside another is the worst
             breach this product could have, and the safe version is one
             where the request cannot express it. */
          data: { orgId: auth.org, email, name, role, passwordHash },
          select: { id: true, email: true, name: true, role: true }
        });
        await appendAuditTx(tx, {
          orgId: auth.org,
          userId: auth.sub,
          action: "user.created",
          entityType: "User",
          entityId: user.id,
          /* Field by field, and NEVER the password or its hash. */
          detail: { email: user.email, role: user.role }
        });
        return user;
      });
      return reply.code(201).send({
        id: created.id,
        email: created.email,
        name: created.name,
        role: created.role,
        password,
        passwordShownOnce: true
      });
    }
  );
  app.post(
    "/api/v1/users/:id/active",
    {
      preHandler: [authenticate, requirePermission("user.manage")],
      config: { rateLimit: { max: 20, timeWindow: "15 minutes" } }
    },
    async (req, reply) => {
      const auth = req.auth;
      if (typeof req.body?.active !== "boolean") {
        return reply.code(400).send({ error: "active_required" });
      }
      const active = req.body.active;
      const target = await prisma.user.findFirst({
        where: { id: req.params.id, orgId: auth.org },
        select: { id: true, email: true, name: true, role: true, active: true }
      });
      if (!target) return reply.code(404).send({ error: "user_not_found" });
      if (target.id === auth.sub && !active) {
        return reply.code(409).send({
          error: "cannot_deactivate_self",
          message: "You cannot deactivate your own account \u2014 nobody would be left to reactivate it. Ask a colleague who manages accounts."
        });
      }
      if (!active && target.role === "ACCOUNTABLE_EXECUTIVE") {
        const others = await prisma.user.count({
          where: {
            orgId: auth.org,
            role: "ACCOUNTABLE_EXECUTIVE",
            active: true,
            id: { not: target.id }
          }
        });
        if (others === 0) {
          return reply.code(409).send({
            error: "last_accountable_executive",
            message: "This is the only active accountable executive. That role signs the safety policy and is the only one that can reset the safety office's credentials. Appoint the replacement first, then deactivate this one."
          });
        }
      }
      if (target.active === active) {
        return { id: target.id, active, changed: false };
      }
      await prisma.$transaction(async (tx) => {
        await tx.user.update({ where: { id: target.id }, data: { active } });
        if (!active) {
          await tx.refreshToken.updateMany({
            where: { userId: target.id, revokedAt: null },
            data: { revokedAt: /* @__PURE__ */ new Date() }
          });
        }
        await appendAuditTx(tx, {
          orgId: auth.org,
          userId: auth.sub,
          action: active ? "user.reactivated" : "user.deactivated",
          entityType: "User",
          entityId: target.id,
          detail: { targetEmail: target.email, targetRole: target.role }
        });
      });
      return {
        id: target.id,
        active,
        changed: true,
        note: active ? "They can sign in again with the password they had. If it is lost, reset it." : "Signed out of every device, and no new session can be started. A session opened in the last 15 minutes stays valid until it expires. Their reports, and every audit entry naming them, are untouched."
      };
    }
  );
  app.get("/api/v1/users", {
    preHandler: [authenticate, requirePermission("user.manage")]
  }, async (req) => {
    const rows = await prisma.user.findMany({
      where: tenantWhere(req),
      orderBy: [{ name: "asc" }],
      take: 500,
      select: { id: true, email: true, name: true, role: true, active: true }
    });
    return { users: rows };
  });
  app.get("/api/v1/auth/me", { preHandler: [authenticate] }, async (req) => {
    const [org, user] = await Promise.all([
      prisma.org.findUnique({
        where: { id: req.auth.org },
        select: {
          name: true,
          aocNumber: true,
          jurisdiction: true,
          /* THE LOGO COMES BACK ON /me, not from /config, and that is a
             performance decision rather than a modelling one. The print
             block reads its identity from here already; putting the
             mark anywhere else means every printed pack issues a second
             request while a print dialog is opening, and a print dialog
             does not wait. */
          config: { select: { logo: true } }
        }
      }),
      /* WHO THE PERSON IS, not only which tenant they are in. The
               account area could not say "you are signed in as" without this
               — it had the org's name and not the reader's, which is the
               wrong way round for a page about them.
      
               Scoped by org as well as by id. The id comes from a verified
               token so the org clause adds nothing today; it costs nothing
               and it is the clause somebody would otherwise have to remember
               to add the day this is reached any other way. */
      prisma.user.findFirst({
        where: { id: req.auth.sub, orgId: req.auth.org },
        select: { name: true, email: true, createdAt: true }
      })
    ]);
    return {
      userId: req.auth.sub,
      orgId: req.auth.org,
      role: req.auth.role,
      name: user?.name ?? null,
      email: user?.email ?? null,
      memberSince: user?.createdAt?.toISOString() ?? null,
      orgName: org?.name ?? null,
      aocNumber: org?.aocNumber ?? null,
      jurisdiction: org?.jurisdiction ?? null,
      logo: org?.config?.logo ?? null,
      /* THE PERMISSIONS THEMSELVES, and this is what stops the account
               area becoming a second copy of the matrix.
      
               The queue already returns which moves a caller may make rather
               than letting the screen work it out, for exactly this reason: a
               client that decides for itself what a role may do is a second
               copy of the permission table, and it is the copy that goes
               stale. An index of destinations is the same problem one layer
               out — so the server says what this caller holds, and the screen
               filters on the answer. */
      permissions: [...PERMISSIONS[req.auth.role] ?? []]
    };
  });
  app.patch(
    "/api/v1/auth/me",
    {
      preHandler: [authenticate],
      config: { rateLimit: { max: 20, timeWindow: "15 minutes" } }
    },
    async (req, reply) => {
      const parsed = ProfileSchema.safeParse(req.body);
      if (!parsed.success) {
        return reply.code(400).send({ error: "invalid", detail: parsed.error.flatten() });
      }
      const before = await prisma.user.findFirst({
        where: { id: req.auth.sub, orgId: req.auth.org },
        select: { name: true }
      });
      if (!before) return reply.code(404).send({ error: "user_not_found" });
      await prisma.$transaction(async (tx) => {
        await tx.user.update({
          where: { id: req.auth.sub },
          data: { name: parsed.data.name }
        });
        await appendAuditTx(tx, {
          orgId: req.auth.org,
          userId: req.auth.sub,
          action: "user.profile.update",
          entityType: "User",
          entityId: req.auth.sub,
          detail: { name: { from: before.name, to: parsed.data.name } }
        });
      });
      return reply.send({ name: parsed.data.name });
    }
  );
  app.post(
    "/api/v1/auth/password",
    {
      preHandler: [authenticate],
      /* Tighter than the profile edit. This verifies a password, so an
         attacker with a borrowed token gets few guesses at the one
         thing that would make the takeover permanent. */
      config: { rateLimit: { max: 5, timeWindow: "15 minutes" } }
    },
    async (req, reply) => {
      const parsed = PasswordChangeSchema.safeParse(req.body);
      if (!parsed.success) {
        return reply.code(400).send({ error: "invalid", detail: parsed.error.flatten() });
      }
      const user = await prisma.user.findFirst({
        where: { id: req.auth.sub, orgId: req.auth.org },
        select: { id: true, passwordHash: true, email: true }
      });
      if (!user) return reply.code(404).send({ error: "user_not_found" });
      const ok = await verifyPassword(user.passwordHash, parsed.data.currentPassword);
      if (!ok) {
        req.log.warn(
          { user: hmac(user.email) },
          "password change refused \u2014 current password did not verify"
        );
        return reply.code(403).send({
          error: "current_password_incorrect",
          message: "That is not the current password for this account. Nothing was changed."
        });
      }
      if (parsed.data.currentPassword === parsed.data.newPassword) {
        return reply.code(400).send({
          error: "unchanged",
          message: "The new password is the same as the current one. If you are changing it because somebody else knows it, it needs to be different."
        });
      }
      const passwordHash = await argon22.hash(parsed.data.newPassword, { type: argon22.argon2id });
      await prisma.$transaction(async (tx) => {
        await tx.user.update({ where: { id: user.id }, data: { passwordHash } });
        await tx.refreshToken.updateMany({
          where: { userId: user.id, revokedAt: null },
          data: { revokedAt: /* @__PURE__ */ new Date() }
        });
        await appendAuditTx(tx, {
          orgId: req.auth.org,
          userId: user.id,
          action: "auth.password.change",
          entityType: "User",
          entityId: user.id,
          /* THE ACT, NEVER THE CREDENTIAL — not the old one, not the
             new one, not a prefix of either. */
          detail: { self: true }
        });
      });
      return reply.send({
        changed: true,
        message: "Password changed. Every signed-in device for this account has been signed out, including this one \u2014 you can carry on here until this session expires, then sign in with the new password."
      });
    }
  );
}
var CREDENTIAL_ALPHABET, ProfileSchema, PasswordChangeSchema, GENERIC_FAILURE, DUMMY_HASH;
var init_routes_auth = __esm({
  "apps/api/src/routes.auth.ts"() {
    "use strict";
    init_src();
    init_signup();
    init_src();
    init_permissions();
    init_taxonomy();
    init_adrep();
    init_core();
    init_reset();
    init_mail();
    CREDENTIAL_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    ProfileSchema = z4.object({
      name: z4.string().trim().min(2).max(120)
    });
    PasswordChangeSchema = z4.object({
      currentPassword: z4.string().min(1),
      newPassword: z4.string().min(12)
    });
    GENERIC_FAILURE = { error: "invalid_credentials" };
    DUMMY_HASH = "$argon2id$v=19$m=65536,t=3,p=4$c2FsdHNhbHRzYWx0c2FsdA$RdescudvJCsgt3ub+b+dWRWJTmaaJObG";
  }
});

// packages/shared/src/curriculum.ts
function requiredFor(role) {
  if (NOT_SAFETY_PERSONNEL.includes(role)) return Object.freeze([]);
  return Object.freeze([...INITIAL_KEYS, ...ADDITIONS_BY_ROLE[role] ?? []]);
}
function courseFor(key) {
  return ALL_COURSES.find((c) => c.key === key);
}
function gapsFor(role, heldCourseKeys) {
  const held = new Set(heldCourseKeys);
  return Object.freeze(requiredFor(role).filter((k) => !held.has(k)));
}
function unrecognisedIn(heldCourseKeys) {
  return Object.freeze([...new Set(heldCourseKeys.filter((k) => courseFor(k) === void 0))]);
}
function standingOf(expiresOn, asOf) {
  if (expiresOn == null) return "NO_EXPIRY";
  const at4 = expiresOn instanceof Date ? expiresOn.getTime() : Date.parse(String(expiresOn));
  if (!Number.isFinite(at4)) return "NO_EXPIRY";
  const days = Math.ceil((at4 - asOf.getTime()) / 864e5);
  if (days < 0) return "LAPSED";
  if (days <= TRAINING_DUE_SOON_DAYS) return "DUE_SOON";
  return "CURRENT";
}
function daysUntilExpiry(expiresOn, asOf) {
  if (expiresOn == null) return null;
  const at4 = expiresOn instanceof Date ? expiresOn.getTime() : Date.parse(String(expiresOn));
  if (!Number.isFinite(at4)) return null;
  return Math.ceil((at4 - asOf.getTime()) / 864e5);
}
var CURRICULUM_VERIFIED_AGAINST_PRIMARY, CURRICULUM_INSTRUMENT, INITIAL_TOPICS, ROLE_ADDITIONS, TRAINING_BANDS, RECOMMENDED_TIMING, EXECUTIVE_TOPICS, SPECIALISED_FUNCTIONS, OUTCOME_LEVELS, ASSESSMENT_METHODS, SYLLABUS_MODULES, ALL_COURSES, INITIAL_KEYS, ADDITIONS_BY_ROLE, NOT_SAFETY_PERSONNEL, TRAINING_DUE_SOON_DAYS;
var init_curriculum = __esm({
  "packages/shared/src/curriculum.ts"() {
    "use strict";
    CURRICULUM_VERIFIED_AGAINST_PRIMARY = true;
    CURRICULUM_INSTRUMENT = Object.freeze({
      reference: "CAA-AC-SMS011",
      title: "Safety Management Systems (SMS) Training",
      issued: "2025-04-01",
      readOn: "2026-08-17",
      /* The same discrepancy circulars.ts records: the cover says April
         2025 and the running header on all thirteen pages says March 2025.
         Written down rather than resolved silently. */
      issuedDateDisputed: "Cover states April 2025; the running header states March 2025."
    });
    INITIAL_TOPICS = Object.freeze([
      Object.freeze({
        key: "POLICY_OBJECTIVES",
        label: "Safety policy and safety objectives",
        why: "What the organisation has committed to, signed by the person accountable for it."
      }),
      Object.freeze({
        key: "ROLES",
        label: "Safety roles and responsibilities",
        why: "Which safety duties attach to this person's own job, rather than to the safety office."
      }),
      Object.freeze({
        key: "SRM_PRINCIPLES",
        label: "Basic safety risk management principles",
        why: "Hazard, consequence, severity, likelihood \u2014 enough to read a risk assessment."
      }),
      Object.freeze({
        key: "REPORTING",
        label: "The safety reporting system",
        why: "How to file, what protection the reporter has, and what happens next."
      }),
      Object.freeze({
        key: "SMS_PROCEDURES",
        label: "The organisation's own SMS processes and procedures",
        why: "The operator's actual procedures, not a generic course."
      }),
      Object.freeze({
        key: "HUMAN_FACTORS",
        label: "Human factors",
        why: "Why capable people make predictable errors, and what the system does about it."
      })
    ]);
    ROLE_ADDITIONS = Object.freeze([
      Object.freeze({
        key: "ACCOUNTABILITIES",
        label: "SMS accountabilities briefing",
        why: "Doc 9859 lists awareness training for a NEW accountable executive and post holders on their own SMS accountabilities, and on the importance of complying with national and organisational safety requirements. It is the one course tied to a person's appointment rather than to their trade."
      }),
      Object.freeze({
        key: "HAZARD_REPORTING",
        label: "Hazard identification and reporting in practice",
        why: "The manual's own example of role-specific training for frontline staff: recognising a hazard and reporting it, which is the behaviour element 2.1 depends on entirely."
      }),
      Object.freeze({
        key: "RISK_ASSESSMENT",
        label: "Conducting a safety risk assessment",
        why: "Running the matrix rather than reading it \u2014 severity and likelihood assignment, and what ALARP requires of a tolerable risk."
      }),
      Object.freeze({
        key: "AUDIT_TECHNIQUE",
        label: "Safety assurance and audit technique",
        why: "The manual's example of role-specific training for those who run the SMS."
      }),
      Object.freeze({
        key: "INVESTIGATION",
        label: "Occurrence investigation",
        why: "Distinct from assurance: establishing what happened and why, without the search for cause becoming a search for a person to blame."
      })
    ]);
    TRAINING_BANDS = Object.freeze([
      Object.freeze({
        key: "NON_OPERATIONAL",
        who: "Non-operational safety critical personnel, with indirect, minimal or no contact with operational personnel",
        examples: Object.freeze([]),
        days: 2,
        practicalRequired: false
      }),
      Object.freeze({
        key: "OPERATIONAL",
        who: "Operational safety-critical personnel, with modules tailored to the specific role",
        examples: Object.freeze([
          "Flight crew",
          "Cabin crew",
          "Maintenance",
          "Aerodrome safety officers",
          "Engineering",
          "Ground handler"
        ]),
        days: 2,
        practicalRequired: true
      }),
      Object.freeze({
        key: "MANAGEMENT",
        who: "Management personnel",
        examples: Object.freeze([
          "Accountable Manager",
          "Human Resources",
          "Finance",
          "Procurement",
          "Legal"
        ]),
        days: 1,
        practicalRequired: false
      }),
      Object.freeze({
        key: "SAFETY_POSTHOLDER",
        who: "Head of Safety, Safety Officers, and safety-critical post holders",
        examples: Object.freeze([
          "Chief pilot",
          "CFI",
          "Head of operations",
          "Head of quality",
          "Head of base maintenance",
          "Head of workshop",
          "Head of line maintenance",
          "Head of maintenance",
          "Head of training",
          "Head of engineering",
          "Head of ground flight safety",
          "Head of RFFS",
          "Maintenance liaison",
          "Dangerous Goods coordinator"
        ]),
        days: 5,
        practicalRequired: true
      })
    ]);
    RECOMMENDED_TIMING = Object.freeze({
      initialWithinMonths: 2,
      refresherMonths: 24,
      basis: "CAA-AC-SMS011 Appendix I, under \u201CRECOMMENDATIONS\u201D",
      /* Said out loud wherever the numbers are shown. */
      status: "Recommended by advisory circular, not prescribed by regulation. The operator sets its own expiry against its operation, and the record carries that date rather than one computed here."
    });
    EXECUTIVE_TOPICS = Object.freeze([
      "Specific awareness training for new accountable executives and post holders on their SMS accountabilities and responsibilities",
      "Importance of compliance with national and organizational safety requirements",
      "Management commitment",
      "Allocation of resources, promotion and enhancement of skills and knowledge",
      "Promotion of the safety policy and the SMS",
      "Promotion of a positive safety culture",
      "Disciplinary policy",
      "Effective interdepartmental and external safety communication, cooperation and collaboration",
      "Determination and assessment of safety objectives, Safety Performance Indicators, targets and alert levels",
      "Safety data collection, processing and analysis for data-driven decision-making",
      "Protection of safety data principles"
    ]);
    SPECIALISED_FUNCTIONS = Object.freeze([
      "Investigating safety events or incidents",
      "Monitoring and analysis of safety performance",
      "Conducting risk assessments",
      "Managing and maintaining safety databases",
      "Conducting safety audits",
      "Developing safety training programs",
      "Emergency response planning and crisis management",
      "Root-cause analysis"
    ]);
    OUTCOME_LEVELS = Object.freeze([
      Object.freeze({ key: "AWARENESS", label: "Awareness", forEveryone: true }),
      Object.freeze({ key: "KNOWLEDGE", label: "Knowledge", forEveryone: true }),
      Object.freeze({ key: "SKILLS", label: "Skills", forEveryone: false }),
      Object.freeze({ key: "ATTITUDES", label: "Attitudes", forEveryone: false })
    ]);
    ASSESSMENT_METHODS = Object.freeze([
      "Knowledge based questions",
      "Problem based questions",
      "Practical exercises",
      "Case studies"
    ]);
    SYLLABUS_MODULES = Object.freeze([
      Object.freeze({
        number: 1,
        title: "Safety Management Fundamentals",
        purpose: "Fundamental safety management principles and concepts, including the influence of human as well as organizational factors.",
        sections: Object.freeze([
          "Concept of safety and its evolution",
          "Safety risk management",
          "Safety culture"
        ])
      }),
      Object.freeze({
        number: 2,
        title: "Safety Policy, Objectives and Resources",
        purpose: "The knowledge and competency to implement and administer an SMS.",
        sections: Object.freeze([
          "SMS organization and accountabilities",
          "SMS gap analysis",
          "SMS implementation",
          "SMS integration",
          "SMS manual and records management",
          "SMS committee and administration",
          "Safety policy and objectives",
          "Emergency response planning"
        ])
      }),
      Object.freeze({
        number: 3,
        title: "Safety Risk Management and Assurance",
        purpose: "The knowledge and competency to implement safety risk and assurance principles.",
        sections: Object.freeze([
          "Hazard identification and voluntary reporting system",
          "Safety risk assessment and mitigation",
          "Occurrence reporting and investigation",
          "Management of change",
          "Internal and external SMS audit",
          "SMS disciplinary policy and procedures"
        ])
      }),
      Object.freeze({
        number: 4,
        title: "SMS Training and Safety Promotion",
        purpose: "The knowledge and competency to develop internal SMS training and an SMS audit programme.",
        sections: Object.freeze([
          "SMS training programme",
          "Safety information sharing, exchange and safety promotions"
        ])
      }),
      Object.freeze({
        number: 5,
        title: "Safety Performance Management",
        purpose: "Development of SPIs, target setting, safety performance monitoring, and the actions required to achieve an acceptable level of safety performance.",
        sections: Object.freeze([
          "Development of safety objectives",
          "Safety performance indicators and safety performance targets",
          "Monitoring safety performance"
        ])
      }),
      Object.freeze({
        number: 6,
        title: "Safety Data Collection and Processing",
        purpose: "Safety data collection, analysis, exchange and safety data protection provisions.",
        sections: Object.freeze([
          "Safety data collection, analysis and exchange",
          "Safety data analysis"
        ])
      })
    ]);
    ALL_COURSES = Object.freeze([
      ...INITIAL_TOPICS,
      ...ROLE_ADDITIONS
    ]);
    INITIAL_KEYS = INITIAL_TOPICS.map((c) => c.key);
    ADDITIONS_BY_ROLE = Object.freeze({
      /* THE VENDOR IS NOT IN THE OPERATOR'S TRAINING MATRIX. A platform
         administrator holds no post in an aviation organisation, so
         CAA-AC-SMS011 has nothing to say about them — and an entry here
         would put a permanent false gap on somebody's Appendix I band. The
         empty array is the answer, and it is the same reasoning that keeps
         REGULATOR_INSPECTOR empty. */
      PLATFORM_ADMIN: Object.freeze([]),
      FRONTLINE: Object.freeze(["HAZARD_REPORTING"]),
      SAFETY_OFFICER: Object.freeze(["HAZARD_REPORTING", "RISK_ASSESSMENT"]),
      SAFETY_MANAGER: Object.freeze([
        "HAZARD_REPORTING",
        "RISK_ASSESSMENT",
        "AUDIT_TECHNIQUE",
        "ACCOUNTABILITIES"
      ]),
      INVESTIGATOR: Object.freeze(["HAZARD_REPORTING", "RISK_ASSESSMENT", "INVESTIGATION"]),
      KEY_MANAGEMENT: Object.freeze(["ACCOUNTABILITIES", "RISK_ASSESSMENT"]),
      ACCOUNTABLE_EXECUTIVE: Object.freeze(["ACCOUNTABILITIES"]),
      /* An inspector reads the operator's record; they are not the
         operator's personnel and the operator does not train them. */
      REGULATOR_INSPECTOR: Object.freeze([]),
      SYSTEM_ADMIN: Object.freeze([])
    });
    NOT_SAFETY_PERSONNEL = Object.freeze([
      "SYSTEM_ADMIN",
      "REGULATOR_INSPECTOR"
    ]);
    TRAINING_DUE_SOON_DAYS = 90;
  }
});

// packages/shared/src/evidence.ts
function checkEvidence(type, bytes) {
  if (typeof type !== "string" || !EVIDENCE_TYPES.includes(type)) {
    const named = typeof type === "string" && type.length > 0 ? type : "That file";
    const why = type === "image/svg+xml" ? "SVG is markup that can carry script rather than a picture, and it is not accepted anywhere in this product." : `${named} is not a kind of file this accepts.`;
    return {
      ok: false,
      message: `${why} Attach a JPEG, PNG or WebP photograph, or a PDF of a form.`
    };
  }
  if (typeof bytes !== "number" || !Number.isFinite(bytes) || bytes <= 0) {
    return { ok: false, message: "That file appears to be empty." };
  }
  if (bytes > EVIDENCE_MAX_BYTES) {
    const mb = (bytes / 1024 / 1024).toFixed(1);
    const cap = Math.round(EVIDENCE_MAX_BYTES / 1024 / 1024);
    return {
      ok: false,
      message: `That file is ${mb} MB, against a ${cap} MB limit per attachment. A photograph is reduced automatically; a scan this large usually means it was made at a higher resolution than a form needs.`
    };
  }
  return { ok: true, type, bytes };
}
function checkEvidenceCount(existing) {
  if (existing >= EVIDENCE_MAX_FILES) {
    return {
      ok: false,
      message: `A report carries up to ${EVIDENCE_MAX_FILES} attachments. Remove one before adding another, or file what is genuinely a second occurrence separately.`
    };
  }
  return { ok: true, type: "", bytes: 0 };
}
function isBase64(value) {
  if (typeof value !== "string" || value.length === 0) return false;
  if (value.length % 4 !== 0) return false;
  return /^[A-Za-z0-9+/]+={0,2}$/.test(value);
}
function evidenceKey(orgId, reportId, id) {
  for (const part of [orgId, reportId, id]) {
    if (!/^[0-9a-f-]{36}$/i.test(part)) {
      throw new Error(
        "An evidence key is built from three UUIDs and nothing else. Something that was not a UUID reached it, which means a caller-supplied value did."
      );
    }
  }
  return `${orgId}/${reportId}/${id}`;
}
var EVIDENCE_TYPES, EVIDENCE_MAX_BYTES, EVIDENCE_MAX_BODY_BYTES, EVIDENCE_MAX_FILES;
var init_evidence = __esm({
  "packages/shared/src/evidence.ts"() {
    "use strict";
    EVIDENCE_TYPES = Object.freeze([
      "image/jpeg",
      "image/png",
      "image/webp",
      "application/pdf"
    ]);
    EVIDENCE_MAX_BYTES = 3 * 1024 * 1024;
    EVIDENCE_MAX_BODY_BYTES = Math.ceil(EVIDENCE_MAX_BYTES / 3) * 4 + 4096;
    EVIDENCE_MAX_FILES = 6;
  }
});

// apps/api/src/routes.sms.ts
import { z as z5 } from "zod";
import { createHash as createHash2 } from "node:crypto";
function guard(role, permission) {
  return can(role, permission);
}
async function smsRoutes(app) {
  const auth = { preHandler: [authenticate] };
  const limited = { ...auth, config: { rateLimit: { max: 120, timeWindow: "1 minute" } } };
  app.get("/api/v1/sms/voluntary", limited, async (req, reply) => {
    if (!guard(req.auth.role, "document.read")) return reply.code(403).send({ error: "forbidden" });
    const scheme = await prisma.voluntaryScheme.findFirst({ where: tenantWhere(req) });
    return reply.send({ scheme: scheme ?? null });
  });
  app.post("/api/v1/sms/voluntary", limited, async (req, reply) => {
    if (!guard(req.auth.role, "policy.draft")) return reply.code(403).send({ error: "forbidden" });
    const body = VoluntaryInput.safeParse(req.body);
    if (!body.success) return reply.code(400).send({ error: "invalid_voluntary_scheme" });
    const data = {};
    for (const [k, v] of Object.entries(body.data)) {
      if (typeof v === "string") data[k] = v.trim();
    }
    const saved = await prisma.$transaction(async (tx) => {
      const row = await tx.voluntaryScheme.upsert({
        where: { orgId: req.auth.org },
        create: { orgId: req.auth.org, ...data },
        update: data
      });
      await appendAuditTx(tx, {
        orgId: req.auth.org,
        userId: req.auth.sub,
        action: "voluntary.define",
        entityType: "VoluntaryScheme",
        entityId: row.id,
        detail: { defined: Object.keys(data) }
      });
      return row;
    });
    return reply.send({ scheme: saved });
  });
  app.get("/api/v1/sms/policy", limited, async (req, reply) => {
    if (!guard(req.auth.role, "document.read")) return reply.code(403).send({ error: "forbidden" });
    const rows = await prisma.safetyPolicy.findMany({
      where: tenantWhere(req),
      orderBy: { version: "desc" },
      take: LIST_LIMIT,
      include: { signedBy: { select: { name: true, role: true } }, _count: { select: { reads: true } } }
    });
    return reply.send({ policies: rows });
  });
  app.post("/api/v1/sms/policy", limited, async (req, reply) => {
    if (!guard(req.auth.role, "policy.draft")) return reply.code(403).send({ error: "forbidden" });
    const body = PolicyDraft.safeParse(req.body);
    if (!body.success) return reply.code(400).send({ error: "invalid_policy" });
    const created = await prisma.$transaction(async (tx) => {
      const current = await tx.safetyPolicy.findFirst({
        where: { orgId: req.auth.org, supersededOn: null },
        orderBy: { version: "desc" }
      });
      if (current) {
        await tx.safetyPolicy.update({
          where: { id: current.id },
          data: { supersededOn: /* @__PURE__ */ new Date() }
        });
      }
      const policy = await tx.safetyPolicy.create({
        data: {
          orgId: req.auth.org,
          version: (current?.version ?? 0) + 1,
          statement: body.data.statement,
          effectiveFrom: toDate(body.data.effectiveFrom)
        }
      });
      await appendAuditTx(tx, {
        orgId: req.auth.org,
        userId: req.auth.sub,
        action: "policy.draft",
        entityType: "SafetyPolicy",
        entityId: policy.id,
        detail: { version: policy.version, supersededVersion: current?.version ?? null }
      });
      return policy;
    });
    return reply.code(201).send({ policy: created });
  });
  app.post("/api/v1/sms/policy/:id/sign", limited, async (req, reply) => {
    if (!guard(req.auth.role, "policy.sign")) {
      return reply.code(403).send({
        error: "only_accountable_executive",
        detail: "A safety policy is signed by the accountable executive. Anyone else signing it is the finding, not the evidence."
      });
    }
    const signed = await prisma.$transaction(async (tx) => {
      const policy = await tx.safetyPolicy.findFirst({
        where: { id: req.params.id, orgId: req.auth.org }
      });
      if (!policy) return null;
      if (policy.signedOn) return policy;
      const updated = await tx.safetyPolicy.update({
        where: { id: policy.id },
        data: { signedById: req.auth.sub, signedOn: /* @__PURE__ */ new Date() }
      });
      await appendAuditTx(tx, {
        orgId: req.auth.org,
        userId: req.auth.sub,
        action: "policy.sign",
        entityType: "SafetyPolicy",
        entityId: policy.id,
        detail: { version: policy.version }
      });
      return updated;
    });
    if (!signed) return reply.code(404).send({ error: "not_found" });
    return reply.send({ policy: signed });
  });
  app.post("/api/v1/sms/policy/:id/read", limited, async (req, reply) => {
    const ack = await prisma.$transaction(async (tx) => {
      const policy = await tx.safetyPolicy.findFirst({
        where: { id: req.params.id, orgId: req.auth.org }
      });
      if (!policy) return null;
      return tx.policyAcknowledgement.upsert({
        where: { policyId_userId: { policyId: policy.id, userId: req.auth.sub } },
        create: { orgId: req.auth.org, policyId: policy.id, userId: req.auth.sub },
        update: {}
      });
    });
    if (!ack) return reply.code(404).send({ error: "not_found" });
    return reply.send({ acknowledgedAt: ack.acknowledgedAt });
  });
  app.get("/api/v1/sms/accountabilities", limited, async (req, reply) => {
    if (!guard(req.auth.role, "document.read")) return reply.code(403).send({ error: "forbidden" });
    const roster = guard(req.auth.role, "appointment.manage") || guard(req.auth.role, "training.manage");
    const [accountabilities, appointments, people] = await Promise.all([
      prisma.accountability.findMany({
        where: tenantWhere(req),
        orderBy: [{ post: "asc" }],
        take: LIST_LIMIT
      }),
      prisma.appointment.findMany({
        where: { ...tenantWhere(req), endedOn: null },
        orderBy: [{ post: "asc" }],
        take: LIST_LIMIT,
        include: { user: { select: { name: true, role: true } } }
      }),
      roster ? prisma.user.findMany({
        where: { ...tenantWhere(req), active: true },
        orderBy: [{ name: "asc" }],
        take: LIST_LIMIT,
        select: { id: true, name: true, role: true }
      }) : Promise.resolve([])
    ]);
    return reply.send({ accountabilities, appointments, people });
  });
  app.post("/api/v1/sms/accountabilities", limited, async (req, reply) => {
    if (!guard(req.auth.role, "accountability.manage")) return reply.code(403).send({ error: "forbidden" });
    const body = AccountabilityInput.safeParse(req.body);
    if (!body.success) return reply.code(400).send({ error: "invalid_accountability" });
    const row = await prisma.$transaction(async (tx) => {
      const created = await tx.accountability.create({
        data: { orgId: req.auth.org, ...body.data }
      });
      await appendAuditTx(tx, {
        orgId: req.auth.org,
        userId: req.auth.sub,
        action: "accountability.create",
        entityType: "Accountability",
        entityId: created.id,
        detail: { post: created.post, elementId: created.elementId }
      });
      return created;
    });
    return reply.code(201).send({ accountability: row });
  });
  app.post("/api/v1/sms/appointments", limited, async (req, reply) => {
    if (!guard(req.auth.role, "appointment.manage")) return reply.code(403).send({ error: "forbidden" });
    const body = AppointmentInput.safeParse(req.body);
    if (!body.success) return reply.code(400).send({ error: "invalid_appointment" });
    const row = await prisma.$transaction(async (tx) => {
      const appointee = await tx.user.findFirst({
        where: { id: body.data.userId, orgId: req.auth.org },
        select: { id: true }
      });
      if (!appointee) return null;
      await tx.appointment.updateMany({
        where: { orgId: req.auth.org, post: body.data.post, endedOn: null },
        data: { endedOn: new Date(body.data.appointedOn) }
      });
      const created = await tx.appointment.create({
        data: {
          orgId: req.auth.org,
          post: body.data.post,
          userId: body.data.userId,
          appointedOn: new Date(body.data.appointedOn),
          letterRef: body.data.letterRef ?? null
        }
      });
      await appendAuditTx(tx, {
        orgId: req.auth.org,
        userId: req.auth.sub,
        action: "appointment.create",
        entityType: "Appointment",
        entityId: created.id,
        detail: { post: created.post, appointee: created.userId }
      });
      return created;
    });
    if (!row) return reply.code(404).send({ error: "no_such_user" });
    return reply.code(201).send({ appointment: row });
  });
  app.get("/api/v1/sms/exercises", limited, async (req, reply) => {
    if (!guard(req.auth.role, "document.read")) return reply.code(403).send({ error: "forbidden" });
    const rows = await prisma.emergencyExercise.findMany({
      where: tenantWhere(req),
      orderBy: { heldOn: "desc" },
      take: LIST_LIMIT
    });
    return reply.send({ exercises: rows });
  });
  app.post("/api/v1/sms/exercises", limited, async (req, reply) => {
    if (!guard(req.auth.role, "erp.manage")) return reply.code(403).send({ error: "forbidden" });
    const body = ExerciseInput.safeParse(req.body);
    if (!body.success) return reply.code(400).send({ error: "invalid_exercise" });
    const row = await prisma.$transaction(async (tx) => {
      const created = await tx.emergencyExercise.create({
        data: {
          orgId: req.auth.org,
          scenario: body.data.scenario,
          heldOn: new Date(body.data.heldOn),
          participants: body.data.participants,
          findings: body.data.findings,
          planUpdated: body.data.planUpdated
        }
      });
      await appendAuditTx(tx, {
        orgId: req.auth.org,
        userId: req.auth.sub,
        action: "erp.exercise",
        entityType: "EmergencyExercise",
        entityId: created.id,
        detail: { heldOn: created.heldOn.toISOString(), planUpdated: created.planUpdated }
      });
      return created;
    });
    return reply.code(201).send({ exercise: row });
  });
  app.get("/api/v1/sms/documents", limited, async (req, reply) => {
    if (!guard(req.auth.role, "document.read")) return reply.code(403).send({ error: "forbidden" });
    const rows = await prisma.controlledDocument.findMany({
      where: { ...tenantWhere(req), supersededOn: null },
      orderBy: [{ reference: "asc" }],
      take: LIST_LIMIT,
      /* The count, and whether the CALLER has read it. Element 1.5 is
         about distribution, and both numbers are the distribution: how
         many have read the revision in force, and whether the person
         looking at the screen is one of them. Counted per revision,
         because that is what the row is. */
      include: {
        approvedBy: { select: { name: true, role: true } },
        _count: { select: { reads: true } },
        reads: { where: { userId: req.auth.sub }, select: { acknowledgedAt: true }, take: 1 }
      }
    });
    return reply.send({ documents: rows });
  });
  app.post("/api/v1/sms/documents/:id/read", limited, async (req, reply) => {
    if (!guard(req.auth.role, "document.read")) return reply.code(403).send({ error: "forbidden" });
    const { id } = req.params;
    const doc = await prisma.controlledDocument.findFirst({
      where: { ...tenantWhere(req), id },
      select: { id: true }
    });
    if (!doc) return reply.code(404).send({ error: "not_found" });
    const existing = await prisma.documentAcknowledgement.findFirst({
      where: { documentId: doc.id, userId: req.auth.sub },
      select: { acknowledgedAt: true }
    });
    if (existing) {
      return reply.send({ acknowledgedAt: existing.acknowledgedAt, alreadyRead: true });
    }
    const saved = await prisma.$transaction(async (tx) => {
      const row = await tx.documentAcknowledgement.create({
        data: { orgId: req.auth.org, documentId: doc.id, userId: req.auth.sub }
      });
      await appendAuditTx(tx, {
        orgId: req.auth.org,
        userId: req.auth.sub,
        action: "document.read",
        entityType: "ControlledDocument",
        entityId: doc.id
      });
      return row;
    });
    return reply.code(201).send({ acknowledgedAt: saved.acknowledgedAt, alreadyRead: false });
  });
  app.get("/api/v1/sms/documents/:id/file", limited, async (req, reply) => {
    if (!guard(req.auth.role, "document.read")) {
      return reply.code(403).send({ error: "forbidden" });
    }
    const { id } = req.params;
    const row = await prisma.controlledDocument.findFirst({
      /* Tenancy in the WHERE, never in a filter afterwards. */
      where: { id, ...tenantWhere(req) },
      /* `data` is selected ONLY here — no list, export or picture route
         touches it, which is what keeps a bytea in the row costing
         nothing anywhere else. */
      select: {
        data: true,
        contentType: true,
        sha256: true,
        filename: true,
        reference: true,
        version: true
      }
    });
    if (!row) return reply.code(404).send({ error: "not_found" });
    if (!row.data || !row.sha256) {
      return reply.code(409).send({
        error: "no_file_held",
        message: "This revision is registered but the document itself is held elsewhere. The register records its reference, revision, approver and review date."
      });
    }
    const buf = Buffer.from(row.data);
    const actual = createHash2("sha256").update(buf).digest("hex");
    if (actual !== row.sha256) {
      req.log.error({ id }, "controlled document hash mismatch");
      return reply.code(409).send({
        error: "hash_mismatch",
        message: "The stored document does not match the hash recorded when it was approved. It has not been served."
      });
    }
    const safe = `${row.reference}-${row.version}`.replace(/[^A-Za-z0-9._-]+/g, "_");
    return reply.header("content-type", row.contentType ?? "application/octet-stream").header("content-disposition", `attachment; filename="${safe}"`).send(buf);
  });
  app.post("/api/v1/sms/documents", limited, async (req, reply) => {
    if (!guard(req.auth.role, "document.manage")) return reply.code(403).send({ error: "forbidden" });
    const body = DocumentInput.safeParse(req.body);
    if (!body.success) return reply.code(400).send({ error: "invalid_document" });
    let file = {};
    if (body.data.data !== void 0) {
      if (!isBase64(body.data.data)) {
        return reply.code(400).send({
          error: "rejected",
          message: "That file did not arrive intact, so nothing was stored. Attach it again."
        });
      }
      const raw = Buffer.from(body.data.data, "base64");
      const verdict = checkEvidence(body.data.contentType, raw);
      if (!verdict.ok) {
        return reply.code(400).send({ error: "rejected", message: verdict.message });
      }
      file = {
        data: new Uint8Array(raw),
        contentType: verdict.type,
        bytes: verdict.bytes,
        /* THE SERVER'S HASH, over the bytes it is about to write —
           never one the client supplied. */
        sha256: createHash2("sha256").update(raw).digest("hex"),
        filename: body.data.filename?.slice(0, 160)
      };
    }
    const row = await prisma.$transaction(async (tx) => {
      await tx.controlledDocument.updateMany({
        where: { orgId: req.auth.org, reference: body.data.reference, supersededOn: null },
        data: { supersededOn: /* @__PURE__ */ new Date() }
      });
      const created = await tx.controlledDocument.create({
        data: {
          orgId: req.auth.org,
          title: body.data.title,
          reference: body.data.reference,
          version: body.data.version,
          approvedById: req.auth.sub,
          approvedOn: /* @__PURE__ */ new Date(),
          reviewBy: toDate(body.data.reviewBy),
          ...file
        }
      });
      await appendAuditTx(tx, {
        orgId: req.auth.org,
        userId: req.auth.sub,
        action: "document.approve",
        entityType: "ControlledDocument",
        entityId: created.id,
        detail: { reference: created.reference, version: created.version }
      });
      return created;
    });
    return reply.code(201).send({ document: row });
  });
  app.get("/api/v1/sms/findings", limited, async (req, reply) => {
    if (!guard(req.auth.role, "audit.read")) return reply.code(403).send({ error: "forbidden" });
    const rows = await prisma.auditFinding.findMany({
      where: tenantWhere(req),
      orderBy: [{ closedOn: "asc" }, { dueBy: "asc" }],
      take: LIST_LIMIT,
      include: { verifiedBy: { select: { name: true } } }
    });
    return reply.send({ findings: rows });
  });
  app.post("/api/v1/sms/findings", limited, async (req, reply) => {
    if (!guard(req.auth.role, "sms.audit.conduct")) return reply.code(403).send({ error: "forbidden" });
    const body = FindingInput.safeParse(req.body);
    if (!body.success) return reply.code(400).send({ error: "invalid_finding" });
    const row = await prisma.$transaction(async (tx) => {
      const created = await tx.auditFinding.create({
        data: {
          orgId: req.auth.org,
          auditRef: body.data.auditRef,
          finding: body.data.finding,
          elementId: body.data.elementId ?? null,
          severity: body.data.severity,
          ownerPost: body.data.ownerPost,
          dueBy: toDate(body.data.dueBy)
        }
      });
      await appendAuditTx(tx, {
        orgId: req.auth.org,
        userId: req.auth.sub,
        action: "finding.raise",
        entityType: "AuditFinding",
        entityId: created.id,
        detail: { auditRef: created.auditRef, severity: created.severity }
      });
      return created;
    });
    return reply.code(201).send({ finding: row });
  });
  app.post("/api/v1/sms/findings/:id/close", limited, async (req, reply) => {
    if (!guard(req.auth.role, "sms.audit.conduct")) return reply.code(403).send({ error: "forbidden" });
    const body = FindingClose.safeParse(req.body);
    if (!body.success) return reply.code(400).send({ error: "corrective_action_required" });
    const row = await prisma.$transaction(async (tx) => {
      const finding = await tx.auditFinding.findFirst({
        where: { id: req.params.id, orgId: req.auth.org }
      });
      if (!finding) return null;
      const updated = await tx.auditFinding.update({
        where: { id: finding.id },
        data: { correctiveAction: body.data.correctiveAction, closedOn: /* @__PURE__ */ new Date() }
      });
      await appendAuditTx(tx, {
        orgId: req.auth.org,
        userId: req.auth.sub,
        action: "finding.close",
        entityType: "AuditFinding",
        entityId: finding.id,
        detail: { auditRef: finding.auditRef }
      });
      return updated;
    });
    if (!row) return reply.code(404).send({ error: "not_found" });
    return reply.send({ finding: row });
  });
  app.post("/api/v1/sms/findings/:id/verify", limited, async (req, reply) => {
    if (!guard(req.auth.role, "sms.audit.verify")) return reply.code(403).send({ error: "forbidden" });
    const outcome = await prisma.$transaction(async (tx) => {
      const finding = await tx.auditFinding.findFirst({
        where: { id: req.params.id, orgId: req.auth.org }
      });
      if (!finding) return { code: 404 };
      if (!finding.closedOn) return { code: 409 };
      const updated = await tx.auditFinding.update({
        where: { id: finding.id },
        data: { verifiedById: req.auth.sub, verifiedOn: /* @__PURE__ */ new Date() }
      });
      await appendAuditTx(tx, {
        orgId: req.auth.org,
        userId: req.auth.sub,
        action: "finding.verify",
        entityType: "AuditFinding",
        entityId: finding.id,
        detail: { auditRef: finding.auditRef }
      });
      return { code: 200, finding: updated };
    });
    if (outcome.code === 404) return reply.code(404).send({ error: "not_found" });
    if (outcome.code === 409) {
      return reply.code(409).send({
        error: "not_closed",
        detail: "A finding is verified after the corrective action has been taken, not instead of it. Close it with what was done first."
      });
    }
    return reply.send({ finding: outcome.finding });
  });
  app.get("/api/v1/sms/training", limited, async (req, reply) => {
    const wide = guard(req.auth.role, "training.manage");
    if (!wide && !guard(req.auth.role, "training.read.own")) {
      return reply.code(403).send({ error: "forbidden" });
    }
    const rows = await prisma.trainingRecord.findMany({
      where: { ...tenantWhere(req), ...wide ? {} : { userId: req.auth.sub } },
      orderBy: [{ expiresOn: "asc" }],
      take: LIST_LIMIT,
      include: { user: { select: { name: true, role: true } } }
    });
    const now = /* @__PURE__ */ new Date();
    const standing = rows.map((t) => ({
      id: t.id,
      standing: standingOf(t.expiresOn, now),
      daysUntilExpiry: daysUntilExpiry(t.expiresOn, now)
    }));
    const people = wide ? await prisma.user.findMany({
      where: { ...tenantWhere(req), active: true },
      select: { id: true, name: true, role: true },
      take: LIST_LIMIT
    }) : [{ id: req.auth.sub, name: null, role: req.auth.role }];
    const heldBy = /* @__PURE__ */ new Map();
    for (const r of rows) {
      const held = heldBy.get(r.userId) ?? [];
      held.push(r.course);
      heldBy.set(r.userId, held);
    }
    const curriculum = people.map((p) => {
      const held = heldBy.get(p.id) ?? [];
      return {
        userId: p.id,
        name: p.name,
        role: p.role,
        required: requiredFor(p.role),
        gaps: gapsFor(p.role, held),
        unrecognised: unrecognisedIn(held)
      };
    });
    return reply.send({
      training: rows,
      scope: wide ? "org" : "own",
      curriculum,
      /* STATED IN THE PAYLOAD, not only in a doc nobody fetches. A
               syllabus nobody has read the instrument for is the one kind of
               wrong this product cannot ship, and a consumer of this route is
               entitled to know which it is holding.
      
               THIS USED TO SAY THE TOPICS CAME FROM A SEARCH INDEX'S
               RENDERING OF DOC 9859, and that was true until somebody read
               CAA-AC-SMS011 itself. The comment outlived the fact by one
               commit, which is why the instrument now travels BESIDE the
               flag: a bare `true` tells a consumer that something was
               verified without telling them against what, and the next
               person to change the source has to change a value rather than
               a sentence. Both are read from curriculum.ts rather than
               written here, so this route cannot claim a provenance the
               shared module does not hold. */
      curriculumVerifiedAgainstPrimary: CURRICULUM_VERIFIED_AGAINST_PRIMARY,
      curriculumInstrument: CURRICULUM_INSTRUMENT.reference,
      /* ELEMENT 4.1's OTHER HALF. The matrix said what had EXPIRED;
         this says what is about to, which is the only version a safety
         manager can act on. Ninety days, because training is a course
         somebody has to find, book and travel to. */
      standing,
      dueSoonWindowDays: TRAINING_DUE_SOON_DAYS
    });
  });
  app.post("/api/v1/sms/training", limited, async (req, reply) => {
    if (!guard(req.auth.role, "training.manage")) return reply.code(403).send({ error: "forbidden" });
    const body = TrainingInput.safeParse(req.body);
    if (!body.success) return reply.code(400).send({ error: "invalid_training_record" });
    const row = await prisma.$transaction(async (tx) => {
      const trainee = await tx.user.findFirst({
        where: { id: body.data.userId, orgId: req.auth.org },
        select: { id: true }
      });
      if (!trainee) return null;
      const created = await tx.trainingRecord.create({
        data: {
          orgId: req.auth.org,
          userId: body.data.userId,
          course: body.data.course,
          completedOn: new Date(body.data.completedOn),
          expiresOn: toDate(body.data.expiresOn)
        }
      });
      await appendAuditTx(tx, {
        orgId: req.auth.org,
        userId: req.auth.sub,
        action: "training.record",
        entityType: "TrainingRecord",
        entityId: created.id,
        detail: { course: created.course, trainee: created.userId }
      });
      return created;
    });
    if (!row) return reply.code(404).send({ error: "no_such_user" });
    return reply.code(201).send({ record: row });
  });
  app.get("/api/v1/sms/communications", limited, async (req, reply) => {
    if (!guard(req.auth.role, "document.read")) return reply.code(403).send({ error: "forbidden" });
    const rows = await prisma.safetyCommunication.findMany({
      where: tenantWhere(req),
      orderBy: { publishedOn: "desc" },
      take: LIST_LIMIT,
      include: { publishedBy: { select: { name: true } } }
    });
    return reply.send({ communications: rows });
  });
  app.post("/api/v1/sms/communications", limited, async (req, reply) => {
    if (!guard(req.auth.role, "communication.publish")) return reply.code(403).send({ error: "forbidden" });
    const body = CommunicationInput.safeParse(req.body);
    if (!body.success) return reply.code(400).send({ error: "invalid_communication" });
    const outcome = await prisma.$transaction(async (tx) => {
      if (body.data.reportId) {
        const report = await tx.safetyReport.findFirst({
          where: { id: body.data.reportId, orgId: req.auth.org },
          select: { id: true, isAnonymous: true }
        });
        if (!report) return { code: 404 };
        if (report.isAnonymous) return { code: 422 };
      }
      const created = await tx.safetyCommunication.create({
        data: {
          orgId: req.auth.org,
          title: body.data.title,
          body: body.data.body,
          publishedById: req.auth.sub,
          reportId: body.data.reportId ?? null
        }
      });
      await appendAuditTx(tx, {
        orgId: req.auth.org,
        userId: req.auth.sub,
        action: body.data.reportId ? "communication.feedback" : "communication.publish",
        entityType: "SafetyCommunication",
        entityId: created.id,
        detail: { title: created.title, aboutReport: Boolean(created.reportId) }
      });
      return { code: 201, communication: created };
    });
    if (outcome.code === 404) return reply.code(404).send({ error: "not_found" });
    if (outcome.code === 422) {
      return reply.code(422).send({
        error: "anonymous_report",
        detail: "There is nobody to tell, and a record joining feedback to an anonymous report would identify its reporter. Publish a bulletin to the organisation instead."
      });
    }
    return reply.code(201).send({ communication: outcome.communication });
  });
}
var LIST_LIMIT, iso, toDate, VoluntaryInput, PolicyDraft, AccountabilityInput, AppointmentInput, ExerciseInput, DocumentInput, FindingInput, FindingClose, TrainingInput, CommunicationInput;
var init_routes_sms = __esm({
  "apps/api/src/routes.sms.ts"() {
    "use strict";
    init_src();
    init_curriculum();
    init_core();
    init_evidence();
    LIST_LIMIT = 200;
    iso = z5.string().datetime({ offset: true }).or(z5.string().date());
    toDate = (s) => s ? new Date(s) : null;
    VoluntaryInput = z5.object({
      objective: z5.string().trim().max(4e3).optional(),
      scope: z5.string().trim().max(4e3).optional(),
      whoMayReport: z5.string().trim().max(4e3).optional(),
      whenToReport: z5.string().trim().max(4e3).optional(),
      howProcessed: z5.string().trim().max(4e3).optional(),
      contactPost: z5.string().trim().max(4e3).optional(),
      protection: z5.string().trim().max(4e3).optional()
    }).refine((v) => Object.values(v).some((x) => typeof x === "string" && x.length > 0), {
      message: "Send at least one field. An empty write defines nothing and would still audit."
    });
    PolicyDraft = z5.object({
      statement: z5.string().min(50).max(2e4),
      effectiveFrom: iso.optional()
    });
    AccountabilityInput = z5.object({
      post: z5.string().min(2).max(120),
      responsibility: z5.string().min(5).max(2e3),
      elementId: z5.string().max(8).optional()
    });
    AppointmentInput = z5.object({
      post: z5.string().min(2).max(120),
      userId: z5.string().uuid(),
      appointedOn: iso,
      letterRef: z5.string().max(120).optional()
    });
    ExerciseInput = z5.object({
      scenario: z5.string().min(10).max(4e3),
      heldOn: iso,
      participants: z5.string().min(2).max(2e3),
      findings: z5.string().min(5).max(8e3),
      planUpdated: z5.boolean().default(false)
    });
    DocumentInput = z5.object({
      title: z5.string().min(3).max(200),
      reference: z5.string().min(1).max(80),
      version: z5.string().min(1).max(40),
      reviewBy: iso.optional(),
      /* THE DOCUMENT ITSELF, and it stays OPTIONAL. A register entry for a
         manual held elsewhere is still a true register entry, and refusing
         one would push an operator's real revisions out of the register
         rather than into it. The screen says which rows carry a file. */
      contentType: z5.string().max(120).optional(),
      data: z5.string().max(EVIDENCE_MAX_BODY_BYTES).optional(),
      filename: z5.string().max(160).optional()
    });
    FindingInput = z5.object({
      auditRef: z5.string().min(1).max(80),
      finding: z5.string().min(10).max(8e3),
      elementId: z5.string().max(8).optional(),
      severity: z5.enum(["NONCONFORMITY", "OBSERVATION", "IMPROVEMENT"]).default("OBSERVATION"),
      ownerPost: z5.string().min(2).max(120),
      dueBy: iso.optional()
    });
    FindingClose = z5.object({
      correctiveAction: z5.string().min(10).max(8e3)
    });
    TrainingInput = z5.object({
      userId: z5.string().uuid(),
      course: z5.string().min(2).max(200),
      completedOn: iso,
      expiresOn: iso.optional()
    });
    CommunicationInput = z5.object({
      title: z5.string().min(3).max(200),
      body: z5.string().min(10).max(2e4),
      reportId: z5.string().uuid().optional()
    });
  }
});

// packages/shared/src/ssp.ts
function rollUp(categories, nationalIndicators, indicators, reportsByHrc) {
  const national = categories.filter((c) => c.nasp);
  const rows = national.map((c) => {
    const mine = indicators.filter((i) => i.hrc === c.code).map(
      (i) => Object.freeze({ name: i.name ?? "Untitled", periods: i.periods?.length ?? 0 })
    );
    const reports = reportsByHrc[c.code] ?? 0;
    const measuring = mine.some((i) => i.periods > 0);
    const standing = measuring ? "MEASURED" : reports > 0 || mine.length > 0 ? "REPORTED" : "UNSEEN";
    return Object.freeze({
      code: c.code,
      label: c.label,
      standing,
      indicators: Object.freeze(mine),
      reports,
      meaning: standing === "UNSEEN" ? UNSEEN_MEANING : standing === "REPORTED" ? REPORTED_MEANING : null,
      available: Object.freeze(
        nationalIndicators.filter((n) => n.hrc === c.code && n.reachable).map((n) => n.measure)
      )
    });
  });
  const nationalCodes = new Set(national.map((c) => c.code));
  const ownIndicators = indicators.filter(
    (i) => !i.hrc || !nationalCodes.has(i.hrc)
  ).length;
  return Object.freeze({ rows: Object.freeze(rows), ownIndicators });
}
var UNSEEN_MEANING, REPORTED_MEANING, SSP_CAVEAT;
var init_ssp = __esm({
  "packages/shared/src/ssp.ts"() {
    "use strict";
    UNSEEN_MEANING = "Nothing is tagged against this category. That is a statement about your records, not about your operation \u2014 it does not mean the risk is absent.";
    REPORTED_MEANING = "Your people are reporting events here and no indicator counts them yet. The data already exists.";
    SSP_CAVEAT = "Kenya's National Aviation Safety Plan names six high-risk categories and says what it counts under each. This shows which of them your own records can currently speak to. It is not a score and not a requirement \u2014 several may not apply to your operation, and deciding that is your call to make and to justify.";
  }
});

// packages/shared/src/nasp.ts
var NASP_SOURCE, NASP_INDICATORS, REACHABLE_NASP_INDICATORS;
var init_nasp = __esm({
  "packages/shared/src/nasp.ts"() {
    "use strict";
    NASP_SOURCE = "Kenya National Aviation Safety Plan 2023\u20132025, Kenya Civil Aviation Authority";
    NASP_INDICATORS = Object.freeze([
      Object.freeze({
        measure: "Go around due to unstable approach",
        per: "100 movements",
        hrc: "RE",
        reachable: true,
        rate: Object.freeze({ unit: "movements", per: 100 })
      }),
      Object.freeze({
        measure: "Rejected take-off",
        per: "100 movements",
        hrc: "RE",
        reachable: true,
        rate: Object.freeze({ unit: "movements", per: 100 })
      }),
      Object.freeze({
        measure: "Runway incursion incidents",
        per: "year",
        hrc: "RI",
        reachable: true
      }),
      Object.freeze({
        measure: "BWI incidents",
        per: "quarter, per aerodrome",
        hrc: "BWI",
        reachable: true
      }),
      Object.freeze({
        measure: "Loss of Control\u2013In Flight (LOC-I) accidents",
        per: "year",
        hrc: "LOC-I",
        reachable: true
      }),
      Object.freeze({
        measure: "Pilot incapacitation incidents",
        per: "year",
        reachable: true
      }),
      Object.freeze({
        measure: "TCAS/RA incidents",
        per: "year",
        hrc: "MAC",
        reachable: false,
        why: "Needs TCAS II, which is not fitted below 5,700 kg or 19 seats."
      }),
      Object.freeze({
        measure: "EGPWS trigger reports",
        per: "year",
        hrc: "CFIT",
        reachable: false,
        why: "Needs a TAWS download. Fitted on many types; readable on fewer."
      }),
      Object.freeze({
        measure: "Upset prevention and recovery training (UPRT)",
        per: "year",
        hrc: "LOC-I",
        reachable: true,
        why: "A training record rather than an occurrence count \u2014 read it from the matrix."
      })
    ]);
    REACHABLE_NASP_INDICATORS = NASP_INDICATORS.filter((i) => i.reachable);
  }
});

// packages/shared/src/spi.ts
function rate(period, per) {
  if (!Number.isFinite(period.events) || !Number.isFinite(period.exposure)) return null;
  if (period.events < 0 || period.exposure < 0) return null;
  if (period.exposure === 0) return null;
  if (!Number.isFinite(per) || per <= 0) return null;
  return period.events / period.exposure * per;
}
function rates(indicator) {
  return (indicator.periods ?? []).map((p) => rate(p, indicator.per)).filter((r) => r !== null);
}
function periodWindow(label) {
  const t = label.trim().toUpperCase().replace(/\s+/g, "-");
  const utc = (y, m, d) => new Date(Date.UTC(y, m, d));
  const quarter = /^(\d{4})-?Q([1-4])$/.exec(t);
  if (quarter) {
    const y = Number(quarter[1]);
    const q = Number(quarter[2]);
    return { from: utc(y, (q - 1) * 3, 1), to: utc(y, q * 3, 1) };
  }
  const day3 = /^(\d{4})-(\d{2})-(\d{2})$/.exec(t);
  if (day3) {
    const y = Number(day3[1]), m = Number(day3[2]), d = Number(day3[3]);
    if (m < 1 || m > 12 || d < 1 || d > 31) return null;
    return { from: utc(y, m - 1, d), to: utc(y, m - 1, d + 1) };
  }
  const month = /^(\d{4})-(\d{2})$/.exec(t);
  if (month) {
    const y = Number(month[1]), m = Number(month[2]);
    if (m < 1 || m > 12) return null;
    return { from: utc(y, m - 1, 1), to: utc(y, m, 1) };
  }
  const year = /^(\d{4})$/.exec(t);
  if (year) {
    const y = Number(year[1]);
    return { from: utc(y, 0, 1), to: utc(y + 1, 0, 1) };
  }
  return null;
}
function mean(xs) {
  if (!xs.length) throw new RangeError("mean of an empty series");
  return xs.reduce((a, b) => a + b, 0) / xs.length;
}
function stdDev(xs) {
  if (!xs.length) throw new RangeError("standard deviation of an empty series");
  const m = mean(xs);
  return Math.sqrt(xs.reduce((a, x) => a + (x - m) ** 2, 0) / xs.length);
}
function alertLevels(baseline, direction = "LOWER_IS_BETTER") {
  const usable = baseline.filter((x) => Number.isFinite(x));
  if (usable.length < MIN_BASELINE) {
    return {
      levels: null,
      reason: `${usable.length} of ${MIN_BASELINE} periods. An alert level set from fewer is set by whichever period was unusual, and it will fire on the next ordinary one.`
    };
  }
  const average = mean(usable);
  const sd = stdDev(usable);
  const sign = direction === "LOWER_IS_BETTER" ? 1 : -1;
  return {
    levels: {
      average,
      sd,
      one: average + sign * sd,
      two: average + sign * 2 * sd,
      three: average + sign * 3 * sd,
      points: usable.length
    },
    reason: null
  };
}
function beyond(value, level, direction) {
  return direction === "LOWER_IS_BETTER" ? value > level : value < level;
}
function watch(series, direction = "LOWER_IS_BETTER") {
  const out = [];
  for (let i = MIN_BASELINE; i < series.length; i += 1) {
    const { levels } = alertLevels(series.slice(0, i), direction);
    if (!levels) continue;
    const value = series[i];
    const sigma = beyond(value, levels.three, direction) ? 3 : beyond(value, levels.two, direction) ? 2 : beyond(value, levels.one, direction) ? 1 : 0;
    out.push({ index: i, value, levels, sigma });
  }
  return out;
}
function breaches(watched) {
  const found = [];
  for (const criterion of ALERT_CRITERIA) {
    for (let i = criterion.consecutive - 1; i < watched.length; i += 1) {
      const window = watched.slice(i - criterion.consecutive + 1, i + 1);
      const contiguous = window.every((p, n) => n === 0 || p.index === window[n - 1].index + 1);
      if (contiguous && window.every((p) => p.sigma >= criterion.sigma)) {
        found.push({
          criterion,
          at: window[window.length - 1].index,
          values: window.map((p) => p.value)
        });
      }
    }
  }
  return found;
}
function targetStatus(latest, target, direction) {
  if (latest === null || target === void 0 || !Number.isFinite(target)) return "NO_TARGET";
  const met = direction === "LOWER_IS_BETTER" ? latest <= target : latest >= target;
  return met ? "MET" : "MISSED";
}
function spiVerdict(indicator) {
  const series = rates(indicator);
  const latest = series.length ? series[series.length - 1] : null;
  const { levels, reason } = alertLevels(series.slice(0, -1), indicator.direction);
  const target = targetStatus(latest ?? null, indicator.target, indicator.direction);
  const watched = watch(series, indicator.direction);
  const found = breaches(watched);
  if (!levels) {
    return {
      rates: series,
      latest,
      levels: null,
      reason: reason ?? "",
      watched,
      breaches: found,
      target,
      headline: series.length === 0 ? "No periods recorded yet" : "Recording, with no alert levels yet"
    };
  }
  const live = found.filter((b) => b.at === series.length - 1);
  const worst2 = live.reduce(
    (a, b) => a === null || b.criterion.sigma > a.criterion.sigma ? b : a,
    null
  );
  const headline = worst2 ? `Alert \u2014 ${worst2.criterion.label.toLowerCase()}` : target === "MISSED" ? "Inside its alert levels, and short of its target" : "Inside its alert levels";
  return {
    rates: series,
    latest,
    levels,
    reason: "",
    watched,
    breaches: found,
    target,
    headline
  };
}
var INDICATOR_TYPES, APPENDIX_II_FIELDS, SPI_PRIMARY_READING, SPI_SUBMISSION_LOOP, MIN_BASELINE, ALERT_CRITERIA;
var init_spi = __esm({
  "packages/shared/src/spi.ts"() {
    "use strict";
    INDICATOR_TYPES = Object.freeze([
      { key: "ACTIVITY", label: "Activity-related (predictive or leading)" },
      { key: "OUTCOME", label: "Outcome-related (reactive or lagging)" }
    ]);
    APPENDIX_II_FIELDS = Object.freeze([
      {
        key: "areaOfOperations",
        ref: "Area",
        label: "Area of operations",
        source: "OPERATOR",
        note: "The operator's own scope. Nothing on an Indicator records it."
      },
      { ref: "A.1", label: "Indicator", source: "HELD", note: "Indicator.name." },
      {
        key: "description",
        ref: "A.2",
        label: "Description",
        source: "OPERATOR",
        note: "A sentence saying what the indicator watches. The name is not a description."
      },
      {
        key: "indicatorType",
        ref: "B.3",
        label: "Indicator type \u2014 activity-related (predictive or leading) or outcome-related (reactive or lagging)",
        source: "OPERATOR",
        note: "NOT derivable from `kind`. That axis is high- against lower-consequence \u2014 how rare the events are \u2014 and a LOWER_CONSEQUENCE indicator can be either activity- or outcome-related. Deriving it would file a leading indicator as lagging."
      },
      {
        key: "rationale",
        ref: "B.4",
        label: "Rationale",
        source: "OPERATOR",
        note: "Why this indicator, for this operator, now. A judgement nothing here holds."
      },
      {
        key: "limitations",
        ref: "B.5",
        label: "Limitations",
        source: "OPERATOR",
        note: "What the indicator cannot see. This product knows ONE limitation and says so: fewer than MIN_BASELINE periods and the alert level is not meaningful."
      },
      {
        key: "definitionOfTerms",
        ref: "B.6",
        label: "Definition of technical or specific terms",
        source: "OPERATOR",
        note: "The operator's vocabulary \u2014 what counts as an unstable approach here."
      },
      {
        ref: "B.7",
        label: "Calculation method / formula",
        source: "DERIVED",
        note: "events \xF7 exposure \xD7 `per`, in the operator's own exposureUnit. See rate()."
      },
      {
        key: "dataSets",
        ref: "C.8",
        label: "Data set(s)",
        source: "OPERATOR",
        note: "Which records feed it. This product is one such source and is rarely the only one."
      },
      { key: "dataProvider", ref: "C.9", label: "Provider", source: "OPERATOR", note: "Who supplies the data." },
      { key: "dataCustodian", ref: "C.10", label: "Custodian", source: "OPERATOR", note: "Who holds it." },
      {
        ref: "D",
        label: "Completed by / Approved by, with dates",
        source: "OPERATOR",
        note: "Indicator.owner is one post and the form wants two signatures with dates."
      },
      {
        ref: "E",
        label: "Accepted / not accepted, by whom, on what date",
        source: "AUTHORITY",
        note: "The Authority's own box. It is the acceptance letter \xA77.6.3 describes, and it means an indicator has a standing with the regulator \u2014 proposed, accepted, neither \u2014 that this product does not model at all."
      }
    ]);
    SPI_PRIMARY_READING = Object.freeze({
      document: "KCAA Advisory Circular CAA-AC-SMS009, Safety Performance Management",
      version: "January 2023",
      readOn: "2026-08-18",
      obtainedBy: "PDF supplied by the owner of this product; kcaa.or.ke is refused at this environment's egress proxy",
      changed: Object.freeze([
        "The submission requirement is \xA77.6.3, not \xA78.4 as a search summary had implied.",
        "Appendix II's thirteen captions are recorded verbatim in APPENDIX_II_FIELDS.",
        "The form carries no target, no alert level and no period \u2014 it registers a definition, not a measurement.",
        "Field 3 is activity- against outcome-related, a different axis from `kind`, and is not derived.",
        "Part E is the Authority's acceptance box, so an indicator has a regulator-facing standing this product does not model.",
        "\xA78.4, \xA78.5 and \xA78.7 as already quoted were confirmed word for word."
      ])
    });
    SPI_SUBMISSION_LOOP = Object.freeze([
      "The service provider completes form AC-SMS009 for each indicator.",
      "It is completed and approved internally \u2014 Part D wants both, with dates.",
      "The Authority reviews the submitted SPIs and agrees them with the service provider.",
      "The Authority marks Part E accepted or not accepted, and issues an acceptance letter."
    ]);
    MIN_BASELINE = 6;
    ALERT_CRITERIA = [
      {
        id: "single-3sd",
        label: "One period beyond 3 SD",
        consecutive: 1,
        sigma: 3,
        meaning: "A single period this far out is unlikely to be ordinary variation."
      },
      {
        id: "two-2sd",
        label: "Two consecutive beyond 2 SD",
        consecutive: 2,
        sigma: 2,
        meaning: "Twice in a row, well out. One period out is noise; two is a signal."
      },
      {
        id: "three-1sd",
        label: "Three consecutive beyond 1 SD",
        consecutive: 3,
        sigma: 1,
        meaning: "The drift. No single period looks alarming, which is exactly why this one goes unnoticed without a rule."
      }
    ];
  }
});

// packages/shared/src/spi-starters.ts
function startersFor(kind) {
  if (!kind) return SPI_STARTERS;
  return SPI_STARTERS.filter(
    (s) => s.forKinds === "ALL" || s.forKinds.includes(kind)
  );
}
var SPI_STARTERS;
var init_spi_starters = __esm({
  "packages/shared/src/spi-starters.ts"() {
    "use strict";
    SPI_STARTERS = Object.freeze([
      // ------------------------------------------------------------------
      // VOLUNTARY REPORTING RATE — the one every new programme should start
      // ------------------------------------------------------------------
      Object.freeze({
        id: "voluntary-reports-per-pilot-quarter",
        name: "Voluntary reports per pilot per quarter",
        kind: "LOWER_CONSEQUENCE",
        direction: "HIGHER_IS_BETTER",
        indicatorType: "ACTIVITY",
        exposureUnit: "pilot-quarters",
        per: 1,
        rationale: "Reporting culture is a leading indicator of safety margin. FSF research finds that report rates drop in the quarters before a major occurrence sequence; a sustained high rate is evidence that people are filing and not hiding. Doc 9859 \xA79.1.2 places reporting rate among the first indicators a programme should establish. It requires no special data source \u2014 the report count is already held.",
        formula: "Voluntary reports filed in the quarter \xF7 pilot-quarters in the same period. Pilot-quarters = (sum of each pilot's months employed in the quarter) \xF7 3. Count only voluntary reports, not MOR: a mandatory report is a legal act, not an indicator of proactive culture.",
        limitations: "A drop in rate may mean improved safety or reduced trust in the system \u2014 the two cannot be separated from the number alone. Investigate a decline before acting on it. Exclude probationary periods from the denominator if staff turnover is high.",
        forKinds: ["AOC", "RPAS"],
        youStillDecide: "Who counts as a pilot for this indicator (line pilots only, or trainees and check-and-training pilots too), and how you will compute pilot-quarters when someone leaves mid-quarter.",
        source: 'FSF, "Unleashing the Power of Safety Performance Indicators", 2016; ICAO Doc 9859 4th ed., \xA79.1.2.'
      }),
      // ------------------------------------------------------------------
      // TIME TO CLOSURE — the indicator the transition record was built for
      // ------------------------------------------------------------------
      Object.freeze({
        id: "days-to-first-closure",
        name: "Median days from receipt to first closure",
        kind: "LOWER_CONSEQUENCE",
        direction: "LOWER_IS_BETTER",
        indicatorType: "OUTCOME",
        exposureUnit: "reports closed",
        per: 1,
        rationale: "An occurrence report that has not been dispositioned is an unfulfilled investigation obligation. Doc 9859 \xA78.3 requires that every report is reviewed and findings recorded; a growing queue with no closures is the filing-cabinet failure those words were written about. Median rather than mean because a single complex investigation extending over months should not pull the average away from the typical experience.",
        formula: "For each report closed this quarter: days from createdAt to the FIRST closure transition, rounded to the nearest day. Report the median of that distribution. Use first closure only \u2014 a report closed on day 3, reopened, and reclosed on day 45 took three days to close; the reopening is a separate event.",
        limitations: "Counts only reports that reached closure. A persistently low median alongside a large untriaged backlog is a misleading positive: the queue may be moving fast on simple cases while complex ones age. Track alongside the untriaged count in the daily digest.",
        forKinds: "ALL",
        youStillDecide: "What your target is. Industry guidance is 30\u201390 days for a voluntary report with no investigation; an occurrence requiring investigation has no universal standard and your AOC conditions may specify one.",
        source: "ICAO Doc 9859 4th ed., \xA78.3; EASA ALoSP Guidance Material, 2019, \xA73.4."
      }),
      // ------------------------------------------------------------------
      // MRO — maintenance quality
      // ------------------------------------------------------------------
      Object.freeze({
        id: "first-attempt-check-pass-rate",
        name: "First-attempt check pass rate",
        kind: "LOWER_CONSEQUENCE",
        direction: "HIGHER_IS_BETTER",
        indicatorType: "ACTIVITY",
        exposureUnit: "checks completed",
        per: 100,
        rationale: "Rework is maintenance safety's most direct leading indicator: a task that has to be done twice was done wrong once. A declining pass rate surfaces a competence gap, a tooling problem or a workload issue before an unsafe release. First-attempt is the measure because a check that passes on the second attempt after a hint is not a pass.",
        formula: "Checks that passed on the first attempt \xF7 total checks completed \xD7 100. Define 'check' consistently: an inspection card sign-off, an RTS check \u2014 whichever your quality system already counts. Count by work order, not by line.",
        limitations: "The denominator is the checks your quality system records, not every maintenance act. A shop that records fewer checks will appear better. Define the scope in the indicator definition before the first period, and hold it.",
        forKinds: ["MRO"],
        youStillDecide: "Which check types enter the denominator, who signs the pass or fail, and whether training checks are included (they should not be \u2014 a trainee under supervision failing a first attempt is not a quality system defect).",
        source: 'EASA ALoSP Guidance Material, 2019, \xA73.4; FSF, "Unleashing the Power of Safety Performance Indicators", 2016.'
      }),
      // ------------------------------------------------------------------
      // MEL — operational risk in maintenance
      // ------------------------------------------------------------------
      Object.freeze({
        id: "mel-deferral-age-days",
        name: "Average MEL deferral open days",
        kind: "LOWER_CONSEQUENCE",
        direction: "LOWER_IS_BETTER",
        indicatorType: "OUTCOME",
        exposureUnit: "deferrals closed",
        per: 1,
        rationale: "How long an MEL item stays open is a proxy for whether the deferral process is functioning as a safety valve or as a delay mechanism. An MEL exists to allow dispatch with an inoperative item within approved limits; a deferral that exceeds those limits on average is an indicator that the limits are not being treated as limits.",
        formula: "For each MEL deferral closed this quarter: the number of days from the deferral date to the rectification date. Average across all deferrals closed in the period. Exclude items deferred under a fleet relief extension if those are tracked separately.",
        limitations: "Depends on your MEL deferred-defect log being up to date. An average below the limit does not mean no item exceeded it \u2014 check the distribution alongside the mean. Does not distinguish Category A, B, C, D deferrals; stratify if one category is driving the average.",
        forKinds: ["AOC"],
        youStillDecide: "Whether to compute per-category or overall, and how to handle fleet-wide relief items that are managed at operator level rather than aircraft level.",
        source: 'ICAO Doc 9859 4th ed., Appendix 4; FSF, "Unleashing the Power of Safety Performance Indicators", 2016.'
      }),
      // ------------------------------------------------------------------
      // HIGH-CONSEQUENCE RATE — for AOC operators with enough movements
      // ------------------------------------------------------------------
      Object.freeze({
        id: "high-risk-occurrence-rate-per-1000-movements",
        name: "High-risk category occurrence rate per 1,000 movements",
        kind: "HIGH_CONSEQUENCE",
        direction: "LOWER_IS_BETTER",
        indicatorType: "OUTCOME",
        exposureUnit: "movements",
        per: 1e3,
        rationale: "An operator whose SPIs include only LOWER_CONSEQUENCE indicators cannot demonstrate to the Authority that it is measuring the events with the highest consequence potential. Doc 9859 \xA79.2 requires SPIs to span the safety performance spectrum. The numerator is an ADREP occurrence category count \u2014 RE, RI, LOC-I, MAC, CFIT or ARC \u2014 already tagged at disposition and not typed separately.",
        formula: "Occurrences in this period coded to one of the six ICAO high-risk categories (RE, RI, LOC-I, MAC, CFIT, ARC) \xF7 movements in the same period \xD7 1,000. Movements = departures + arrivals. Count an occurrence once even if it meets multiple categories.",
        limitations: "A low rate at small fleet sizes is statistically unreliable: an operator with 500 movements per quarter needs six or more periods before alert levels are meaningful. Show the raw event count alongside the rate. Note that CICTT coding in this product carries the caveat that definitions have not been verified against the primary instrument.",
        forKinds: ["AOC", "HELIPORT"],
        youStillDecide: "Whether to include all six ICAO high-risk categories or only those relevant to your operations (a VFR-only operator may have no CFIT exposure), and how you count movements if your ops log records cycles rather than movements.",
        source: "ICAO Doc 9859 4th ed., \xA79.2 and Appendix 4; Kenya National Aviation Safety Plan 2023\u20132025, \xA75."
      }),
      // ------------------------------------------------------------------
      // RPAS / HELIPORT — operations-based rate
      // ------------------------------------------------------------------
      Object.freeze({
        id: "occurrence-rate-per-100-operations",
        name: "Reportable occurrence rate per 100 operations",
        kind: "HIGH_CONSEQUENCE",
        direction: "LOWER_IS_BETTER",
        indicatorType: "OUTCOME",
        exposureUnit: "operations",
        per: 100,
        rationale: "Movements are the natural denominator for fixed-wing operations, but RPAS and helipad operations are better measured per flight operation or sortie. A reportable occurrence \u2014 one that would trigger an MOR \u2014 is the threshold KCAA's own form uses, which aligns this indicator with the legal definition rather than with an internal severity scale.",
        formula: "Occurrences that meet the MOR threshold this period \xF7 operations in the same period \xD7 100. An operation is one sortie or flight. Count occurrences on the same event-count basis as voluntary reports \u2014 a single event is one occurrence even if it generates multiple reports.",
        limitations: "Requires a consistent definition of 'operation' that is logged and retrievable. A small number of operations per period makes any non-zero rate appear alarming; the raw count is more informative until the denominator exceeds 200.",
        forKinds: ["RPAS", "HELIPORT"],
        youStillDecide: "Whether to count ground operations (taxi and pre-flight) as part of the operation or whether an operation begins at power-on for take-off.",
        source: "ICAO Doc 9859 4th ed., \xA79.1; EASA ALoSP Guidance Material, 2019, \xA73.4."
      })
    ]);
  }
});

// apps/api/src/routes.spi.ts
import { z as z6 } from "zod";
function guard2(role, permission) {
  return can(role, permission);
}
async function spiRoutes(app) {
  const limited = {
    preHandler: authenticate,
    /* EVERY ROUTE IN THIS FILE WRITES ROWS, AND NONE OF THEM WAS LIMITED.
    
           Found by asking which route files declare no limit at all rather
           than by reading any one of them: this file, routes.register.ts and
           routes.spi.ts were the three, and all three accept POSTs that
           create records. Authentication bounds WHO can do it; it does not
           bound how often, so a stuck retry loop or a stolen token wrote
           until something else broke.
    
           60 a minute, matching routes.config.ts — this is a safety manager
           adding entries on a working screen, not a reporter at a strip, so
           the limit only has to be below "a script". The tighter number
           belongs on routes.attachments.ts, which is the one that writes
           megabytes. */
    config: { rateLimit: { max: 60, timeWindow: "1 minute" } }
  };
  const paid = {
    ...limited,
    preHandler: [authenticate, requireEntitlement("RECORD_INDICATOR_PERIOD")]
  };
  app.get("/api/v1/spi/starters", limited, async (req, reply) => {
    if (!guard2(req.auth.role, "spi.read")) return reply.code(403).send({ error: "forbidden" });
    const kind = String(req.query.kind ?? "").toUpperCase();
    const VALID_KINDS = ["AOC", "RPAS", "HELIPORT", "MRO"];
    const filtered = VALID_KINDS.includes(kind) ? startersFor(kind) : SPI_STARTERS;
    return reply.send({
      starters: filtered,
      caveat: "These are offered as starting points, not requirements. Each organisation develops its own SPIs under Doc 9859 \xA79.1. Edit the pre-filled fields to match your operations before submitting the form to the Authority."
    });
  });
  app.get("/api/v1/spi", paid, async (req, reply) => {
    if (!guard2(req.auth.role, "spi.read")) return reply.code(403).send({ error: "forbidden" });
    const indicators = await prisma.spi.findMany({
      where: tenantWhere(req),
      orderBy: [{ name: "asc" }],
      take: LIST_LIMIT2,
      include: {
        /* Ordered by insertion, not by label. A label is the
           operator's own cadence — "2026-Q1", "March", "Week 12" — and
           the server has no business parsing it into a calendar. The
           shared module has periodOrder() for the cases where it can
           be read; where it cannot, the order the operator entered
           them in is the only truth available. */
        periods: {
          orderBy: [{ createdAt: "asc" }],
          take: LIST_LIMIT2,
          select: {
            id: true,
            label: true,
            events: true,
            exposure: true,
            /* Element 3.1's evidence: "a record of what happened the
               last time one was crossed". Returned with the series so
               the screen can show the response beside the period that
               prompted it, rather than in a list somewhere else. */
            actionTaken: true,
            actionOn: true
          }
        }
      }
    });
    return reply.send({ indicators });
  });
  app.get("/api/v1/ssp", limited, async (req, reply) => {
    const auth = req.auth;
    if (!guard2(auth.role, "spi.read")) return reply.code(403).send({ error: "forbidden" });
    const indicators = await prisma.spi.findMany({
      where: tenantWhere(req),
      take: LIST_LIMIT2,
      select: { name: true, hrc: true, periods: { select: { id: true }, take: LIST_LIMIT2 } }
    });
    const withheld = [];
    const reportsByHrc = {};
    if (guard2(auth.role, "report.read.org")) {
      const tagged = await prisma.safetyReport.findMany({
        /* RETRACTED REPORTS DO NOT COUNT, and the gate caught this
           before it shipped. A retraction is a tombstone — the row
           stays so the audit chain is unbroken, and it stops counting.
           Including them here would tell a regulator that an operator
           is seeing events in a category on the strength of reports
           that operator has withdrawn, on the one screen built to be
           shown to that regulator. */
        where: { ...tenantWhere(req), retractedAt: null },
        take: LIST_LIMIT2,
        select: { hrcTags: true }
      });
      for (const r of tagged) {
        for (const tag of r.hrcTags) {
          reportsByHrc[tag] = (reportsByHrc[tag] ?? 0) + 1;
        }
      }
    } else {
      withheld.push(
        "Counts of reports tagged against each category \u2014 these need report access. A category shown as unseen may only be unseen by you."
      );
    }
    return reply.send({
      ...rollUp(HRC_CATEGORIES, NASP_INDICATORS, indicators, reportsByHrc),
      caveat: SSP_CAVEAT,
      source: NASP_SOURCE,
      withheld
    });
  });
  app.post("/api/v1/spi", paid, async (req, reply) => {
    if (!guard2(req.auth.role, "spi.configure")) {
      return reply.code(403).send({ error: "forbidden" });
    }
    const parsed = IndicatorSchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ error: "invalid", detail: parsed.error.flatten() });
    }
    const existing = await prisma.spi.findFirst({
      where: { ...tenantWhere(req), name: parsed.data.name },
      select: { id: true }
    });
    if (existing) {
      return reply.code(409).send({
        error: "duplicate_name",
        message: "An indicator with that name already exists for this operator."
      });
    }
    const created = await prisma.$transaction(async (tx) => {
      const spi = await tx.spi.create({
        data: { orgId: req.auth.org, ...parsed.data }
      });
      await appendAuditTx(tx, {
        orgId: req.auth.org,
        userId: req.auth.sub,
        action: "spi.configure",
        entityType: "Spi",
        entityId: spi.id
      });
      return spi;
    });
    return reply.code(201).send({ indicator: { ...created, periods: [] } });
  });
  app.put("/api/v1/spi/:id/submission", paid, async (req, reply) => {
    if (!guard2(req.auth.role, "spi.configure")) {
      return reply.code(403).send({ error: "forbidden" });
    }
    const { id } = req.params;
    const parsed = SubmissionSchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ error: "invalid", detail: parsed.error.flatten() });
    }
    const data = {};
    for (const [k, v] of Object.entries(parsed.data)) {
      if (v !== void 0) data[k] = v === null ? null : v;
    }
    for (const k of ["submittedOn", "acceptedOn"]) {
      if (typeof data[k] === "string") data[k] = /* @__PURE__ */ new Date(`${data[k]}T00:00:00.000Z`);
    }
    const updated = await prisma.$transaction(async (tx) => {
      const r = await tx.spi.updateMany({ where: { ...tenantWhere(req), id }, data });
      if (r.count === 0) return null;
      await appendAuditTx(tx, {
        orgId: req.auth.org,
        userId: req.auth.sub,
        action: "spi.configure",
        entityType: "Spi",
        entityId: id
      });
      return tx.spi.findFirst({ where: { ...tenantWhere(req), id } });
    });
    if (!updated) return reply.code(404).send({ error: "not_found" });
    return reply.send({ indicator: updated });
  });
  app.post("/api/v1/spi/:id/periods/:periodId/action", paid, async (req, reply) => {
    if (!guard2(req.auth.role, "spi.configure")) {
      return reply.code(403).send({ error: "forbidden" });
    }
    const { id, periodId } = req.params;
    const parsed = ActionSchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ error: "invalid", detail: parsed.error.flatten() });
    }
    const period = await prisma.spiPeriod.findFirst({
      where: { ...tenantWhere(req), id: periodId, spiId: id },
      select: { id: true }
    });
    if (!period) return reply.code(404).send({ error: "not_found" });
    const saved = await prisma.$transaction(async (tx) => {
      const row = await tx.spiPeriod.update({
        where: { id: period.id },
        data: {
          actionTaken: parsed.data.actionTaken,
          ...parsed.data.actionOn ? { actionOn: /* @__PURE__ */ new Date(`${parsed.data.actionOn}T00:00:00.000Z`) } : {}
        }
      });
      await appendAuditTx(tx, {
        orgId: req.auth.org,
        userId: req.auth.sub,
        action: "spi.period.action",
        entityType: "SpiPeriod",
        entityId: row.id
      });
      return row;
    });
    return reply.send({
      period: {
        id: saved.id,
        label: saved.label,
        events: saved.events,
        exposure: saved.exposure,
        actionTaken: saved.actionTaken,
        actionOn: saved.actionOn ? saved.actionOn.toISOString().slice(0, 10) : null
      }
    });
  });
  app.get("/api/v1/spi/observed", limited, async (req, reply) => {
    if (!guard2(req.auth.role, "spi.read")) return reply.code(403).send({ error: "forbidden" });
    const label = String(req.query.label ?? "");
    const window = periodWindow(label);
    if (!window) {
      return reply.code(422).send({
        error: "unrecognised_period",
        message: `"${label}" is not a period this product can turn into a date range, so it cannot count reports for it. Quarters (2026-Q1), months (2026-08), days and years are understood; anything else is yours to count.`
      });
    }
    const rows = await prisma.safetyReport.groupBy({
      by: ["type"],
      /* An indicator counts what was REPORTED, and a withdrawn
         duplicate was not a second report. Counting it inflates the
         reporting rate this element is measured on — which is the one
         number an operator is tempted to like the look of. */
      where: { ...tenantWhere(req), retractedAt: null, createdAt: { gte: window.from, lt: window.to } },
      _count: { _all: true }
    });
    return reply.send({
      label,
      from: window.from.toISOString(),
      to: window.to.toISOString(),
      countedBy: "createdAt",
      total: rows.reduce((n, r) => n + r._count._all, 0),
      byType: Object.fromEntries(rows.map((r) => [r.type, r._count._all])),
      caveat: "This is how many reports arrived in that window. It is this indicator's event count only if this indicator counts reports \u2014 check before using it."
    });
  });
  app.post("/api/v1/spi/:id/periods", paid, async (req, reply) => {
    if (!guard2(req.auth.role, "spi.configure")) {
      return reply.code(403).send({ error: "forbidden" });
    }
    const { id } = req.params;
    const parsed = PeriodSchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ error: "invalid", detail: parsed.error.flatten() });
    }
    const spi = await prisma.spi.findFirst({
      where: { ...tenantWhere(req), id },
      select: { id: true }
    });
    if (!spi) return reply.code(404).send({ error: "not_found" });
    const clash = await prisma.spiPeriod.findFirst({
      where: { spiId: spi.id, label: parsed.data.label },
      select: { id: true }
    });
    if (clash) {
      return reply.code(409).send({
        error: "duplicate_period",
        message: `This indicator already has a period labelled "${parsed.data.label}".`
      });
    }
    const created = await prisma.$transaction(async (tx) => {
      const period = await tx.spiPeriod.create({
        data: { orgId: req.auth.org, spiId: spi.id, ...parsed.data }
      });
      await appendAuditTx(tx, {
        orgId: req.auth.org,
        userId: req.auth.sub,
        action: "spi.period.append",
        entityType: "SpiPeriod",
        entityId: period.id
      });
      return period;
    });
    return reply.code(201).send({
      period: {
        id: created.id,
        label: created.label,
        events: created.events,
        exposure: created.exposure
      }
    });
  });
}
var LIST_LIMIT2, KINDS, DIRECTIONS, text, isoDay, SubmissionSchema, IndicatorSchema, ActionSchema, PeriodSchema;
var init_routes_spi = __esm({
  "apps/api/src/routes.spi.ts"() {
    "use strict";
    init_src();
    init_ssp();
    init_nasp();
    init_spi();
    init_spi_starters();
    init_core();
    LIST_LIMIT2 = 200;
    KINDS = ["LOWER_CONSEQUENCE", "HIGHER_CONSEQUENCE"];
    DIRECTIONS = ["LOWER_IS_BETTER", "HIGHER_IS_BETTER"];
    text = (max) => z6.string().trim().max(max).nullable().optional();
    isoDay = z6.string().regex(/^\d{4}-\d{2}-\d{2}$/).refine((d) => !Number.isNaN(Date.parse(d)), "not a date").nullable().optional();
    SubmissionSchema = z6.object({
      areaOfOperations: text(160),
      description: text(2e3),
      indicatorType: z6.enum(["ACTIVITY", "OUTCOME"]).nullable().optional(),
      rationale: text(2e3),
      limitations: text(2e3),
      definitionOfTerms: text(2e3),
      dataSets: text(1e3),
      dataProvider: text(160),
      dataCustodian: text(160),
      submittedOn: isoDay,
      acceptance: z6.enum(["ACCEPTED", "NOT_ACCEPTED"]).nullable().optional(),
      acceptedOn: isoDay
    }).strict().refine((b) => Object.keys(b).length > 0, { message: "empty update" }).refine((b) => !(b.acceptedOn && b.acceptance === void 0), {
      message: "an acceptance date needs an acceptance"
    });
    IndicatorSchema = z6.object({
      name: z6.string().trim().min(1).max(160),
      kind: z6.enum(KINDS),
      exposureUnit: z6.string().trim().min(1).max(60),
      /* Positive and finite. A rate basis of zero divides by nothing, and a
         negative one inverts the indicator silently. */
      per: z6.number().finite().positive(),
      direction: z6.enum(DIRECTIONS),
      target: z6.number().finite().optional(),
      owner: z6.string().trim().max(160).default(""),
      /* WHICH NATIONAL HIGH-RISK CATEGORY THIS BEARS ON, if the operator
           says it bears on one.
      
           Validated against the taxonomy rather than accepted as free text,
           because the rollup groups by this value and a typo would silently
           put an indicator in a category of its own — a gap that reads as a
           gap in the operator's SMS rather than in their spelling.
      
           `.nullable()` as well as optional: clearing the tag on an existing
           indicator has to be expressible, and an absent key would read as
           "leave it alone". */
      hrc: z6.string().refine((c) => HRC_CATEGORIES.some((h) => h.code === c), {
        message: "hrc must be a category code from the taxonomy"
      }).nullable().optional()
    });
    ActionSchema = z6.object({
      actionTaken: z6.string().trim().min(1).max(4e3),
      actionOn: z6.string().trim().regex(/^\d{4}-\d{2}-\d{2}$/).optional()
    });
    PeriodSchema = z6.object({
      label: z6.string().trim().min(1).max(40),
      /* Events are a count and exposure is a measure, so they are typed
         differently. Both refuse negatives: a negative count is not a
         correction, it is a data-entry error that would drag a rate below
         zero and read as an improvement. */
      events: z6.number().int().min(0),
      exposure: z6.number().finite().positive()
    });
  }
});

// packages/shared/src/holder.ts
function requiredHolder(band) {
  return REQUIREMENT[band];
}
function meetsRequirement(band, post) {
  const need = AUTHORITY_ORDER.indexOf(requiredHolder(band).minimum);
  const have = AUTHORITY_ORDER.indexOf(post ?? "");
  if (have < 0) return "unknown";
  return have >= need ? "meets" : "below";
}
var AUTHORITY_ORDER, REQUIREMENT;
var init_holder = __esm({
  "packages/shared/src/holder.ts"() {
    "use strict";
    AUTHORITY_ORDER = [
      "SAFETY_OFFICER",
      "SAFETY_MANAGER",
      "ACCOUNTABLE_EXECUTIVE"
    ];
    REQUIREMENT = Object.freeze({
      INTOLERABLE: {
        minimum: "ACCOUNTABLE_EXECUTIVE",
        because: "An intolerable risk is not acceptable at any level of benefit. It is not owned down the organisation \u2014 it is carried by the accountable executive until the controls change, or it is not carried at all."
      },
      TOLERABLE: {
        minimum: "ACCOUNTABLE_EXECUTIVE",
        because: "A tolerable risk is one being accepted because reducing it further is not reasonably practicable. That is a judgement about cost against safety, so it belongs with the post that can actually spend the money."
      },
      ACCEPTABLE: {
        minimum: "SAFETY_MANAGER",
        because: "An acceptable risk is managed rather than accepted upward. The safety manager owns it, reviews it, and escalates if the position changes."
      }
    });
  }
});

// packages/shared/src/signature.ts
function authorityOf(role) {
  return ROLE_AUTHORITY[role ?? ""] ?? null;
}
function refuseSignature(band, role) {
  const need = requiredHolder(band);
  if (band === "INTOLERABLE") {
    return {
      error: "not_ownable",
      requires: need.minimum,
      message: "This risk is intolerable as it stands. It cannot be accepted by anybody, at any level \u2014 the controls have to change, not the signature."
    };
  }
  const have = authorityOf(role);
  if (have === null || AUTHORITY_ORDER.indexOf(have) < AUTHORITY_ORDER.indexOf(need.minimum)) {
    return {
      error: "below_authority",
      requires: need.minimum,
      message: `${need.because} Somebody holding ${labelFor(need.minimum)} has to sign this one.`
    };
  }
  return null;
}
function labelFor(post) {
  return {
    SAFETY_OFFICER: "Safety Officer",
    SAFETY_MANAGER: "Safety Manager",
    ACCOUNTABLE_EXECUTIVE: "Accountable Executive"
  }[post];
}
var ROLE_AUTHORITY;
var init_signature = __esm({
  "packages/shared/src/signature.ts"() {
    "use strict";
    init_holder();
    ROLE_AUTHORITY = Object.freeze({
      FRONTLINE: null,
      SAFETY_OFFICER: "SAFETY_OFFICER",
      INVESTIGATOR: "SAFETY_OFFICER",
      SAFETY_MANAGER: "SAFETY_MANAGER",
      /* The heads of department. Senior to the safety manager in an
         operator's structure — they hold the budget and the schedule for
         their own department — and below the accountable executive, who is
         the one post that answers for the whole operation. RA 1210's shape
         exactly: the Operating Duty Holder is not the Senior one. */
      KEY_MANAGEMENT: "SAFETY_MANAGER",
      ACCOUNTABLE_EXECUTIVE: "ACCOUNTABLE_EXECUTIVE",
      REGULATOR_INSPECTOR: null,
      SYSTEM_ADMIN: null
    });
  }
});

// packages/shared/src/discovery.ts
var METHODS, ROUTES, BY_KEY, DISCOVERY_KEYS;
var init_discovery = __esm({
  "packages/shared/src/discovery.ts"() {
    "use strict";
    METHODS = Object.freeze({
      REACTIVE: Object.freeze({
        label: "Reactive",
        means: "Found because something already happened \u2014 an occurrence, an incident, a report somebody filed.",
        definition: "Any method that responds to past occurrences."
      }),
      PROACTIVE: Object.freeze({
        label: "Proactive",
        means: "Found by looking, before anything happened \u2014 an audit, a workshop, a survey, an assessment of a change.",
        definition: "Any method that actively searches for potential safety risks through the analysis of an organization's activities prior to occurrence."
      }),
      PREDICTIVE: Object.freeze({
        label: "Predictive",
        means: "Found by watching the system's own behaviour for where it is drifting \u2014 indicator trends, degraded defences.",
        definition: "Any method that continuously analyzes current and historical information to forecast potential future occurrences."
      })
    });
    ROUTES = Object.freeze([
      Object.freeze({
        key: "REPORT",
        method: "REACTIVE",
        label: "An occurrence report",
        where: "/triage"
      }),
      Object.freeze({
        key: "AUDIT",
        method: "PROACTIVE",
        label: "An internal audit finding",
        where: "/sms"
      }),
      Object.freeze({
        key: "WORKSHOP",
        method: "PROACTIVE",
        label: "A hazard identification workshop",
        where: null
      }),
      Object.freeze({
        key: "CHANGE",
        method: "PROACTIVE",
        label: "Assessing a change",
        where: "/sms"
      }),
      Object.freeze({
        key: "INDICATOR",
        method: "PREDICTIVE",
        label: "An indicator trend",
        where: "/toolkits/spi"
      }),
      Object.freeze({
        key: "BARRIER",
        method: "PREDICTIVE",
        label: "A degraded defence",
        where: "/picture"
      })
    ]);
    BY_KEY = new Map(ROUTES.map((r) => [r.key, r]));
    DISCOVERY_KEYS = ROUTES.map((r) => r.key);
  }
});

// apps/api/src/routes.register.ts
import { z as z7 } from "zod";
function guard3(role, permission) {
  return can(role, permission);
}
async function registerRoutes(app) {
  const limited = {
    preHandler: authenticate,
    /* EVERY ROUTE IN THIS FILE WRITES ROWS, AND NONE OF THEM WAS LIMITED.
    
           Found by asking which route files declare no limit at all rather
           than by reading any one of them: this file, routes.register.ts and
           routes.spi.ts were the three, and all three accept POSTs that
           create records. Authentication bounds WHO can do it; it does not
           bound how often, so a stuck retry loop or a stolen token wrote
           until something else broke.
    
           60 a minute, matching routes.config.ts — this is a safety manager
           adding entries on a working screen, not a reporter at a strip, so
           the limit only has to be below "a script". The tighter number
           belongs on routes.attachments.ts, which is the one that writes
           megabytes. */
    config: { rateLimit: { max: 60, timeWindow: "1 minute" } }
  };
  const paid = {
    ...limited,
    preHandler: [authenticate, requireEntitlement("EDIT_REGISTER")]
  };
  app.get("/api/v1/register", paid, async (req, reply) => {
    if (!guard3(req.auth.role, "hazard.manage") && !guard3(req.auth.role, "report.read.org")) {
      return reply.code(403).send({ error: "forbidden" });
    }
    const hazards = await prisma.hazard.findMany({
      where: tenantWhere(req),
      orderBy: [{ createdAt: "desc" }],
      take: LIST_LIMIT3,
      include: {
        assessments: {
          orderBy: [{ createdAt: "desc" }],
          take: 1,
          select: {
            id: true,
            consequence: true,
            severity: true,
            likelihood: true,
            score: true,
            tolerability: true,
            controls: true,
            residualSeverity: true,
            residualLikelihood: true,
            residualScore: true,
            residualTolerability: true,
            owner: true,
            reviewBy: true,
            status: true,
            acceptedById: true,
            acceptedAt: true,
            alarpJustification: true
          }
        }
      }
    });
    const acceptorIds = [
      ...new Set(
        hazards.map((h) => h.assessments[0]?.acceptedById).filter((id) => !!id)
      )
    ];
    const acceptors = acceptorIds.length ? await prisma.user.findMany({
      where: { orgId: req.auth.org, id: { in: acceptorIds } },
      select: { id: true, name: true }
    }) : [];
    const nameOf = new Map(acceptors.map((u) => [u.id, u.name]));
    const entries = hazards.filter((h) => h.assessments[0]).map((h) => {
      const a = h.assessments[0];
      return {
        id: h.id,
        assessmentId: a.id,
        hazard: h.title,
        /* WHERE IT CAME FROM, rendered rather than inferred. An
           operator asked "how much of your register came from your
           own people" has to be able to answer it, and a register
           that cannot tell a typed hazard from a reported one cannot.
           The report's ID travels; nothing of its content does. */
        source: h.source,
        discovery: h.discovery ?? null,
        fromReportId: h.reportId ?? void 0,
        consequence: a.consequence,
        severity: a.severity,
        likelihood: a.likelihood,
        controls: a.controls ?? "",
        residualSeverity: a.residualSeverity ?? void 0,
        residualLikelihood: a.residualLikelihood ?? void 0,
        owner: a.owner ?? "",
        reviewBy: a.reviewBy ? a.reviewBy.toISOString().slice(0, 10) : "",
        status: a.status,
        acceptedAt: a.acceptedAt ? a.acceptedAt.toISOString().slice(0, 10) : "",
        /* Empty rather than "Unknown" when the acceptor has since been
           offboarded: a name this product cannot verify is worse than
           a date and an audit trail that can be read. */
        acceptedBy: a.acceptedById && nameOf.get(a.acceptedById) || "",
        alarpJustification: a.alarpJustification ?? ""
      };
    });
    return reply.send({ entries });
  });
  app.post("/api/v1/register", paid, async (req, reply) => {
    if (!guard3(req.auth.role, "hazard.manage")) {
      return reply.code(403).send({ error: "forbidden" });
    }
    const parsed = EntrySchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ error: "invalid", detail: parsed.error.flatten() });
    }
    const e = parsed.data;
    const score = riskScore(e.severity, e.likelihood);
    const band = tolerability(e.severity, e.likelihood);
    const residual = e.residualSeverity && e.residualLikelihood ? {
      residualSeverity: e.residualSeverity,
      residualLikelihood: e.residualLikelihood,
      residualScore: riskScore(
        e.residualSeverity,
        e.residualLikelihood
      ),
      residualTolerability: tolerability(
        e.residualSeverity,
        e.residualLikelihood
      )
    } : {};
    if (e.fromReportId) {
      const report = await prisma.safetyReport.findFirst({
        where: { ...tenantWhere(req), id: e.fromReportId },
        select: { id: true }
      });
      if (!report) {
        return reply.code(404).send({
          error: "report_not_found",
          message: "That report is not one of this operator's. A register entry can only be raised from a report the safety office actually holds."
        });
      }
    }
    const created = await prisma.$transaction(async (tx) => {
      const hazard = await tx.hazard.create({
        data: {
          orgId: req.auth.org,
          title: e.hazard,
          description: e.consequence,
          /* Named so the register can tell a hazard somebody typed from
             one that arrived on a report — and so an operator can be
             asked the question an auditor actually asks, which is what
             proportion of its register came from its own people. */
          ...e.fromReportId ? { reportId: e.fromReportId } : {},
          source: e.fromReportId ? "REPORT" : "REGISTER",
          /* A HAZARD ON A REPORT IS REACTIVE BY DEFINITION, and the
             fact is in the row rather than inferred, so the link wins
             over anything the client said. Otherwise take what was
             recorded, and leave it null when nothing was — an operator
             evidencing a combination it does not have is the one
             outcome this column exists to prevent. */
          discovery: e.fromReportId ? "REPORT" : e.discovery ?? null
        }
      });
      const assessment = await tx.riskAssessment.create({
        data: {
          orgId: req.auth.org,
          hazardId: hazard.id,
          consequence: e.consequence,
          severity: e.severity,
          likelihood: e.likelihood,
          score,
          tolerability: band,
          ...e.controls ? { controls: e.controls } : {},
          ...residual,
          ...e.owner ? { owner: e.owner } : {},
          ...e.reviewBy ? { reviewBy: /* @__PURE__ */ new Date(`${e.reviewBy}T00:00:00.000Z`) } : {},
          status: e.status
        }
      });
      await appendAuditTx(tx, {
        orgId: req.auth.org,
        userId: req.auth.sub,
        action: "risk.register.entry",
        entityType: "RiskAssessment",
        entityId: assessment.id
      });
      return { hazard, assessment };
    });
    return reply.code(201).send({
      entry: {
        id: created.hazard.id,
        assessmentId: created.assessment.id,
        hazard: created.hazard.title,
        source: created.hazard.source,
        discovery: created.hazard.discovery ?? null,
        fromReportId: created.hazard.reportId ?? void 0,
        consequence: created.assessment.consequence,
        severity: created.assessment.severity,
        likelihood: created.assessment.likelihood,
        controls: created.assessment.controls ?? "",
        residualSeverity: created.assessment.residualSeverity ?? void 0,
        residualLikelihood: created.assessment.residualLikelihood ?? void 0,
        owner: created.assessment.owner ?? "",
        reviewBy: created.assessment.reviewBy ? created.assessment.reviewBy.toISOString().slice(0, 10) : "",
        status: created.assessment.status
      }
    });
  });
  const AcceptSchema = z7.object({
    alarpJustification: z7.string().trim().max(4e3).optional()
  });
  app.post("/api/v1/register/:assessmentId/accept", paid, async (req, reply) => {
    if (!guard3(req.auth.role, "risk.accept.tolerable")) {
      return reply.code(403).send({ error: "forbidden" });
    }
    const parsed = AcceptSchema.safeParse(req.body ?? {});
    if (!parsed.success) {
      return reply.code(400).send({ error: "invalid", detail: parsed.error.flatten() });
    }
    const { assessmentId } = req.params;
    const assessment = await prisma.riskAssessment.findFirst({
      where: { ...tenantWhere(req), id: assessmentId },
      select: {
        id: true,
        tolerability: true,
        residualTolerability: true,
        acceptedAt: true,
        alarpJustification: true
      }
    });
    if (!assessment) return reply.code(404).send({ error: "not_found" });
    if (assessment.acceptedAt) {
      return reply.code(409).send({
        error: "already_accepted",
        message: "This risk has already been accepted. Accepting it twice would overwrite who signed it \u2014 if the position has changed, assess it again."
      });
    }
    const governing = assessment.residualTolerability ?? assessment.tolerability;
    const refusal = refuseSignature(governing, req.auth.role);
    if (refusal) {
      return reply.code(refusal.error === "not_ownable" ? 409 : 403).send({
        error: refusal.error,
        requires: refusal.requires,
        message: refusal.message
      });
    }
    const alarp = parsed.data.alarpJustification ?? assessment.alarpJustification ?? "";
    if (governing === "TOLERABLE" && !alarp.trim()) {
      return reply.code(400).send({
        error: "alarp_required",
        message: "A tolerable risk is only tolerable once it has been driven as low as reasonably practicable. Say what was done and why going further is not reasonably practicable \u2014 that statement is the acceptance."
      });
    }
    const saved = await prisma.$transaction(async (tx) => {
      const row = await tx.riskAssessment.update({
        where: { id: assessment.id },
        data: {
          acceptedById: req.auth.sub,
          acceptedAt: /* @__PURE__ */ new Date(),
          status: "ACCEPTED",
          ...alarp.trim() ? { alarpJustification: alarp.trim() } : {}
        }
      });
      await appendAuditTx(tx, {
        orgId: req.auth.org,
        userId: req.auth.sub,
        /* Named for the band it was accepted in. An audit trail that
           says only "risk.accept" cannot answer the question an
           inspector actually asks, which is who accepted the amber
           ones. */
        action: `risk.accept.${governing.toLowerCase()}`,
        entityType: "RiskAssessment",
        entityId: row.id
      });
      return row;
    });
    return reply.send({
      accepted: {
        assessmentId: saved.id,
        acceptedAt: saved.acceptedAt?.toISOString() ?? null,
        band: governing,
        status: saved.status
      }
    });
  });
}
var LIST_LIMIT3, SEVERITIES, LIKELIHOODS, SETTABLE_ON_CREATE, EntrySchema;
var init_routes_register = __esm({
  "apps/api/src/routes.register.ts"() {
    "use strict";
    init_src();
    init_signature();
    init_discovery();
    init_core();
    LIST_LIMIT3 = 200;
    SEVERITIES = [
      "A_CATASTROPHIC",
      "B_HAZARDOUS",
      "C_MAJOR",
      "D_MINOR",
      "E_NEGLIGIBLE"
    ];
    LIKELIHOODS = [
      "FREQUENT",
      "OCCASIONAL",
      "REMOTE",
      "IMPROBABLE",
      "EXTREMELY_IMPROBABLE"
    ];
    SETTABLE_ON_CREATE = ["OPEN", "MITIGATED", "CLOSED"];
    EntrySchema = z7.object({
      hazard: z7.string().trim().min(1).max(200),
      consequence: z7.string().trim().min(1).max(4e3),
      severity: z7.enum(SEVERITIES),
      likelihood: z7.enum(LIKELIHOODS),
      controls: z7.string().trim().max(4e3).optional(),
      /* The residual pair travels together or not at all. Half of it is a
         control whose effect nobody stated, and it would render as a
         residual position the entry does not have. */
      residualSeverity: z7.enum(SEVERITIES).optional(),
      residualLikelihood: z7.enum(LIKELIHOODS).optional(),
      owner: z7.string().trim().max(160).optional(),
      reviewBy: z7.string().trim().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
      status: z7.enum(SETTABLE_ON_CREATE).default("OPEN"),
      /* ------------------------------------------------------------------
           THE REPORT THIS CAME OUT OF.
      
           `Hazard.reportId` and `Hazard.source` have been in the schema since
           the first migration and nothing has ever written the first one. So
           every hazard in every register was typed by hand, and the two
           halves of this product did not touch: reports arrived, were
           triaged, coded to ICAO's categories and dispositioned, while the
           register held whatever somebody remembered to write down again.
      
           That is the finding element 2.1 exists to prevent — hazard
           identification is meant to be FED by the reporting system — and
           /coverage has been saying so in element 2.2's `missing` field in
           the meantime.
      
           WHAT DOES NOT TRAVEL IS THE NARRATIVE, and that is the whole
           design of this field. A register is printed, taken to a meeting and
           shown to an inspector; a report narrative is protected, may be
           anonymous, and is de-identified before it goes anywhere wider. So
           the link is an ID and nothing else. The hazard's own words are
           written by the person raising it, which is also what an SMS
           actually asks for: a hazard is the general condition a safety
           officer abstracts from one or more reports, not a copy of one.
           ------------------------------------------------------------------ */
      fromReportId: z7.string().uuid().optional(),
      /* HOW IT WAS FOUND, against ICAO's three methods. Optional, because a
         register entry typed in a hurry is still a register entry and
         refusing it would cost the record the hazard to gain a label. What
         it must not do is default to something — an unrecorded method is
         reported as unknown rather than guessed. See
         packages/shared/src/discovery.ts. */
      discovery: z7.enum(DISCOVERY_KEYS).optional()
    }).refine(
      (e) => Boolean(e.residualSeverity) === Boolean(e.residualLikelihood),
      { message: "A residual position needs both a severity and a likelihood, or neither." }
    );
  }
});

// apps/api/src/routes.change.ts
import { z as z8 } from "zod";
function guard4(role, permission) {
  return can(role, permission);
}
async function changeRoutes(app) {
  const limited = {
    preHandler: authenticate,
    /* EVERY ROUTE IN THIS FILE WRITES ROWS, AND NONE OF THEM WAS LIMITED.
    
           Found by asking which route files declare no limit at all rather
           than by reading any one of them: this file, routes.register.ts and
           routes.spi.ts were the three, and all three accept POSTs that
           create records. Authentication bounds WHO can do it; it does not
           bound how often, so a stuck retry loop or a stolen token wrote
           until something else broke.
    
           60 a minute, matching routes.config.ts — this is a safety manager
           adding entries on a working screen, not a reporter at a strip, so
           the limit only has to be below "a script". The tighter number
           belongs on routes.attachments.ts, which is the one that writes
           megabytes. */
    config: { rateLimit: { max: 60, timeWindow: "1 minute" } }
  };
  app.get("/api/v1/changes", limited, async (req, reply) => {
    if (!guard4(req.auth.role, "moc.create") && !guard4(req.auth.role, "moc.approve")) {
      return reply.code(403).send({ error: "forbidden" });
    }
    const rows = await prisma.changeAssessment.findMany({
      where: tenantWhere(req),
      orderBy: [{ assessedOn: "desc" }],
      take: LIST_LIMIT4,
      include: { approvedBy: { select: { name: true, role: true } } }
    });
    return reply.send({ changes: rows });
  });
  app.post("/api/v1/changes", limited, async (req, reply) => {
    if (!guard4(req.auth.role, "moc.create")) {
      return reply.code(403).send({ error: "forbidden" });
    }
    const parsed = ChangeInput.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ error: "invalid", detail: parsed.error.flatten() });
    }
    const c = parsed.data;
    const score = riskScore(c.severity, c.likelihood);
    const band = tolerability(c.severity, c.likelihood);
    const residual = c.residualSeverity && c.residualLikelihood ? {
      residualSeverity: c.residualSeverity,
      residualLikelihood: c.residualLikelihood,
      residualScore: riskScore(
        c.residualSeverity,
        c.residualLikelihood
      ),
      residualTolerability: tolerability(
        c.residualSeverity,
        c.residualLikelihood
      )
    } : {};
    const created = await prisma.$transaction(async (tx) => {
      const row = await tx.changeAssessment.create({
        data: {
          orgId: req.auth.org,
          title: c.title,
          description: c.description,
          trigger: c.trigger,
          assessedOn: at(c.assessedOn),
          ...c.effectiveFrom ? { effectiveFrom: at(c.effectiveFrom) } : {},
          severity: c.severity,
          likelihood: c.likelihood,
          score,
          tolerability: band,
          ...c.controls ? { controls: c.controls } : {},
          ...residual,
          ...c.reviewDueOn ? { reviewDueOn: at(c.reviewDueOn) } : {},
          status: "ASSESSED"
        }
      });
      await appendAuditTx(tx, {
        orgId: req.auth.org,
        userId: req.auth.sub,
        action: "change.assess",
        entityType: "ChangeAssessment",
        entityId: row.id
      });
      return row;
    });
    return reply.code(201).send({ change: created });
  });
  app.post("/api/v1/changes/:id/approve", limited, async (req, reply) => {
    if (!guard4(req.auth.role, "moc.approve")) {
      return reply.code(403).send({ error: "forbidden" });
    }
    const { id } = req.params;
    if (!ApprovalInput.safeParse(req.body ?? {}).success) {
      return reply.code(400).send({ error: "invalid" });
    }
    const change = await prisma.changeAssessment.findFirst({
      where: { ...tenantWhere(req), id },
      select: { id: true, approvedAt: true, residualTolerability: true, tolerability: true }
    });
    if (!change) return reply.code(404).send({ error: "not_found" });
    if (change.approvedAt) {
      return reply.code(409).send({
        error: "already_approved",
        message: "This change has already been approved. Approving twice would overwrite who signed it."
      });
    }
    const governing = change.residualTolerability ?? change.tolerability;
    const refusal = refuseSignature(governing, req.auth.role);
    if (refusal) {
      return reply.code(refusal.error === "not_ownable" ? 409 : 403).send({
        error: refusal.error === "not_ownable" ? "intolerable" : refusal.error,
        requires: refusal.requires,
        message: refusal.error === "not_ownable" ? "This change carries an intolerable risk after its controls. It cannot be approved \u2014 the controls have to change, not the signature." : refusal.message
      });
    }
    const saved = await prisma.$transaction(async (tx) => {
      const row = await tx.changeAssessment.update({
        where: { id: change.id },
        data: { approvedById: req.auth.sub, approvedAt: /* @__PURE__ */ new Date(), status: "APPROVED" }
      });
      await appendAuditTx(tx, {
        orgId: req.auth.org,
        userId: req.auth.sub,
        action: "change.approve",
        entityType: "ChangeAssessment",
        entityId: row.id
      });
      return row;
    });
    return reply.send({ change: saved });
  });
  app.post("/api/v1/changes/:id/review", limited, async (req, reply) => {
    if (!guard4(req.auth.role, "moc.create")) {
      return reply.code(403).send({ error: "forbidden" });
    }
    const { id } = req.params;
    const parsed = ReviewInput.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ error: "invalid", detail: parsed.error.flatten() });
    }
    const change = await prisma.changeAssessment.findFirst({
      where: { ...tenantWhere(req), id },
      select: { id: true }
    });
    if (!change) return reply.code(404).send({ error: "not_found" });
    const saved = await prisma.$transaction(async (tx) => {
      const row = await tx.changeAssessment.update({
        where: { id: change.id },
        data: {
          reviewedOn: at(parsed.data.reviewedOn),
          reviewNotes: parsed.data.reviewNotes,
          status: "REVIEWED"
        }
      });
      await appendAuditTx(tx, {
        orgId: req.auth.org,
        userId: req.auth.sub,
        action: "change.review",
        entityType: "ChangeAssessment",
        entityId: row.id
      });
      return row;
    });
    return reply.send({ change: saved });
  });
}
var LIST_LIMIT4, SEVERITIES2, LIKELIHOODS2, TRIGGERS, day, at, ChangeInput, ApprovalInput, ReviewInput;
var init_routes_change = __esm({
  "apps/api/src/routes.change.ts"() {
    "use strict";
    init_src();
    init_signature();
    init_core();
    LIST_LIMIT4 = 200;
    SEVERITIES2 = [
      "A_CATASTROPHIC",
      "B_HAZARDOUS",
      "C_MAJOR",
      "D_MINOR",
      "E_NEGLIGIBLE"
    ];
    LIKELIHOODS2 = [
      "FREQUENT",
      "OCCASIONAL",
      "REMOTE",
      "IMPROBABLE",
      "EXTREMELY_IMPROBABLE"
    ];
    TRIGGERS = [
      "FLEET",
      "ROUTE_OR_NETWORK",
      "ORGANISATION",
      "KEY_PERSONNEL",
      "EQUIPMENT_OR_SYSTEM",
      "PROCEDURE",
      "OTHER"
    ];
    day = z8.string().trim().regex(/^\d{4}-\d{2}-\d{2}$/);
    at = (d) => /* @__PURE__ */ new Date(`${d}T00:00:00.000Z`);
    ChangeInput = z8.object({
      title: z8.string().trim().min(1).max(200),
      description: z8.string().trim().min(1).max(8e3),
      trigger: z8.enum(TRIGGERS),
      assessedOn: day,
      effectiveFrom: day.optional(),
      severity: z8.enum(SEVERITIES2),
      likelihood: z8.enum(LIKELIHOODS2),
      controls: z8.string().trim().max(4e3).optional(),
      residualSeverity: z8.enum(SEVERITIES2).optional(),
      residualLikelihood: z8.enum(LIKELIHOODS2).optional(),
      reviewDueOn: day.optional()
    }).refine(
      (c) => Boolean(c.residualSeverity) === Boolean(c.residualLikelihood),
      { message: "A residual position needs both a severity and a likelihood, or neither." }
    ).refine(
      /* THE ELEMENT, AS A VALIDATION. "Dated before it happened" is what
         3.2's evidence asks for, so an assessment dated after its own
         change took effect is refused rather than stored and flagged.
         Storing it would put a row in the record that reads as evidence
         and is the opposite of it. */
      (c) => !c.effectiveFrom || at(c.assessedOn) <= at(c.effectiveFrom),
      {
        message: "This assessment is dated after the change took effect. Element 3.2 asks for an assessment made before the change \u2014 a later one is a justification, and recording it as an assessment would misstate the record."
      }
    );
    ApprovalInput = z8.object({
      /* Nothing to send. The approver is the caller and the moment is now:
         letting either be supplied would allow an approval attributed to
         somebody who did not give it, or dated to suit. */
    });
    ReviewInput = z8.object({
      reviewedOn: day,
      reviewNotes: z8.string().trim().min(1).max(8e3)
    });
  }
});

// packages/shared/src/disposition.ts
function transitionsFrom(state) {
  return TRANSITIONS.filter((t) => t.from === state);
}
function transitionBetween(from, to) {
  return TRANSITIONS.find((t) => t.from === from && t.to === to) ?? null;
}
function mayTransition(from, to, can2, note) {
  const t = transitionBetween(from, to);
  if (!t) {
    return {
      ok: false,
      reason: "illegal",
      message: `A report cannot move from ${from} to ${to}. ` + (transitionsFrom(from).length === 0 ? `${from} is a terminal state.` : `From ${from} the available moves are: ` + transitionsFrom(from).map((x) => x.to).join(", ") + ".")
    };
  }
  if (!can2(t.needs)) {
    return {
      ok: false,
      reason: "forbidden",
      message: `Moving a report to ${to} requires ${t.needs}.`
    };
  }
  if (t.requiresNote && !(note ?? "").trim()) {
    return {
      ok: false,
      reason: "note_required",
      message: `"${t.label}" needs a note saying what was done. A closure with no statement of what was done is the thing that makes a queue worthless to whoever reads it next.`
    };
  }
  return { ok: true, transition: t };
}
var REPORT_STATES, TRANSITIONS;
var init_disposition = __esm({
  "packages/shared/src/disposition.ts"() {
    "use strict";
    REPORT_STATES = [
      "SUBMITTED",
      "TRIAGED",
      "UNDER_INVESTIGATION",
      "ACTIONS_OPEN",
      "CLOSED"
    ];
    TRANSITIONS = Object.freeze([
      {
        from: "SUBMITTED",
        to: "TRIAGED",
        needs: "report.triage",
        label: "Triage this report",
        requiresNote: false,
        because: "Somebody in the safety office has read it and confirmed what it is. This is where the type, location and phase are settled against the taxonomy, which is what makes the report countable later."
      },
      {
        from: "TRIAGED",
        to: "UNDER_INVESTIGATION",
        needs: "report.investigate",
        label: "Open an investigation",
        requiresNote: false,
        because: "The report raises a question the safety office cannot answer from the narrative alone."
      },
      {
        from: "TRIAGED",
        to: "CLOSED",
        needs: "report.close",
        label: "Close without investigating",
        requiresNote: true,
        because: "Not every report needs an investigation \u2014 a duplicate, or a hazard already on the register, is closed by saying so. The note is what says so."
      },
      {
        from: "UNDER_INVESTIGATION",
        to: "ACTIONS_OPEN",
        needs: "report.investigate",
        label: "Investigation complete, actions outstanding",
        requiresNote: false,
        because: "The investigation has finished and produced something to do. Kept separate from closure because an action agreed is not an action taken, and collapsing the two is how a register comes to read as managed while nothing has changed."
      },
      {
        from: "UNDER_INVESTIGATION",
        to: "CLOSED",
        needs: "report.close",
        label: "Close \u2014 investigation found no action needed",
        requiresNote: true,
        because: "A finding of no action is a finding. It is recorded, not left as an unanswered report."
      },
      {
        from: "ACTIONS_OPEN",
        to: "CLOSED",
        needs: "report.close",
        label: "Close \u2014 actions complete",
        requiresNote: true,
        because: "The actions are done. The note is the evidence that they are."
      },
      {
        from: "CLOSED",
        to: "ACTIONS_OPEN",
        needs: "report.investigate",
        label: "Reopen",
        requiresNote: true,
        because: "A report closed too early and then found to matter is an ordinary event. Refusing to reopen it makes people either close nothing or edit the record, and both are worse than a reopening with a reason attached."
      }
    ]);
  }
});

// packages/shared/src/cictt.ts
function unrecognised(codes) {
  return codes.filter((c) => !BY_CODE.has(c));
}
var CICTT_VERSION, OCCURRENCE_CATEGORIES, BY_CODE, CATEGORY_GROUPS, CICTT_CAVEAT;
var init_cictt = __esm({
  "packages/shared/src/cictt.ts"() {
    "use strict";
    CICTT_VERSION = "4.8 (May 2021)";
    OCCURRENCE_CATEGORIES = Object.freeze([
      // ---- In flight ----
      { code: "AMAN", label: "Abrupt manoeuvre", group: "In flight" },
      { code: "UIMC", label: "Unintended flight in instrument meteorological conditions", group: "In flight" },
      { code: "WSTRW", label: "Wind shear or thunderstorm", group: "In flight" },
      { code: "NAV", label: "Navigation errors", group: "In flight" },
      { code: "LOLI", label: "Loss of lifting conditions en route", group: "In flight" },
      { code: "LOC-I", label: "Loss of control \u2014 in flight", group: "In flight" },
      { code: "CFIT", label: "Controlled flight into or toward terrain", group: "In flight" },
      { code: "MAC", label: "Airprox, TCAS alert, loss of separation, near or actual mid-air collision", group: "In flight" },
      { code: "LALT", label: "Low altitude operations", group: "In flight" },
      { code: "TURB", label: "Turbulence encounter", group: "In flight" },
      { code: "ICE", label: "Icing", group: "In flight" },
      { code: "BIRD", label: "Birdstrike", group: "In flight" },
      { code: "CTOL", label: "Collision with obstacle(s) during take-off or landing, while airborne", group: "In flight" },
      { code: "EXTL", label: "External load related occurrences", group: "In flight" },
      // ---- Runway and landing ----
      { code: "RE", label: "Runway excursion", group: "Runway and landing" },
      { code: "ARC", label: "Abnormal runway contact", group: "Runway and landing" },
      /* THE ONE WHOSE ABSENCE WAS A SAFETY GAP RATHER THAN AN OMISSION. A
         runway incursion is among the most consequential occurrence types in
         aviation and an operator looking for it found nothing, so the honest
         ones coded OTHR and the rest picked something adjacent and wrong. */
      { code: "RI", label: "Runway incursion", group: "Runway and landing" },
      { code: "USOS", label: "Undershoot or overshoot", group: "Runway and landing" },
      // ---- On the ground ----
      { code: "GCOL", label: "Ground collision", group: "On the ground" },
      { code: "RAMP", label: "Ground handling", group: "On the ground" },
      { code: "LOC-G", label: "Loss of control \u2014 on the ground", group: "On the ground" },
      { code: "ADRM", label: "Aerodrome \u2014 design, service or functionality", group: "On the ground" },
      { code: "EVAC", label: "Evacuation", group: "On the ground" },
      { code: "GTOW", label: "Glider towing related events", group: "On the ground" },
      // ---- Aircraft ----
      { code: "SCF-PP", label: "System or component failure or malfunction \u2014 powerplant", group: "Aircraft" },
      { code: "SCF-NP", label: "System or component failure or malfunction \u2014 non-powerplant", group: "Aircraft" },
      { code: "F-NI", label: "Fire or smoke \u2014 non-impact", group: "Aircraft" },
      { code: "F-POST", label: "Fire or smoke \u2014 post-impact", group: "Aircraft" },
      { code: "CABIN", label: "Cabin safety events", group: "Aircraft" },
      { code: "FUEL", label: "Fuel related", group: "Aircraft" },
      // ---- Other ----
      { code: "SEC", label: "Security related", group: "Other" },
      { code: "ATM", label: "ATM or CNS \u2014 air traffic management and communication, navigation, surveillance", group: "Other" },
      {
        code: "OTHR",
        label: "Other \u2014 nothing in this list fits",
        group: "Other"
      },
      {
        code: "UNK",
        label: "Unknown or undetermined \u2014 not enough is known yet to categorise it",
        group: "Other"
      }
    ]);
    BY_CODE = new Map(OCCURRENCE_CATEGORIES.map((c) => [c.code, c]));
    CATEGORY_GROUPS = Object.freeze([
      "In flight",
      "Runway and landing",
      "On the ground",
      "Aircraft",
      "Other"
    ]);
    CICTT_CAVEAT = `Occurrence categories are ICAO's, from the CAST/ICAO Common Taxonomy Team, version ${CICTT_VERSION}. This product carries the codes and their names, NOT their full definitions \u2014 a category's definition is what decides a borderline case, and it is in the published document rather than paraphrased here. The list is also not complete: if nothing fits, use OTHR and say so in the narrative rather than forcing a code that does not.`;
  }
});

// apps/api/src/routes.reports.ts
import { z as z9 } from "zod";
async function reportRoutes(app) {
  const limited = {
    preHandler: [authenticate],
    config: { rateLimit: { max: 120, timeWindow: "1 minute" } }
  };
  const paid = {
    ...limited,
    preHandler: [authenticate, requireEntitlement("TRIAGE")]
  };
  app.get("/api/v1/reports/queue", limited, async (req, reply) => {
    const auth = req.auth;
    if (!can(auth.role, "report.read.org")) {
      return reply.code(403).send({ error: "forbidden" });
    }
    const rows = await prisma.safetyReport.findMany({
      /* A RETRACTED REPORT LEAVES THE QUEUE. It is a correction to the
         record — a duplicate, or one filed against the wrong aircraft —
         and leaving it here would make the safety office triage work
         the reporter has already withdrawn. The row and its audit entry
         remain; only the queue stops showing it. */
      where: { ...tenantWhere(req), retractedAt: null },
      orderBy: { createdAt: "desc" },
      take: QUEUE_LIMIT,
      select: {
        id: true,
        clientId: true,
        state: true,
        type: true,
        title: true,
        createdAt: true,
        isAnonymous: true,
        jurisdiction: true,
        awareAt: true,
        occurredAt: true,
        location: true,
        phase: true,
        cicttCodes: true,
        /* The five ADREP attributes travel with the row for the same
           reason cicttCodes does: the triage panel renders what is
           STORED, and a panel that opens blank invites somebody to
           re-code what was already determined. */
        injuryLevel: true,
        aircraftDamage: true,
        lightCondition: true,
        metCondition: true,
        operationType: true,
        /* WHETHER THE DUTY WAS DISCHARGED. The queue computes a
           reporting deadline per row and, until this column travelled
           with the row, had no way to know the call had been made — so
           the countdown counted down for ever and the screen could
           offer no way to stop it. The REFERENCE is deliberately not
           here: it is the operator's record to hand over, not a field
           to spray across every queue response. */
        reportedToAuthorityAt: true
      }
    });
    return reply.send({
      /* Stated rather than left to be inferred from a round number. A
         truncated queue that looks complete is how a report at the
         bottom stops existing. */
      truncated: rows.length === QUEUE_LIMIT,
      reports: rows.map((r) => ({
        id: r.id,
        clientId: r.clientId,
        state: r.state,
        type: r.type,
        title: r.title,
        createdAt: r.createdAt.toISOString(),
        isAnonymous: r.isAnonymous,
        jurisdiction: r.jurisdiction,
        awareAt: r.awareAt?.toISOString() ?? null,
        occurredAt: r.occurredAt?.toISOString() ?? null,
        location: r.location,
        phase: r.phase,
        cicttCodes: r.cicttCodes,
        injuryLevel: r.injuryLevel,
        aircraftDamage: r.aircraftDamage,
        lightCondition: r.lightCondition,
        metCondition: r.metCondition,
        operationType: r.operationType,
        reportedToAuthorityAt: r.reportedToAuthorityAt?.toISOString() ?? null,
        available: transitionsFrom(r.state).filter((t) => can(auth.role, t.needs)).map((t) => ({ to: t.to, label: t.label, requiresNote: t.requiresNote }))
      }))
    });
  });
  app.get("/api/v1/reports/:id/disposition", paid, async (req, reply) => {
    const { id } = req.params;
    const auth = req.auth;
    if (!can(auth.role, "report.read.org")) {
      return reply.code(403).send({ error: "forbidden" });
    }
    const report = await prisma.safetyReport.findFirst({
      where: { ...tenantWhere(req), id },
      select: {
        id: true,
        state: true,
        createdAt: true,
        cicttCodes: true,
        injuryLevel: true,
        aircraftDamage: true,
        lightCondition: true,
        metCondition: true,
        operationType: true
      }
    });
    if (!report) return reply.code(404).send({ error: "not_found" });
    const history = await prisma.reportTransition.findMany({
      where: { ...tenantWhere(req), reportId: report.id },
      orderBy: { at: "asc" },
      take: HISTORY_LIMIT,
      select: { fromState: true, toState: true, note: true, at: true, byUserId: true }
    });
    return reply.send({
      state: report.state,
      filedAt: report.createdAt.toISOString(),
      /* Read back so the screen renders the coding that EXISTS rather
         than the coding somebody last submitted from this browser. */
      cicttCodes: report.cicttCodes,
      injuryLevel: report.injuryLevel,
      aircraftDamage: report.aircraftDamage,
      lightCondition: report.lightCondition,
      metCondition: report.metCondition,
      operationType: report.operationType,
      available: transitionsFrom(report.state).filter((t) => can(auth.role, t.needs)).map((t) => ({
        to: t.to,
        label: t.label,
        requiresNote: t.requiresNote,
        because: t.because
      })),
      /* The moves this caller CANNOT make are named too, with the
         permission each needs. A button that is simply absent teaches a
         safety officer that the product cannot close a report; a button
         that says who can teaches them who to ask. */
      unavailable: transitionsFrom(report.state).filter((t) => !can(auth.role, t.needs)).map((t) => ({ to: t.to, label: t.label, needs: t.needs })),
      history: history.map((h) => ({
        from: h.fromState,
        to: h.toState,
        note: h.note,
        at: h.at.toISOString(),
        by: h.byUserId
      }))
    });
  });
  app.put("/api/v1/reports/:id/codes", limited, async (req, reply) => {
    const { id } = req.params;
    const auth = req.auth;
    if (!can(auth.role, "report.triage")) {
      return reply.code(403).send({
        error: "forbidden",
        message: "Classifying an occurrence to ICAO's categories is held by the roles that triage reports."
      });
    }
    const parsed = CodesSchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ error: "invalid", detail: parsed.error.flatten() });
    }
    const report = await prisma.safetyReport.findFirst({
      where: { ...tenantWhere(req), id },
      select: {
        id: true,
        cicttCodes: true,
        injuryLevel: true,
        aircraftDamage: true,
        lightCondition: true,
        metCondition: true,
        operationType: true
      }
    });
    if (!report) return reply.code(404).send({ error: "not_found" });
    const before = report.cicttCodes;
    const adrepPatch = {};
    const adrepBefore = {};
    for (const field of ADREP_FIELDS) {
      const sent = parsed.data[field.key];
      if (sent === void 0) continue;
      adrepPatch[field.key] = sent;
      adrepBefore[field.key] = report[field.key];
    }
    await prisma.$transaction(async (tx) => {
      await tx.safetyReport.update({
        where: { id: report.id },
        data: { cicttCodes: { set: parsed.data.cicttCodes }, ...adrepPatch }
      });
      await appendAuditTx(tx, {
        orgId: auth.org,
        userId: auth.sub,
        action: "report.classify",
        entityType: "SafetyReport",
        entityId: report.id,
        /* BOTH SIDES OF THE CHANGE. How an occurrence is coded decides
           what the State is told about it, so "was RE, is now RE and
           LOC-I" is the auditable fact — a record of the new value
           alone cannot answer whether a category was removed. */
        detail: {
          from: before,
          to: parsed.data.cicttCodes,
          /* THE ATTRIBUTES GO IN THE SAME ENTRY, both sides, and only
             the ones that changed hands. Injury level decides whether
             an occurrence is an Annex 13 accident, so "was MINOR, is
             now SERIOUS" is exactly the kind of re-determination an
             investigator later asks who made and when. Omitted entirely
             when the submission touched none of them, so the audit
             record does not grow a field that says nothing. */
          ...Object.keys(adrepPatch).length ? { adrep: { from: adrepBefore, to: adrepPatch } } : {}
        }
      });
    });
    const unknown = unrecognised(parsed.data.cicttCodes);
    return reply.send({
      cicttCodes: parsed.data.cicttCodes,
      /* READ BACK WHAT THE ROW NOW HOLDS, not what was sent — a partial
         submission leaves the untouched columns at their stored values
         and the screen has to render those, not blanks. */
      ...Object.fromEntries(
        ADREP_FIELDS.map((f) => [
          f.key,
          f.key in adrepPatch ? adrepPatch[f.key] : report[f.key]
        ])
      ),
      ...unknown.length ? { unrecognisedCodes: unknown } : {}
    });
  });
  app.post("/api/v1/reports/:id/notified", paid, async (req, reply) => {
    const { id } = req.params;
    const auth = req.auth;
    if (!can(auth.role, "report.triage")) {
      return reply.code(403).send({ error: "forbidden" });
    }
    const parsed = NotifiedSchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ error: "invalid", detail: parsed.error.flatten() });
    }
    const report = await prisma.safetyReport.findFirst({
      where: { ...tenantWhere(req), id },
      select: {
        id: true,
        type: true,
        occurredAt: true,
        createdAt: true,
        reportedToAuthorityAt: true
      }
    });
    if (!report) return reply.code(404).send({ error: "not_found" });
    if (report.type !== "MOR") {
      return reply.code(409).send({
        error: "not_reportable",
        message: "Only an occurrence carries a notification duty. This report has none, so there is nothing for a notification to discharge."
      });
    }
    const now = /* @__PURE__ */ new Date();
    const at4 = parsed.data.at ?? now;
    if (at4.getTime() > now.getTime()) {
      return reply.code(400).send({
        error: "invalid",
        message: "A notification cannot be dated in the future."
      });
    }
    const happened = report.occurredAt ?? report.createdAt;
    if (at4.getTime() < happened.getTime()) {
      return reply.code(400).send({
        error: "invalid",
        message: "A notification cannot precede the occurrence it reports."
      });
    }
    if (report.reportedToAuthorityAt) {
      return reply.code(409).send({
        error: "already_recorded",
        message: "This occurrence is already recorded as notified. Correcting that date is a change to a regulatory record and is not done by filing it again.",
        reportedToAuthorityAt: report.reportedToAuthorityAt.toISOString()
      });
    }
    const saved = await prisma.$transaction(async (tx) => {
      const claimed = await tx.safetyReport.updateMany({
        where: { id: report.id, orgId: auth.org, reportedToAuthorityAt: null },
        data: {
          reportedToAuthorityAt: at4,
          reportedToAuthorityById: auth.sub,
          authorityReference: parsed.data.reference ?? null
        }
      });
      if (claimed.count === 0) return null;
      await appendAuditTx(tx, {
        orgId: auth.org,
        userId: auth.sub,
        action: "report.notified_authority",
        entityType: "SafetyReport",
        entityId: report.id,
        detail: { at: at4.toISOString(), hasReference: Boolean(parsed.data.reference) }
      });
      return tx.safetyReport.findUniqueOrThrow({
        where: { id: report.id },
        select: { id: true, reportedToAuthorityAt: true, authorityReference: true }
      });
    });
    if (saved === null) {
      return reply.code(409).send({
        error: "already_recorded",
        message: "This occurrence was recorded as notified while this request was in flight. Correcting that date is a change to a regulatory record and is not done by filing it again."
      });
    }
    return reply.send(saved);
  });
  app.post("/api/v1/reports/:id/disposition", paid, async (req, reply) => {
    const { id } = req.params;
    const auth = req.auth;
    const parsed = TransitionSchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ error: "invalid", detail: parsed.error.flatten() });
    }
    const report = await prisma.safetyReport.findFirst({
      where: { ...tenantWhere(req), id },
      select: { id: true, state: true }
    });
    if (!report) return reply.code(404).send({ error: "not_found" });
    const from = report.state;
    if (parsed.data.fromState && parsed.data.fromState !== from) {
      return reply.code(409).send({
        error: "conflict",
        message: `This report is now ${from}, not ${parsed.data.fromState}. Somebody else has moved it since this screen was loaded.`,
        state: from
      });
    }
    const verdict = mayTransition(
      from,
      parsed.data.to,
      (p) => can(auth.role, p),
      parsed.data.note
    );
    if (!verdict.ok) {
      const code = verdict.reason === "forbidden" ? 403 : verdict.reason === "illegal" ? 409 : 400;
      return reply.code(code).send({
        error: verdict.reason,
        message: verdict.message,
        state: from
      });
    }
    const moved = await prisma.$transaction(async (tx) => {
      const row = await tx.reportTransition.create({
        data: {
          orgId: auth.org,
          reportId: report.id,
          fromState: from,
          toState: parsed.data.to,
          note: parsed.data.note ?? null,
          byUserId: auth.sub
        }
      });
      await tx.safetyReport.update({
        where: { id: report.id },
        data: {
          state: parsed.data.to,
          ...parsed.data.cicttCodes === void 0 ? {} : { cicttCodes: { set: parsed.data.cicttCodes } }
        }
      });
      await appendAuditTx(tx, {
        orgId: auth.org,
        userId: auth.sub,
        action: "report.disposition",
        entityType: "SafetyReport",
        entityId: report.id,
        /* The note is NOT copied into the audit detail. It can quote a
           narrative, and the audit log is read by roles that hold no
           narrative permission — see NARRATIVE_PERMISSIONS. The move is
           the auditable fact; the note lives on the row that the same
           tenancy check already guards. */
        detail: {
          from,
          to: parsed.data.to,
          /* The codes ARE in the audit detail where the note is not.
             The note can quote a narrative; a category code cannot —
             it is a classification, not content, and how an occurrence
             was coded for onward filing to the State is exactly the
             kind of decision an audit trail exists to hold. */
          ...parsed.data.cicttCodes === void 0 ? {} : { cicttCodes: parsed.data.cicttCodes }
        }
      });
      return row;
    });
    const unknown = parsed.data.cicttCodes ? unrecognised(parsed.data.cicttCodes) : [];
    return reply.code(201).send({
      state: parsed.data.to,
      transition: {
        from: moved.fromState,
        to: moved.toState,
        note: moved.note,
        at: moved.at.toISOString()
      },
      ...parsed.data.cicttCodes === void 0 ? {} : { cicttCodes: parsed.data.cicttCodes },
      ...unknown.length ? { unrecognisedCodes: unknown } : {}
    });
  });
}
var HISTORY_LIMIT, QUEUE_LIMIT, CicttCodes, TransitionSchema, AdrepPatch, CodesSchema, NotifiedSchema;
var init_routes_reports = __esm({
  "apps/api/src/routes.reports.ts"() {
    "use strict";
    init_src();
    init_disposition();
    init_cictt();
    init_adrep();
    init_core();
    HISTORY_LIMIT = 200;
    QUEUE_LIMIT = 500;
    CicttCodes = z9.array(z9.string().trim().toUpperCase().min(1).max(16)).max(12).transform((codes) => [...new Set(codes)]);
    TransitionSchema = z9.object({
      to: z9.enum(REPORT_STATES),
      /* Trimmed here so a note of three spaces is the same as no note by
         the time the state machine sees it — otherwise `requiresNote`
         passes on whitespace, which is the closure-with-no-statement this
         whole rule exists to refuse. */
      note: z9.string().trim().max(4e3).optional(),
      /* Optimistic concurrency, same shape as the sync path: two people in
         the safety office with the queue open should not silently overwrite
         one another's disposition. Optional, because a single-operator
         safety office should not have to send it. */
      fromState: z9.enum(REPORT_STATES).optional(),
      /* THE ICAO OCCURRENCE CATEGORIES, set by the safety office as part of
           the disposition rather than by the reporter on the form.
      
           Coding an occurrence to ADREP is a trained judgement about what
           happened, made after somebody has read the narrative. Asking a
           reporter at a strip to pick from twenty categories would be the
           same mistake as asking them whether the event meets Annex 13's
           definition of an accident, and the form already refuses that one.
      
           NOT VALIDATED AGAINST THE LIST HERE. The list is incomplete by
           admission, so an unknown code is recorded and REPORTED back rather
           than rejected — see the response below. Bounded and de-duplicated
           so a client cannot write an unbounded array, and normalised to
           upper case because CICTT codes are published in upper case and
           `re` and `RE` are not two categories. */
      cicttCodes: CicttCodes.optional()
    });
    AdrepPatch = z9.object(
      Object.fromEntries(
        ADREP_FIELDS.map((f) => [
          f.key,
          z9.string().trim().toUpperCase().max(32).nullable().refine((v) => v === null || isValidAdrepValue(f.key, v), {
            message: `Not a value ${f.key} accepts.`
          }).optional()
        ])
      )
    );
    CodesSchema = z9.object({ cicttCodes: CicttCodes }).merge(AdrepPatch);
    NotifiedSchema = z9.object({
      at: z9.coerce.date().optional(),
      reference: z9.string().max(120).optional()
    });
  }
});

// packages/shared/src/posts.ts
var SAFETY_ROLES;
var init_posts = __esm({
  "packages/shared/src/posts.ts"() {
    "use strict";
    SAFETY_ROLES = [
      { code: "ACCOUNTABLE_EXECUTIVE", label: "Accountable Executive" },
      { code: "SAFETY_MANAGER", label: "Safety Manager" },
      { code: "SAFETY_OFFICER", label: "Safety Officer" },
      { code: "HEAD_FLIGHT_OPS", label: "Head of Flight Operations" },
      { code: "HEAD_ENGINEERING", label: "Head of Engineering / CAMO" },
      { code: "HEAD_GROUND_OPS", label: "Head of Ground Operations" },
      { code: "HEAD_TRAINING", label: "Head of Training" },
      { code: "HEAD_SECURITY", label: "Head of Security" },
      { code: "CHIEF_PILOT", label: "Chief Pilot" },
      { code: "QUALITY_MANAGER", label: "Quality Manager" }
    ];
  }
});

// packages/shared/src/tenant.ts
function cleanLabels(raw, allowed) {
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) return void 0;
  const out = {};
  for (const key of allowed) {
    const value = raw[key];
    if (typeof value !== "string") continue;
    const trimmed = value.trim().slice(0, MAX_LABEL);
    if (trimmed) out[key] = trimmed;
  }
  return Object.keys(out).length ? out : void 0;
}
function cleanList(raw) {
  if (!Array.isArray(raw)) return void 0;
  const seen = /* @__PURE__ */ new Set();
  for (const item of raw) {
    if (typeof item !== "string") continue;
    const trimmed = item.trim().slice(0, MAX_ITEM);
    if (trimmed) seen.add(trimmed);
    if (seen.size >= MAX_LIST) break;
  }
  return seen.size ? [...seen] : void 0;
}
function cleanAuthority(raw) {
  if (!raw || typeof raw !== "object") return void 0;
  const r = raw;
  const out = {};
  for (const band of ASSIGNABLE_BANDS) {
    const post = r[band];
    if (typeof post === "string" && POST_CODES.includes(post)) out[band] = post;
  }
  return Object.keys(out).length ? Object.freeze(out) : void 0;
}
function normaliseConfig(raw) {
  if (!raw || typeof raw !== "object") return {};
  const r = raw;
  const days = Number(r.reviewDefaultDays);
  return {
    severityLabels: cleanLabels(r.severityLabels, SEVERITY_KEYS),
    likelihoodLabels: cleanLabels(r.likelihoodLabels, LIKELIHOOD_KEYS),
    postTitles: cleanLabels(r.postTitles, POST_CODES),
    aerodromes: cleanList(r.aerodromes),
    aircraftTypes: cleanList(r.aircraftTypes),
    /* Bounded to something a review cycle can plausibly be. A zero-day
       cycle marks everything overdue on creation; a ten-year one is a
       review that never happens, dressed as one that does. */
    reviewDefaultDays: Number.isFinite(days) && days >= 1 && days <= 1825 ? Math.round(days) : void 0,
    decisionLevels: cleanAuthority(r.decisionLevels)
  };
}
var MAX_LABEL, MAX_LIST, MAX_ITEM, SEVERITY_KEYS, LIKELIHOOD_KEYS, POST_CODES, ASSIGNABLE_BANDS;
var init_tenant = __esm({
  "packages/shared/src/tenant.ts"() {
    "use strict";
    init_risk();
    init_posts();
    MAX_LABEL = 60;
    MAX_LIST = 200;
    MAX_ITEM = 80;
    SEVERITY_KEYS = SEVERITY_SCALE.map((p) => p.key);
    LIKELIHOOD_KEYS = LIKELIHOOD_SCALE.map((p) => p.key);
    POST_CODES = SAFETY_ROLES.map((r) => r.code);
    ASSIGNABLE_BANDS = Object.freeze(
      ["INTOLERABLE", "TOLERABLE", "ACCEPTABLE"].filter((b) => b !== "INTOLERABLE")
    );
  }
});

// packages/shared/src/logo.ts
function checkLogo(value) {
  if (typeof value !== "string" || value.length === 0) {
    return { ok: false, message: "No image was supplied." };
  }
  if (value.length > LOGO_MAX_CHARS) {
    const kb = Math.round(value.length / 1024);
    return {
      ok: false,
      message: `That image is about ${kb} KB encoded, against a ${Math.round(LOGO_MAX_CHARS / 1024)} KB ceiling. It rides on every page this operator prints, so it is kept small on purpose \u2014 export it at ${LOGO_MAX_EDGE}px on the longest edge.`
    };
  }
  const m = DATA_URI.exec(value);
  if (!m) {
    return {
      ok: false,
      message: "That did not arrive as a base64 image. Choose a PNG, JPEG or WebP file."
    };
  }
  const type = m[1];
  if (!LOGO_TYPES.includes(type)) {
    const why = type === "image/svg+xml" ? "SVG is not accepted anywhere in this product: it is markup that can carry script, and this image is rendered into your own pages. Export it as a PNG." : `${type} is not accepted.`;
    return { ok: false, message: `${why} Use PNG, JPEG or WebP.` };
  }
  if (m[2].length % 4 !== 0) {
    return {
      ok: false,
      message: "That image arrived incomplete. Try uploading it again."
    };
  }
  return { ok: true, type, chars: value.length };
}
var LOGO_TYPES, LOGO_MAX_CHARS, LOGO_MAX_EDGE, DATA_URI;
var init_logo = __esm({
  "packages/shared/src/logo.ts"() {
    "use strict";
    LOGO_TYPES = Object.freeze([
      "image/png",
      "image/jpeg",
      "image/webp"
    ]);
    LOGO_MAX_CHARS = 6e4;
    LOGO_MAX_EDGE = 512;
    DATA_URI = /^data:([a-z]+\/[a-z0-9.+-]+);base64,([A-Za-z0-9+/]+={0,2})$/;
  }
});

// apps/api/src/routes.config.ts
import { Prisma as Prisma3 } from "@prisma/client";
async function configRoutes(app) {
  const limited = {
    preHandler: [authenticate],
    config: { rateLimit: { max: 60, timeWindow: "1 minute" } }
  };
  app.get("/api/v1/config", limited, async (req, reply) => {
    const row = await prisma.orgConfig.findFirst({ where: tenantWhere(req) });
    return reply.send({
      config: normaliseConfig(row ?? {}),
      logo: row?.logo ?? null
    });
  });
  app.put("/api/v1/config", limited, async (req, reply) => {
    const auth = req.auth;
    if (!can(auth.role, "config.manage")) {
      return reply.code(403).send({
        error: "forbidden",
        message: "What the operator calls its posts and its risk scales is held by the safety manager and the accountable executive."
      });
    }
    const config2 = normaliseConfig(req.body);
    const saved = await prisma.orgConfig.upsert({
      where: { orgId: auth.org },
      create: {
        orgId: auth.org,
        severityLabels: config2.severityLabels ? config2.severityLabels : void 0,
        likelihoodLabels: config2.likelihoodLabels ? config2.likelihoodLabels : void 0,
        postTitles: config2.postTitles ? config2.postTitles : void 0,
        aerodromes: [...config2.aerodromes ?? []],
        aircraftTypes: [...config2.aircraftTypes ?? []],
        reviewDefaultDays: config2.reviewDefaultDays ?? null,
        decisionLevels: config2.decisionLevels ? config2.decisionLevels : void 0
      },
      update: {
        /* `null` and not `undefined` on the update path. Prisma reads
           undefined as "leave this column alone", so a cleared rename
           sent as undefined would silently persist the old label — the
           operator would remove a word on screen, save, reload, and
           find it still there. The whole object is replaced, so absence
           means removal and must be written as such. */
        severityLabels: config2.severityLabels ? config2.severityLabels : Prisma3.DbNull,
        likelihoodLabels: config2.likelihoodLabels ? config2.likelihoodLabels : Prisma3.DbNull,
        postTitles: config2.postTitles ? config2.postTitles : Prisma3.DbNull,
        aerodromes: { set: [...config2.aerodromes ?? []] },
        aircraftTypes: { set: [...config2.aircraftTypes ?? []] },
        reviewDefaultDays: config2.reviewDefaultDays ?? null,
        /* DbNull rather than undefined, for the reason the label maps
           give above: an operator clearing the declaration must see it
           cleared on reload, not silently keep the old one. */
        decisionLevels: config2.decisionLevels ? config2.decisionLevels : Prisma3.DbNull
      }
    });
    await appendAudit({
      orgId: auth.org,
      userId: auth.sub,
      action: "org.config",
      entityType: "OrgConfig",
      entityId: saved.id,
      detail: {
        severityLabels: config2.severityLabels ?? null,
        likelihoodLabels: config2.likelihoodLabels ?? null,
        postTitles: config2.postTitles ?? null,
        aerodromes: config2.aerodromes?.length ?? 0,
        aircraftTypes: config2.aircraftTypes?.length ?? 0,
        reviewDefaultDays: config2.reviewDefaultDays ?? null
      }
    });
    return reply.send({ config: config2 });
  });
  app.put("/api/v1/config/logo", limited, async (req, reply) => {
    const auth = req.auth;
    if (!can(auth.role, "config.manage")) {
      return reply.code(403).send({
        error: "forbidden",
        message: "The mark on the operator's documents is held by the safety manager and the accountable executive."
      });
    }
    const supplied = req.body?.logo;
    if (supplied === null) {
      const cleared = await prisma.orgConfig.upsert({
        where: { orgId: auth.org },
        create: { orgId: auth.org, aerodromes: [], aircraftTypes: [] },
        update: { logo: null, logoUpdatedAt: null }
      });
      await appendAudit({
        orgId: auth.org,
        userId: auth.sub,
        action: "org.logo.clear",
        entityType: "OrgConfig",
        entityId: cleared.id,
        detail: { cleared: true }
      });
      return reply.send({ logo: null });
    }
    const verdict = checkLogo(supplied);
    if (!verdict.ok) {
      return reply.code(400).send({ error: "rejected", message: verdict.message });
    }
    const saved = await prisma.orgConfig.upsert({
      where: { orgId: auth.org },
      create: {
        orgId: auth.org,
        aerodromes: [],
        aircraftTypes: [],
        logo: supplied,
        logoUpdatedAt: /* @__PURE__ */ new Date()
      },
      update: { logo: supplied, logoUpdatedAt: /* @__PURE__ */ new Date() }
    });
    await appendAudit({
      orgId: auth.org,
      userId: auth.sub,
      action: "org.logo.set",
      entityType: "OrgConfig",
      entityId: saved.id,
      detail: { type: verdict.type, chars: verdict.chars }
    });
    return reply.send({ logo: supplied });
  });
}
var init_routes_config = __esm({
  "apps/api/src/routes.config.ts"() {
    "use strict";
    init_src();
    init_tenant();
    init_logo();
    init_core();
  }
});

// apps/api/src/routes.attachments.ts
import { createHash as createHash3 } from "node:crypto";
function storageReady() {
  if (!STORAGE_URL) return { ok: false, missing: "SUPABASE_URL" };
  if (!STORAGE_KEY) return { ok: false, missing: "SUPABASE_SERVICE_ROLE_KEY" };
  return { ok: true };
}
async function attachmentRoutes(app) {
  const limited = {
    preHandler: [authenticate],
    /* Tighter than the rest of the API on purpose: this is the only
       route that writes megabytes, so it is the only one where a stuck
       retry loop is a bill rather than a log line. */
    config: { rateLimit: { max: 20, timeWindow: "1 minute" } }
  };
  app.get("/api/v1/reports/:id/attachments", limited, async (req, reply) => {
    const auth = req.auth;
    if (!can(auth.role, "report.read.org")) {
      return reply.code(403).send({ error: "forbidden" });
    }
    const { id } = req.params;
    const rows = await prisma.reportAttachment.findMany({
      /* tenantWhere FIRST, then the report. A caller who guesses another
         operator's report id gets an empty list rather than its
         evidence. */
      where: { ...tenantWhere(req), reportId: id },
      orderBy: [{ createdAt: "asc" }],
      /* BOUNDED, and EVIDENCE_MAX_FILES does not do it. That constant
               caps files per UPLOAD REQUEST — `checkEvidenceCount` applies it
               to one batch — so a report accumulating uploads over months has
               no ceiling on either the query or the response. Every other
               read route in this API carries a take and reports truncation;
               this one carried neither, which an audit found rather than a
               reviewer.
      
               The number is deliberately generous. An investigation into a
               serious occurrence can legitimately gather a lot of
               photographs, and a cap that bit in that case would cut evidence
               out of the one report it mattered most on. */
      take: ATTACHMENT_LIMIT,
      /* The key is deliberately NOT returned. It is a storage path, and
         a client has no use for one it cannot fetch directly anyway —
         every fetch goes through the route below by row id. */
      select: {
        id: true,
        contentType: true,
        bytes: true,
        sha256: true,
        label: true,
        createdAt: true
      }
    });
    return reply.send({
      attachments: rows,
      max: EVIDENCE_MAX_FILES,
      /* SAID, NOT ABSORBED — the rule /api/v1/picture and the fatigue
         picture already follow. A panel showing two hundred of four
         hundred photographs with nothing saying so lets an investigator
         conclude two hundred is all there are, on the one record where
         a missing photograph is the point. */
      truncated: rows.length === ATTACHMENT_LIMIT,
      storage: storageReady().ok
    });
  });
  app.post("/api/v1/reports/:id/attachments", {
    ...limited,
    /* THE ONLY ROUTE IN THIS PRODUCT THAT IS ALLOWED A BIG BODY, and
           it is sized from the rule rather than chosen.
    
           server.ts caps JSON at 1 MB for everything, which is right for a
           narrative and a sync batch and was silently wrong here: base64
           costs four characters per three bytes, so this route's own 3 MB
           ceiling needed about 4 MB of request and got a 1 MB one. The
           effective limit was 786 KB — announced as a Fastify parser error
           rather than as any of the sentences evidence.ts writes to explain
           a refusal, and never noticed because nothing ever posted a file
           larger than a few kilobytes.
    
           A route-level bodyLimit overrides the content-type parser's;
           confirmed by booting Fastify with this exact configuration and
           posting 4.2 MB, which the parser refuses at the default and this
           route accepts. Everything else keeps the 1 MB. */
    bodyLimit: EVIDENCE_MAX_BODY_BYTES
  }, async (req, reply) => {
    const auth = req.auth;
    if (!can(auth.role, "report.read.org")) {
      return reply.code(403).send({
        error: "forbidden",
        message: "Evidence is attached by the safety office."
      });
    }
    const ready = storageReady();
    const { id } = req.params;
    const body = req.body ?? {};
    const report = await prisma.safetyReport.findFirst({
      where: { ...tenantWhere(req), id },
      select: { id: true }
    });
    if (!report) return reply.code(404).send({ error: "not_found" });
    const existing = await prisma.reportAttachment.count({
      where: { ...tenantWhere(req), reportId: id }
    });
    const room = checkEvidenceCount(existing);
    if (!room.ok) return reply.code(409).send({ error: "too_many", message: room.message });
    if (typeof body.data !== "string" || body.data.length === 0) {
      return reply.code(400).send({ error: "rejected", message: "No file was supplied." });
    }
    if (!isBase64(body.data)) {
      return reply.code(400).send({
        error: "rejected",
        message: "That file did not arrive intact, so nothing was stored. Attach it again \u2014 if it keeps failing, the connection is dropping part of the upload."
      });
    }
    const bytes = Buffer.from(body.data, "base64");
    const verdict = checkEvidence(body.contentType, bytes.byteLength);
    if (!verdict.ok) {
      return reply.code(400).send({ error: "rejected", message: verdict.message });
    }
    const attachmentId = crypto.randomUUID();
    const key = evidenceKey(auth.org, id, attachmentId);
    const sha2562 = createHash3("sha256").update(bytes).digest("hex");
    const inlineBytes = ready.ok ? null : bytes;
    const put = ready.ok ? await fetch(objectUrl(key), {
      method: "POST",
      headers: {
        authorization: `Bearer ${STORAGE_KEY}`,
        "content-type": verdict.type,
        /* Never overwrite. A key is a fresh UUID every time, so a
           collision means something is wrong rather than something is
           being replaced, and failing loudly is the right answer. */
        "x-upsert": "false"
      },
      body: new Uint8Array(bytes)
    }) : { ok: true, status: 200 };
    if (!put.ok) {
      req.log.error({ status: put.status }, "evidence upload failed");
      return reply.code(502).send({
        error: "storage_failed",
        message: "The file could not be stored, so nothing was recorded against the report."
      });
    }
    const saved = await prisma.reportAttachment.create({
      data: {
        id: attachmentId,
        orgId: auth.org,
        reportId: id,
        key,
        contentType: verdict.type,
        bytes: verdict.bytes,
        sha256: sha2562,
        /* Display only, and capped. Nothing is ever built from it. */
        label: typeof body.label === "string" ? body.label.slice(0, 120) : null,
        /* Null when the bucket took it. The row records WHERE the file
           is by which of these is set, so there is no third column to
           fall out of step with reality. */
        data: inlineBytes,
        uploadedById: auth.sub
      },
      select: { id: true, contentType: true, bytes: true, sha256: true, label: true, createdAt: true }
    });
    await appendAudit({
      orgId: auth.org,
      userId: auth.sub,
      action: "report.evidence.add",
      entityType: "ReportAttachment",
      entityId: saved.id,
      detail: { reportId: id, contentType: verdict.type, bytes: verdict.bytes, sha256: sha2562 }
    });
    return reply.code(201).send({ attachment: saved });
  });
  app.get("/api/v1/attachments/:id", limited, async (req, reply) => {
    const auth = req.auth;
    if (!can(auth.role, "report.read.org")) {
      return reply.code(403).send({ error: "forbidden" });
    }
    const { id } = req.params;
    const row = await prisma.reportAttachment.findFirst({
      where: { ...tenantWhere(req), id },
      /* `data` IS SELECTED ONLY HERE. It is the one column in this
         product that can be megabytes, and no list, export or picture
         route touches it — which is what keeps a bytea in the row from
         costing anything anywhere else. */
      select: { key: true, contentType: true, sha256: true, data: true }
    });
    if (!row) return reply.code(404).send({ error: "not_found" });
    let buf;
    if (row.data) {
      buf = Buffer.from(row.data);
    } else {
      const ready = storageReady();
      if (!ready.ok) {
        return reply.code(503).send({
          error: "storage_unconfigured",
          message: `This attachment is held in object storage, and ${ready.missing} is unset on this deploy, so the file cannot be fetched.`
        });
      }
      const got = await fetch(objectUrl(row.key), {
        headers: { authorization: `Bearer ${STORAGE_KEY}` }
      });
      if (!got.ok) return reply.code(502).send({ error: "storage_failed" });
      buf = Buffer.from(await got.arrayBuffer());
    }
    const actual = createHash3("sha256").update(buf).digest("hex");
    if (actual !== row.sha256) {
      req.log.error({ id }, "evidence hash mismatch");
      return reply.code(409).send({
        error: "tampered",
        message: "The stored file does not match the hash recorded when it was attached. It has not been served. Treat this as evidence of a change to the stored copy."
      });
    }
    return reply.header("content-type", row.contentType).header("content-disposition", "attachment").header("x-content-type-options", "nosniff").send(buf);
  });
}
var STORAGE_URL, STORAGE_KEY, BUCKET, ATTACHMENT_LIMIT, objectUrl;
var init_routes_attachments = __esm({
  "apps/api/src/routes.attachments.ts"() {
    "use strict";
    init_src();
    init_evidence();
    init_core();
    STORAGE_URL = process.env["SUPABASE_URL"] ?? "";
    STORAGE_KEY = process.env["SUPABASE_SERVICE_ROLE_KEY"] ?? "";
    BUCKET = process.env["SUPABASE_EVIDENCE_BUCKET"] ?? "evidence";
    ATTACHMENT_LIMIT = 200;
    objectUrl = (key) => `${STORAGE_URL.replace(/\/$/, "")}/storage/v1/object/${BUCKET}/${key}`;
  }
});

// packages/shared/src/picture.ts
function tally(keys, rows) {
  const by = Object.fromEntries(keys.map((k) => [k, 0]));
  for (const r of rows) if (r.key in by) by[r.key] = r.count;
  return { total: Object.values(by).reduce((a, b) => a + b, 0), by };
}
function sampleOf(values) {
  const n = values.length;
  if (n < MIN_SAMPLE) {
    return {
      n,
      median: null,
      p90: null,
      note: n === 0 ? "Nothing has been closed yet, so there is no time to closure to report." : `Only ${n} report${n === 1 ? "" : "s"} closed so far. A median over fewer than ${MIN_SAMPLE} is an anecdote with a decimal place, so none is shown.`
    };
  }
  const sorted = [...values].sort((a, b) => a - b);
  return { n, median: quantile(sorted, 0.5), p90: quantile(sorted, 0.9), note: null };
}
function quantile(sorted, q) {
  const rank = Math.ceil(q * sorted.length);
  return sorted[Math.min(sorted.length - 1, Math.max(0, rank - 1))];
}
function trendOf(series) {
  if (series.length < MIN_TREND_POINTS) return "TOO_SHORT";
  const last = series[series.length - 1];
  const baseline = quantile([...series.slice(0, -1)].sort((a, b) => a - b), 0.5);
  if (baseline === 0) return last === 0 ? "FLAT" : "RISING";
  const change = (last - baseline) / baseline;
  if (Math.abs(change) < 0.1) return "FLAT";
  return change > 0 ? "RISING" : "FALLING";
}
function holderGaps(rows) {
  const gaps = [];
  for (const r of rows) {
    const band = r.residualTolerability ?? r.tolerability;
    const verdict = meetsRequirement(band, r.owner);
    if (verdict === "meets") continue;
    gaps.push({
      id: r.id,
      hazard: r.hazard,
      band,
      owner: r.owner ?? null,
      needs: requiredHolder(band).minimum,
      verdict
    });
  }
  const rank = (g) => (g.verdict === "below" ? 0 : 10) + (g.band === "INTOLERABLE" ? 0 : g.band === "TOLERABLE" ? 1 : 2);
  return gaps.sort((a, b) => rank(a) - rank(b));
}
function reportCount(count, days) {
  return {
    count,
    days,
    rate: null,
    note: `${count} report${count === 1 ? "" : "s"} in ${days} days. This is a count, not a rate \u2014 Doc 9859's indicator is per 1,000 flight hours or per departure, and this product does not hold your flying hours. Enter them as exposure against an indicator and the rate is computed there.`
  };
}
var MIN_TREND_POINTS, MIN_SAMPLE;
var init_picture = __esm({
  "packages/shared/src/picture.ts"() {
    "use strict";
    init_holder();
    MIN_TREND_POINTS = 3;
    MIN_SAMPLE = 5;
  }
});

// packages/shared/src/capa.ts
function daysBetween(from, to) {
  return Math.round((to.getTime() - from.getTime()) / DAY);
}
function statusOf(a, today) {
  if (at2(a.cancelledOn)) return "CANCELLED";
  if (at2(a.verifiedOn)) return "VERIFIED";
  if (at2(a.completedOn)) return "DONE";
  const due = at2(a.dueOn);
  if (!due) return "OPEN";
  const days = daysBetween(today, due);
  if (days < 0) return "OVERDUE";
  if (days <= DUE_SOON_DAYS) return "DUE_SOON";
  return "OPEN";
}
function isOutstanding(s) {
  return s === "OPEN" || s === "OVERDUE" || s === "DUE_SOON" || s === "DONE";
}
function summarise(actions, today) {
  let outstanding = 0, overdue = 0, dueSoon = 0, awaiting = 0, undated = 0;
  for (const a of actions) {
    const s = statusOf(a, today);
    if (isOutstanding(s)) outstanding++;
    if (s === "OVERDUE") overdue++;
    if (s === "DUE_SOON") dueSoon++;
    if (s === "DONE") awaiting++;
    if (!at2(a.dueOn) && isOutstanding(s)) undated++;
  }
  return {
    total: actions.length,
    outstanding,
    overdue,
    dueSoon,
    awaitingVerification: awaiting,
    undated
  };
}
function verificationRefusal(action, verifierId) {
  if (!at2(action.completedOn)) {
    return "This action has not been marked complete yet, so there is nothing to verify. Verifying first would record a check of work that has not been reported as done.";
  }
  if (action.completedById && action.completedById === verifierId) {
    return "You marked this action complete, so you cannot also verify it. An action verified by the person who did it has not been verified \u2014 it has been asserted twice by the same person. Ask somebody else in the organisation to confirm it.";
  }
  return null;
}
var DUE_SOON_DAYS, at2, DAY;
var init_capa = __esm({
  "packages/shared/src/capa.ts"() {
    "use strict";
    DUE_SOON_DAYS = 7;
    at2 = (v) => {
      if (!v) return null;
      const d = v instanceof Date ? v : new Date(v);
      return Number.isNaN(d.getTime()) ? null : d;
    };
    DAY = 864e5;
  }
});

// packages/shared/src/barriers.ts
function barrierHealth(input, now = /* @__PURE__ */ new Date()) {
  const degraded = [];
  for (const a of input.actions ?? []) {
    if (a.completedOn || a.cancelledOn) continue;
    const due = asDate(a.dueOn);
    const late = lateDays(due, now);
    if (late === null || late < OVERDUE_FROM_DAYS) continue;
    degraded.push({
      kind: "MITIGATION",
      id: a.id,
      what: a.action,
      daysLate: late,
      ownerPost: a.ownerPost ?? null,
      hrcs: [...a.hrcs ?? []]
    });
  }
  for (const r of input.assessments ?? []) {
    const due = asDate(r.reviewBy);
    const late = lateDays(due, now);
    if (late === null || late < OVERDUE_FROM_DAYS) continue;
    degraded.push({
      kind: "CONTROL_REVIEW",
      id: r.id,
      what: `Controls for "${r.hazardTitle}" have not been re-checked`,
      daysLate: late,
      ownerPost: null,
      hrcs: [...r.hrcs ?? []]
    });
  }
  for (const t of input.training ?? []) {
    const due = asDate(t.expiresOn);
    const late = lateDays(due, now);
    if (late === null || late < OVERDUE_FROM_DAYS) continue;
    degraded.push({
      kind: "COMPETENCE",
      id: t.id,
      what: `${t.course} has expired for ${t.who}`,
      daysLate: late,
      ownerPost: null,
      hrcs: []
    });
  }
  for (const c of input.changes ?? []) {
    if (c.reviewedOn) continue;
    const due = asDate(c.reviewDueOn);
    const late = lateDays(due, now);
    if (late === null || late < OVERDUE_FROM_DAYS) continue;
    degraded.push({
      kind: "CHANGE",
      id: c.id,
      what: `"${c.title}" was assessed and never reviewed after it took effect`,
      daysLate: late,
      ownerPost: null,
      hrcs: []
    });
  }
  for (const f of input.findings ?? []) {
    if (f.closedOn) continue;
    const due = asDate(f.dueBy);
    const late = lateDays(due, now);
    if (late === null || late < OVERDUE_FROM_DAYS) continue;
    degraded.push({
      kind: "AUDIT",
      id: f.id,
      what: `${f.auditRef}: ${f.finding}`,
      daysLate: late,
      ownerPost: null,
      hrcs: []
    });
  }
  for (const s of input.crossing ?? []) {
    degraded.push({
      kind: "PERFORMANCE",
      id: s.id,
      what: `${s.name} \u2014 ${s.headline}`,
      daysLate: null,
      ownerPost: s.owner ?? null,
      hrcs: []
    });
  }
  degraded.sort((x, y) => (y.daysLate ?? -1) - (x.daysLate ?? -1));
  const byHrc = {};
  const unattributed = [];
  for (const d of degraded) {
    if (d.hrcs.length === 0) {
      unattributed.push(d);
      continue;
    }
    for (const h of d.hrcs) (byHrc[h] ??= []).push(d);
  }
  const attributed = degraded.length - unattributed.length;
  return {
    degraded,
    byHrc,
    unattributed,
    attribution: degraded.length === 0 ? 1 : attributed / degraded.length
  };
}
var BARRIER_KINDS, OVERDUE_FROM_DAYS, DAY_MS2, asDate, lateDays;
var init_barriers = __esm({
  "packages/shared/src/barriers.ts"() {
    "use strict";
    BARRIER_KINDS = Object.freeze({
      MITIGATION: "A mitigation that was agreed and is not in place",
      CONTROL_REVIEW: "A control nobody has re-checked since it was accepted",
      COMPETENCE: "A competence the operation relies on, expired",
      CHANGE: "A change assessed and never closed out",
      AUDIT: "A finding the operation admitted and has not closed",
      PERFORMANCE: "An indicator that has crossed its own alert level"
    });
    OVERDUE_FROM_DAYS = 0;
    DAY_MS2 = 864e5;
    asDate = (v) => {
      if (!v) return null;
      const d = v instanceof Date ? v : new Date(v);
      return Number.isNaN(d.getTime()) ? null : d;
    };
    lateDays = (due, now) => due === null ? null : Math.floor((now.getTime() - due.getTime()) / DAY_MS2);
  }
});

// apps/api/src/routes.picture.ts
async function pictureRoutes(app) {
  app.get("/api/v1/picture", {
    preHandler: [authenticate],
    config: { rateLimit: { max: 60, timeWindow: "1 minute" } }
  }, async (req, reply) => {
    const auth = req.auth;
    if (!can(auth.role, "report.read.org")) {
      return reply.code(403).send({ error: "forbidden" });
    }
    const mayReadFindings = can(auth.role, "audit.read");
    const mayReadTraining = can(auth.role, "training.manage");
    const mayReadChanges = can(auth.role, "moc.create") || can(auth.role, "moc.approve");
    const asked = Number(req.query.days ?? DEFAULT_WINDOW_DAYS);
    const days = Number.isFinite(asked) ? Math.min(MAX_WINDOW_DAYS, Math.max(7, Math.trunc(asked))) : DEFAULT_WINDOW_DAYS;
    const to = /* @__PURE__ */ new Date();
    const from = new Date(to.getTime() - days * DAY2);
    const where = tenantWhere(req);
    const reportWhere = { ...where, retractedAt: null };
    const [
      byState,
      filed,
      closures,
      monthly,
      register,
      indicators,
      changes,
      actions,
      lateActions,
      lapsedTraining,
      openFindings,
      unreviewedChanges
    ] = await Promise.all([
      /* THE WHOLE QUEUE, not the window. "How many are open" is a
         question about now, and a report filed four months ago and
         still untriaged is exactly the one that must not fall out of
         the count because the window moved past it. */
      prisma.safetyReport.groupBy({
        by: ["state"],
        where: reportWhere,
        _count: { _all: true }
      }),
      prisma.safetyReport.count({ where: { ...reportWhere, createdAt: { gte: from } } }),
      /* Time to closure, from the transition history rather than from
         a column — and the FIRST closure per report, which is why the
         rows are ordered and de-duplicated below rather than
         aggregated in SQL. A report closed, reopened and closed again
         took as long as it took the first time; reporting the latest
         would describe reopening as slowness, and an indicator that
         punishes reopening is one that stops reports being reopened. */
      /* CAPPED, LIKE EVERY OTHER READ IN THIS BLOCK. It was the one
                 that was not: the register takes REGISTER_LIMIT, the monthly
                 series is grouped in Postgres precisely so two years of
                 reports are not pulled across to be counted here, and this
                 sat between them reading every closure in a window the caller
                 can set to two years.
      
                 OLDEST FIRST AND THE CAP KEEPS WHAT IT READS, which is the
                 right direction for a median: taking the newest would compute
                 closure time from the most recent transitions and call it the
                 window's. Truncation is reported below rather than absorbed,
                 because a median over a capped sample is a median of a sample
                 and the screen has to say so. */
      prisma.reportTransition.findMany({
        where: { ...where, toState: "CLOSED", at: { gte: from } },
        orderBy: { at: "asc" },
        take: CLOSURE_LIMIT,
        select: { reportId: true, at: true, report: { select: { createdAt: true } } }
      }),
      /* The monthly series the trend reads. Grouped in Postgres: one
         row per month, not every report in two years pulled across to
         be counted here. */
      prisma.$queryRaw`
          SELECT date_trunc('month', "createdAt") AS month, count(*) AS n
            FROM "SafetyReport"
           WHERE "orgId" = ${auth.org} AND "createdAt" >= ${from}
           GROUP BY 1 ORDER BY 1 ASC`,
      prisma.riskAssessment.findMany({
        where: { ...where, status: "OPEN" },
        take: REGISTER_LIMIT,
        select: {
          id: true,
          tolerability: true,
          residualTolerability: true,
          owner: true,
          reviewBy: true,
          /* THE REPORT BEHIND THE HAZARD, for its HRC tags and nothing
             else. `hrcTags` exists on SafetyReport and on no other
             model, so this two-hop join is the ONLY path from a
             register entry to a national high-risk category — and it
             is null for a hazard raised any other way. That is why
             barrier health below reports how much of itself it could
             attribute rather than grouping regardless. */
          hazard: {
            select: { title: true, report: { select: { hrcTags: true } } }
          }
        }
      }),
      prisma.spi.findMany({
        where,
        take: INDICATOR_LIMIT,
        orderBy: { name: "asc" },
        select: {
          id: true,
          name: true,
          kind: true,
          direction: true,
          per: true,
          target: true,
          exposureUnit: true,
          owner: true,
          /* DESCENDING HERE, ASCENDING AGAIN BELOW. Taking the most
             recent periods and then restoring the order the verdict
             reads them in — see PERIOD_LIMIT for why the ascending
             version of this cap is a correctness bug rather than a
             smaller answer. */
          periods: {
            orderBy: { label: "desc" },
            take: PERIOD_LIMIT,
            select: { id: true, label: true, events: true, exposure: true }
          }
        }
      }),
      /* A change that took effect and was never reviewed afterwards is
         element 3.2's own loose end, and it is invisible on the change
         screen because that screen is a list of changes rather than a
         list of omissions. */
      prisma.changeAssessment.count({
        where: { ...where, status: "IN_EFFECT", reviewedOn: null }
      }),
      /* THE CAPA LOOP'S OWN QUESTION: what did we undertake to do, and
         is it done. Fetched as rows rather than counted in SQL because
         overdue is DERIVED from the due date against today — there is
         no status column to GROUP BY, deliberately, since a stored one
         would still say OPEN the day after the date passed. */
      prisma.correctiveAction.findMany({
        where,
        take: ACTION_LIMIT,
        select: { dueOn: true, completedOn: true, verifiedOn: true, cancelledOn: true }
      }),
      /* ------------------------------------------------------------
                 THE FOUR READS BARRIER HEALTH ADDS.
      
                 Each is NARROWED IN POSTGRES to the degraded subset rather
                 than fetched whole and filtered here — `dueOn < now AND not
                 closed` is an index-hittable predicate on every one of them,
                 and the alternative is pulling an operator's entire training
                 history across the wire to discard the current records.
      
                 They are separate from the reads above rather than widenings
                 of them. `actions` fetches dates for a summary and is capped
                 at a thousand; this one fetches the TEXT of the overdue ones
                 only, because barrier health names the barrier and a summary
                 does not. Widening the first read to serve both would pull a
                 thousand rows of db.Text to display at most a few dozen.
                 ------------------------------------------------------------ */
      /* The overdue mitigations, with the report behind them — the
         only one of the four that can reach an HRC at all. */
      prisma.correctiveAction.findMany({
        where: {
          ...where,
          completedOn: null,
          cancelledOn: null,
          dueOn: { lt: to }
        },
        take: BARRIER_LIMIT,
        orderBy: { dueOn: "asc" },
        select: {
          id: true,
          action: true,
          ownerPost: true,
          dueOn: true,
          report: { select: { hrcTags: true } }
        }
      }),
      /* NOT QUERIED AT ALL without the permission, rather than queried
         and filtered afterwards. A row this caller may not see should
         not cross the database boundary on their behalf — the cheapest
         way to leak one is to load it and forget the filter later. */
      mayReadTraining ? prisma.trainingRecord.findMany({
        where: { ...where, expiresOn: { lt: to } },
        take: BARRIER_LIMIT,
        orderBy: { expiresOn: "asc" },
        select: {
          id: true,
          course: true,
          expiresOn: true,
          user: { select: { name: true } }
        }
      }) : [],
      mayReadFindings ? prisma.auditFinding.findMany({
        where: { ...where, closedOn: null, dueBy: { lt: to } },
        take: BARRIER_LIMIT,
        orderBy: { dueBy: "asc" },
        select: { id: true, auditRef: true, finding: true, dueBy: true }
      }) : [],
      /* The overdue-review subset of the count above, as rows. The
         count stays a COUNT — it is exact, it appears in "what needs
         attention", and turning it into `rows.length` would silently
         convert an exact figure into a capped one. */
      mayReadChanges ? prisma.changeAssessment.findMany({
        where: {
          ...where,
          status: "IN_EFFECT",
          reviewedOn: null,
          reviewDueOn: { lt: to }
        },
        take: BARRIER_LIMIT,
        orderBy: { reviewDueOn: "asc" },
        select: { id: true, title: true, reviewDueOn: true }
      }) : []
    ]);
    const seen = /* @__PURE__ */ new Set();
    const closureDays = [];
    for (const c of closures) {
      if (seen.has(c.reportId)) continue;
      seen.add(c.reportId);
      closureDays.push(
        Math.max(0, Math.round((c.at.getTime() - c.report.createdAt.getTime()) / DAY2))
      );
    }
    const gaps = holderGaps(
      register.map((r) => ({
        id: r.id,
        hazard: r.hazard.title,
        tolerability: r.tolerability,
        residualTolerability: r.residualTolerability,
        owner: r.owner
      }))
    );
    const series = indicators.map((i) => ({ ...i, periods: [...i.periods].reverse() }));
    const alerting = series.map((i) => ({ spi: i, verdict: spiVerdict(i) })).filter((x) => x.verdict.headline.startsWith("Alert")).map((x) => ({
      id: x.spi.id,
      name: x.spi.name,
      headline: x.verdict.headline,
      owner: x.spi.owner
    }));
    const overdueReview = register.filter(
      (r) => r.reviewBy !== null && r.reviewBy.getTime() < to.getTime()
    ).length;
    const barriers = barrierHealth(
      {
        actions: lateActions.map((a) => ({
          id: a.id,
          action: a.action,
          ownerPost: a.ownerPost,
          dueOn: a.dueOn,
          hrcs: a.report?.hrcTags ?? []
        })),
        assessments: register.filter((r) => r.reviewBy !== null).map((r) => ({
          id: r.id,
          hazardTitle: r.hazard.title,
          reviewBy: r.reviewBy,
          hrcs: r.hazard.report?.hrcTags ?? []
        })),
        training: lapsedTraining.map((t) => ({
          id: t.id,
          who: t.user.name,
          course: t.course,
          expiresOn: t.expiresOn
        })),
        changes: unreviewedChanges.map((c) => ({
          id: c.id,
          title: c.title,
          reviewDueOn: c.reviewDueOn
        })),
        findings: openFindings.map((f) => ({
          id: f.id,
          auditRef: f.auditRef,
          finding: f.finding,
          dueBy: f.dueBy
        })),
        crossing: alerting
      },
      to
    );
    const withheld = [
      ...mayReadFindings ? [] : [{ kind: "AUDIT", source: "the internal audit findings" }],
      ...mayReadTraining ? [] : [{ kind: "COMPETENCE", source: "other people's training records" }],
      ...mayReadChanges ? [] : [{ kind: "CHANGE", source: "the change assessments" }]
    ];
    const withheldKinds = withheld.map((w) => w.kind);
    const byKind = Object.fromEntries(
      Object.keys(BARRIER_KINDS).filter((k) => !withheldKinds.includes(k)).map((k) => [k, barriers.degraded.filter((d) => d.kind === k).length])
    );
    const hrcLabel = new Map(HRC_CATEGORIES.map((c) => [c.code, c.label]));
    const byHrc = Object.entries(barriers.byHrc).map(([code, items]) => ({
      code,
      label: hrcLabel.get(code) ?? code,
      count: items.length
    })).sort((a, b) => b.count - a.count);
    return reply.send({
      window: { from: from.toISOString(), to: to.toISOString(), days },
      reporting: {
        ...reportCount(filed, days),
        /* The queue counts are over ALL time and say so, because mixing
           a windowed count with an all-time one under one heading is how
           two true numbers add up to a false impression. */
        queue: tally(
          REPORT_STATES2,
          byState.map((r) => ({ key: r.state, count: r._count._all }))
        ),
        queueScope: "all",
        trend: trendOf(monthly.map((m) => Number(m.n))),
        months: monthly.map((m) => ({
          month: m.month.toISOString().slice(0, 7),
          count: Number(m.n)
        })),
        closure: sampleOf(closureDays),
        /* SAID, NOT ABSORBED. A median computed over a capped sample is
           a median of a sample, and this is a figure somebody reads out
           to an authority. The register beside it already reports its
           own truncation for the same reason. */
        closureTruncated: closures.length === CLOSURE_LIMIT
      },
      register: {
        /* Open entries only — a closed risk is not part of the position
           being carried, and counting it makes a register that is being
           worked look identical to one that is growing. */
        open: tally(
          BANDS2,
          BANDS2.map((b) => ({
            key: b,
            count: register.filter((r) => (r.residualTolerability ?? r.tolerability) === b).length
          }))
        ),
        overdueReview,
        truncated: register.length === REGISTER_LIMIT,
        holderGaps: gaps
      },
      indicators: {
        total: indicators.length,
        alerting,
        /* SAID, NOT ABSORBED — the same rule the closure median and the
                   register follow. "3 of 200 alerting" read off a capped list is
                   a different sentence from "3 of 214", and this is a figure an
                   operator reads out at a safety review.
        
                   The PERIOD cap is deliberately NOT reported: dropping periods
                   older than fifteen years changes no verdict, because nothing
                   in spi.ts consults a window that long. A truncation notice
                   about something that cannot alter the answer is noise that
                   teaches people to ignore the notice that can. */
        truncated: indicators.length === INDICATOR_LIMIT
      },
      changes: { inEffectUnreviewed: changes },
      actions: {
        ...summarise(actions, to),
        truncated: actions.length === ACTION_LIMIT
      },
      barriers: {
        total: barriers.degraded.length,
        byKind,
        /* The six sentences, sent rather than held on the screen. They
           are the meaning of each kind, they belong beside the module
           that decides what a degradation of it is, and a copy in the
           web bundle is a copy that drifts from it. */
        kinds: BARRIER_KINDS,
        byHrc,
        attribution: barriers.attribution,
        unattributed: barriers.unattributed.length,
        withheld,
        /* THE WORST FEW, NOT ALL OF THEM, and the counts above are what
                   carry the totals.
        
                   This shipped as `barriers.degraded` entire. Measured against a
                   neglected operator — 400 of each record, every one overdue —
                   the response was 564 KB of which 500 KB was this array: 1600
                   findings, of which the screen renders twelve and discards the
                   rest. Eighty-nine per cent of the payload, on a page an
                   operator opens over a metered connection at a remote strip,
                   for an app whose entire entry chunk is 215 KB.
        
                   The list is ranked worst-first, so the top of it is the part
                   with any claim on the reader. `total` above is the real
                   figure and is unaffected by this cap. */
        degraded: barriers.degraded.slice(0, DEGRADED_SHOWN),
        truncated: lateActions.length === BARRIER_LIMIT || lapsedTraining.length === BARRIER_LIMIT || openFindings.length === BARRIER_LIMIT || unreviewedChanges.length === BARRIER_LIMIT || register.length === REGISTER_LIMIT
      }
    });
  });
}
var DEFAULT_WINDOW_DAYS, MAX_WINDOW_DAYS, REGISTER_LIMIT, CLOSURE_LIMIT, ACTION_LIMIT, BARRIER_LIMIT, DEGRADED_SHOWN, INDICATOR_LIMIT, PERIOD_LIMIT, REPORT_STATES2, BANDS2, DAY2;
var init_routes_picture = __esm({
  "apps/api/src/routes.picture.ts"() {
    "use strict";
    init_src();
    init_spi();
    init_picture();
    init_capa();
    init_barriers();
    init_core();
    DEFAULT_WINDOW_DAYS = 90;
    MAX_WINDOW_DAYS = 730;
    REGISTER_LIMIT = 500;
    CLOSURE_LIMIT = 5e3;
    ACTION_LIMIT = 1e3;
    BARRIER_LIMIT = 300;
    DEGRADED_SHOWN = 12;
    INDICATOR_LIMIT = 200;
    PERIOD_LIMIT = 60;
    REPORT_STATES2 = [
      "SUBMITTED",
      "TRIAGED",
      "UNDER_INVESTIGATION",
      "ACTIONS_OPEN",
      "CLOSED"
    ];
    BANDS2 = ["INTOLERABLE", "TOLERABLE", "ACCEPTABLE"];
    DAY2 = 864e5;
  }
});

// packages/shared/src/fatigue.ts
function touchesWocl(startHour, endHour) {
  if (!Number.isFinite(startHour) || !Number.isFinite(endHour)) return false;
  const hours = [];
  let h = Math.trunc(startHour) % 24;
  const end = Math.trunc(endHour) % 24;
  for (let i = 0; i < 24; i++) {
    hours.push(h);
    if (h === end) break;
    h = (h + 1) % 24;
  }
  return hours.some((x) => x >= WOCL_START_HOUR && x < WOCL_END_HOUR);
}
function hasDeclaredLimits(limits) {
  if (!limits) return false;
  return [
    limits.maxFlightTimeHours,
    limits.maxDutyHours,
    limits.minRestHours,
    limits.maxFlightTime7DaysHours
  ].some((n) => typeof n === "number" && Number.isFinite(n) && n > 0);
}
function assess(duty, limits) {
  const num = (n) => typeof n === "number" && Number.isFinite(n) ? n : null;
  const sp = num(duty.samnPerelli);
  const impairmentReported = sp !== null && sp >= SAMN_PERELLI_IMPAIRMENT_FROM;
  const factors = [];
  const startH = num(duty.startLocalHour);
  const endH = num(duty.endLocalHour);
  if (startH !== null && endH !== null && touchesWocl(startH, endH)) {
    factors.push("Duty ran through the window of circadian low (02:00\u201306:00 local)");
  }
  const sleep = num(duty.sleepPrior24Hours);
  if (sleep !== null && sleep < 6) {
    factors.push(`Under six hours of sleep in the 24 hours before duty (${sleep})`);
  }
  const sectors = num(duty.sectors);
  if (sectors !== null && sectors >= 6) {
    factors.push(`${sectors} sectors in one duty`);
  }
  if (impairmentReported) {
    factors.push(
      `Rated ${sp} of 7 on Samn-Perelli, at or above the level its authors describe as possible performance impairment`
    );
  }
  if (!hasDeclaredLimits(limits)) {
    return {
      verdict: "NO_LIMITS_DECLARED",
      exceeded: [],
      factors,
      impairmentReported,
      headline: "No duty limits are recorded for this operator, so this report cannot be read against them. Declare the limits that bind you and the instrument they come from."
    };
  }
  const l = limits;
  const exceeded = [];
  const compare = (actual, limit, over, name, unit) => {
    const lim = num(limit);
    if (actual === null || lim === null || lim <= 0) return false;
    const breached = over ? actual > lim : actual < lim;
    if (breached) exceeded.push(`${name}: ${actual}${unit} against a declared ${lim}${unit}`);
    return true;
  };
  const comparisons = [
    compare(num(duty.flightTimeHours), l.maxFlightTimeHours, true, "Flight time", "h"),
    compare(num(duty.dutyHours), l.maxDutyHours, true, "Duty period", "h"),
    compare(num(duty.restBeforeHours), l.minRestHours, false, "Rest before duty", "h")
  ];
  if (!comparisons.some(Boolean)) {
    return {
      verdict: "INCOMPLETE",
      exceeded: [],
      factors,
      impairmentReported,
      headline: "This report does not carry enough about the duty to read it against the declared limits. The safety office can add the figures when it speaks to the reporter."
    };
  }
  if (exceeded.length) {
    return {
      verdict: "EXCEEDED_DECLARED",
      exceeded,
      factors,
      impairmentReported,
      headline: "This duty went past a limit this operator declared for itself. That is a finding with an owner as well as a hazard."
    };
  }
  return {
    verdict: "WITHIN_DECLARED",
    exceeded: [],
    factors,
    impairmentReported,
    headline: "This duty was inside every declared limit and somebody was still too tired to fly it safely. Staying within the limits is what makes this report worth reading, not what settles it."
  };
}
var FATIGUE_SOURCES, FATIGUE_VERIFIED_AGAINST_PRIMARY, SAMN_PERELLI, SAMN_PERELLI_IMPAIRMENT_FROM, SAMN_PERELLI_SOURCE, WOCL_START_HOUR, WOCL_END_HOUR, FATIGUE_CAVEAT;
var init_fatigue = __esm({
  "packages/shared/src/fatigue.ts"() {
    "use strict";
    FATIGUE_SOURCES = [
      "ICAO Annex 6, Part I, 4.10 and Appendix 7 \u2014 fatigue management",
      "ICAO Doc 9966, Manual for the Oversight of Fatigue Management Approaches"
    ];
    FATIGUE_VERIFIED_AGAINST_PRIMARY = false;
    SAMN_PERELLI = [
      { level: 1, label: "Fully alert, wide awake" },
      { level: 2, label: "Very lively, responsive, but not at peak" },
      { level: 3, label: "Okay, somewhat fresh" },
      { level: 4, label: "A little tired, less than fresh" },
      { level: 5, label: "Moderately tired, let down" },
      { level: 6, label: "Extremely tired, very difficult to concentrate" },
      { level: 7, label: "Completely exhausted, unable to function effectively" }
    ];
    SAMN_PERELLI_IMPAIRMENT_FROM = 5;
    SAMN_PERELLI_SOURCE = "Samn and Perelli, seven-point subjective fatigue checklist, as used throughout aviation fatigue research. Levels 5 and 6 are described by the authors as moderate to severe fatigue with some performance impairment possibly occurring \u2014 flying duties permissible but not recommended.";
    WOCL_START_HOUR = 2;
    WOCL_END_HOUR = 6;
    FATIGUE_CAVEAT = "This is fatigue hazard management inside your safety management system, which is what the prescriptive route asks of you alongside staying inside your duty limits. It is not a Fatigue Risk Management System: an FRMS is a separate undertaking that your authority has to approve. Nothing here checks your limits against the law \u2014 the limits compared are the ones you declared, from the instrument you named.";
  }
});

// apps/api/src/routes.fatigue.ts
async function fatigueRoutes(app) {
  const limited = {
    preHandler: [authenticate],
    config: { rateLimit: { max: 60, timeWindow: "1 minute" } }
  };
  app.get("/api/v1/fatigue/limits", limited, async (req) => {
    const row = await prisma.fatigueLimit.findUnique({
      where: { orgId: req.auth.org }
    });
    return {
      declared: hasDeclaredLimits(row ?? void 0),
      limits: row ? {
        maxFlightTimeHours: row.maxFlightTimeHours,
        maxDutyHours: row.maxDutyHours,
        minRestHours: row.minRestHours,
        maxFlightTime7DaysHours: row.maxFlightTime7DaysHours,
        instrument: row.instrument,
        declaredOn: row.declaredOn
      } : null,
      caveat: FATIGUE_CAVEAT
    };
  });
  app.put(
    "/api/v1/fatigue/limits",
    { preHandler: [authenticate], config: { rateLimit: { max: 20, timeWindow: "15 minutes" } } },
    async (req, reply) => {
      const auth = req.auth;
      if (!can(auth.role, "config.manage")) {
        return reply.code(403).send({
          error: "forbidden",
          detail: "Declaring the duty limits this operator is bound by is held by the accountable executive and the safety manager."
        });
      }
      const b = req.body ?? {};
      const hours = (v, max) => {
        if (v === null || v === void 0 || v === "") return null;
        const n = Number(v);
        if (!Number.isFinite(n) || n <= 0 || n > max) return Number.NaN;
        return n;
      };
      const maxFlightTimeHours = hours(b["maxFlightTimeHours"], 24);
      const maxDutyHours = hours(b["maxDutyHours"], 48);
      const minRestHours = hours(b["minRestHours"], 168);
      const maxFlightTime7DaysHours = hours(b["maxFlightTime7DaysHours"], 168);
      if ([maxFlightTimeHours, maxDutyHours, minRestHours, maxFlightTime7DaysHours].some((n) => Number.isNaN(n))) {
        return reply.code(400).send({ error: "limit_out_of_range" });
      }
      const instrument = String(b["instrument"] ?? "").trim();
      const anyNumber = [maxFlightTimeHours, maxDutyHours, minRestHours, maxFlightTime7DaysHours].some((n) => typeof n === "number" && n > 0);
      if (anyNumber && (instrument.length < 3 || instrument.length > 200)) {
        return reply.code(400).send({
          error: "instrument_required",
          message: "Name the instrument these limits come from \u2014 the regulation, the operations manual section, or the AOC condition. A limit with no source cannot be checked by anybody."
        });
      }
      const data = {
        maxFlightTimeHours,
        maxDutyHours,
        minRestHours,
        maxFlightTime7DaysHours,
        instrument: instrument || "Not stated",
        declaredById: auth.sub,
        declaredOn: /* @__PURE__ */ new Date()
      };
      const saved = await prisma.$transaction(async (tx) => {
        const row = await tx.fatigueLimit.upsert({
          where: { orgId: auth.org },
          create: { orgId: auth.org, ...data },
          update: data
        });
        await appendAuditTx(tx, {
          orgId: auth.org,
          userId: auth.sub,
          action: "fatigue.limits.declared",
          entityType: "FatigueLimit",
          entityId: row.id,
          /* The figures and their source, because a change to what an
             operator says binds it is exactly the kind of thing an
             auditor asks the date of. */
          detail: {
            instrument: row.instrument,
            maxFlightTimeHours: row.maxFlightTimeHours,
            maxDutyHours: row.maxDutyHours,
            minRestHours: row.minRestHours,
            maxFlightTime7DaysHours: row.maxFlightTime7DaysHours
          }
        });
        return row;
      });
      return { declared: hasDeclaredLimits(saved), instrument: saved.instrument };
    }
  );
  app.get("/api/v1/fatigue", limited, async (req, reply) => {
    const auth = req.auth;
    if (!can(auth.role, "report.read.org")) {
      return reply.code(403).send({
        error: "forbidden",
        detail: "Reading the operator's fatigue reports is held by the roles that read the reporting queue."
      });
    }
    const asked = Number(req.query.days ?? DEFAULT_WINDOW_DAYS2);
    const days = Number.isFinite(asked) ? Math.min(MAX_WINDOW_DAYS2, Math.max(7, Math.trunc(asked))) : DEFAULT_WINDOW_DAYS2;
    const from = new Date(Date.now() - days * DAY3);
    const [limitRow, rows] = await Promise.all([
      prisma.fatigueLimit.findUnique({ where: { orgId: auth.org } }),
      prisma.safetyReport.findMany({
        where: { ...tenantWhere(req), type: "FATIGUE", retractedAt: null, createdAt: { gte: from } },
        take: REPORT_LIMIT,
        orderBy: { createdAt: "desc" },
        /* NO NARRATIVE, and no reporter. See the header. */
        select: {
          id: true,
          clientId: true,
          title: true,
          createdAt: true,
          state: true,
          isAnonymous: true,
          fatigueFlightTimeHours: true,
          fatigueDutyHours: true,
          fatigueRestBeforeHours: true,
          fatigueSectors: true,
          fatigueSleepPrior24: true,
          fatigueStartLocalHour: true,
          fatigueEndLocalHour: true,
          fatigueSamnPerelli: true
        }
      })
    ]);
    const limits = limitRow ? {
      maxFlightTimeHours: limitRow.maxFlightTimeHours,
      maxDutyHours: limitRow.maxDutyHours,
      minRestHours: limitRow.minRestHours,
      maxFlightTime7DaysHours: limitRow.maxFlightTime7DaysHours,
      instrument: limitRow.instrument
    } : null;
    const assessed = rows.map((r) => {
      const a = assess(
        {
          flightTimeHours: r.fatigueFlightTimeHours,
          dutyHours: r.fatigueDutyHours,
          restBeforeHours: r.fatigueRestBeforeHours,
          sectors: r.fatigueSectors,
          sleepPrior24Hours: r.fatigueSleepPrior24,
          startLocalHour: r.fatigueStartLocalHour,
          endLocalHour: r.fatigueEndLocalHour,
          samnPerelli: r.fatigueSamnPerelli
        },
        limits
      );
      return {
        id: r.id,
        clientId: r.clientId,
        title: r.title,
        createdAt: r.createdAt,
        state: r.state,
        verdict: a.verdict,
        exceeded: a.exceeded,
        factors: a.factors,
        impairmentReported: a.impairmentReported,
        samnPerelli: r.fatigueSamnPerelli
      };
    });
    const count = (v) => assessed.filter((a) => a.verdict === v).length;
    return {
      windowDays: days,
      declared: hasDeclaredLimits(limitRow ?? void 0),
      limits,
      total: assessed.length,
      truncated: rows.length === REPORT_LIMIT,
      counts: {
        withinDeclared: count("WITHIN_DECLARED"),
        exceededDeclared: count("EXCEEDED_DECLARED"),
        incomplete: count("INCOMPLETE"),
        noLimitsDeclared: count("NO_LIMITS_DECLARED"),
        impairmentReported: assessed.filter((a) => a.impairmentReported).length
      },
      reports: assessed,
      scale: SAMN_PERELLI,
      scaleSource: SAMN_PERELLI_SOURCE,
      sources: FATIGUE_SOURCES,
      verifiedAgainstPrimary: FATIGUE_VERIFIED_AGAINST_PRIMARY,
      caveat: FATIGUE_CAVEAT
    };
  });
}
var REPORT_LIMIT, DEFAULT_WINDOW_DAYS2, MAX_WINDOW_DAYS2, DAY3;
var init_routes_fatigue = __esm({
  "apps/api/src/routes.fatigue.ts"() {
    "use strict";
    init_src();
    init_fatigue();
    init_core();
    REPORT_LIMIT = 500;
    DEFAULT_WINDOW_DAYS2 = 365;
    MAX_WINDOW_DAYS2 = 1095;
    DAY3 = 864e5;
  }
});

// packages/shared/src/currency.ts
function wholeDaysBetween(from, to) {
  const a = Date.UTC(from.getFullYear(), from.getMonth(), from.getDate());
  const b = Date.UTC(to.getFullYear(), to.getMonth(), to.getDate());
  return Math.round((b - a) / DAY_MS3);
}
function windowFor(record) {
  if (!record.expiresOn) return null;
  const validity = wholeDaysBetween(record.completedOn, record.expiresOn);
  if (validity <= 0) return MIN_WINDOW_DAYS;
  const proportional = Math.round(validity * DUE_SOON_FRACTION2);
  return Math.min(MAX_WINDOW_DAYS3, Math.max(MIN_WINDOW_DAYS, proportional));
}
function currencyOf(record, today) {
  if (!record.expiresOn) return { state: "NO_EXPIRY", daysLeft: null, windowDays: null };
  const daysLeft = wholeDaysBetween(today, record.expiresOn);
  const windowDays = windowFor(record);
  if (daysLeft < 0) return { state: "LAPSED", daysLeft, windowDays };
  if (windowDays !== null && daysLeft <= windowDays) {
    return { state: "DUE_SOON", daysLeft, windowDays };
  }
  return { state: "CURRENT", daysLeft, windowDays };
}
var DUE_SOON_FRACTION2, MIN_WINDOW_DAYS, MAX_WINDOW_DAYS3, DAY_MS3;
var init_currency = __esm({
  "packages/shared/src/currency.ts"() {
    "use strict";
    DUE_SOON_FRACTION2 = 0.25;
    MIN_WINDOW_DAYS = 7;
    MAX_WINDOW_DAYS3 = 90;
    DAY_MS3 = 864e5;
  }
});

// packages/shared/src/erp.ts
function freshnessOf(c, today) {
  const verified = at3(c.verifiedOn);
  if (!verified) return "NEVER_VERIFIED";
  const age = Math.floor((today.getTime() - verified.getTime()) / DAY4);
  if (age >= VERIFY_WITHIN_DAYS) return "STALE";
  if (age >= VERIFY_WITHIN_DAYS - VERIFY_WARN_DAYS) return "DUE_SOON";
  return "CURRENT";
}
function daysUntilStale(c, today) {
  const verified = at3(c.verifiedOn);
  if (!verified) return null;
  const age = Math.floor((today.getTime() - verified.getTime()) / DAY4);
  return VERIFY_WITHIN_DAYS - age;
}
function assess2(contacts, today) {
  let never = 0, stale = 0, soon = 0;
  for (const c of contacts) {
    const f = freshnessOf(c, today);
    if (f === "NEVER_VERIFIED") never++;
    else if (f === "STALE") stale++;
    else if (f === "DUE_SOON") soon++;
  }
  const total = contacts.length;
  if (total === 0) {
    return {
      total: 0,
      neverVerified: 0,
      stale: 0,
      dueSoon: 0,
      usable: false,
      concern: "No emergency contacts recorded. Element 1.4 is about coordination \u2014 who you call, in what order, and what they can authorise \u2014 and a plan that connects to nobody is a document."
    };
  }
  const untrusted = never + stale;
  return {
    total,
    neverVerified: never,
    stale,
    dueSoon: soon,
    usable: untrusted === 0,
    concern: untrusted === 0 ? soon > 0 ? `${soon} contact${soon === 1 ? "" : "s"} fall${soon === 1 ? "s" : ""} due for re-verification within the month.` : null : describe(never, stale)
  };
}
function describe(never, stale) {
  const parts = [];
  if (never > 0) {
    parts.push(
      `${never} ${never === 1 ? "contact has" : "contacts have"} never been verified`
    );
  }
  if (stale > 0) {
    parts.push(
      `${stale} ${stale === 1 ? "is" : "are"} more than ${VERIFY_WITHIN_DAYS} days old`
    );
  }
  return `${parts.join(", and ")}. A number nobody has dialled is a number you find out about during the emergency.`;
}
function inCallOrder(contacts) {
  return [...contacts].sort((a, b) => {
    const ao = a.callOrder ?? Number.MAX_SAFE_INTEGER;
    const bo = b.callOrder ?? Number.MAX_SAFE_INTEGER;
    if (ao !== bo) return ao - bo;
    return a.name.localeCompare(b.name);
  });
}
var VERIFY_WITHIN_DAYS, VERIFY_WARN_DAYS, at3, DAY4;
var init_erp = __esm({
  "packages/shared/src/erp.ts"() {
    "use strict";
    VERIFY_WITHIN_DAYS = 182;
    VERIFY_WARN_DAYS = 30;
    at3 = (v) => {
      if (!v) return null;
      const d = v instanceof Date ? v : new Date(v);
      return Number.isNaN(d.getTime()) ? null : d;
    };
    DAY4 = 864e5;
  }
});

// apps/api/src/digest.compute.ts
async function computeDigest(prisma2, orgId, now) {
  const org = await prisma2.org.findUnique({
    where: { id: orgId },
    select: { jurisdiction: true }
  });
  if (!org) return null;
  const [open, training, untriaged, overdue, contacts] = await Promise.all([
    prisma2.safetyReport.findMany({
      where: {
        orgId,
        /* RETRACTED REPORTS DO NOT OWE A NOTIFICATION. A duplicate
           filed twice and corrected is not two occurrences, and a
           digest that counts it is a digest that sends somebody to
           telephone an authority about a report that was withdrawn. */
        retractedAt: null,
        type: "MOR",
        /* The column that did not exist when the deadline engine was
           written, and the whole reason the section was empty. */
        reportedToAuthorityAt: null,
        /* CLOSED IS OUT. A report the safety office has finished with is
           not today's action, and leaving it in means an operator that
           closed an occurrence without recording the call gets told
           about it every morning for ever. */
        state: { not: "CLOSED" },
        createdAt: { gte: new Date(now.getTime() - DEADLINE_LOOKBACK_DAYS * 864e5) }
      },
      select: { occurredAt: true, awareAt: true, createdAt: true },
      /* OLDEST FIRST. The cap keeps whatever it reads, so taking the
         NEWEST would drop precisely the overdue ones this is for. */
      orderBy: { createdAt: "asc" },
      take: ROW_LIMIT
    }),
    prisma2.trainingRecord.findMany({
      where: { orgId },
      select: { completedOn: true, expiresOn: true },
      take: TRAINING_LIMIT
    }),
    prisma2.safetyReport.count({ where: { orgId, retractedAt: null, state: UNTRIAGED_STATE } }),
    /* THE DATES, NOT A COUNT. Padding a count with a placeholder made a
       195-day-old action read as "overdue by 1 days" — a number the
       reader acts on and the caller invented. */
    prisma2.correctiveAction.findMany({
      where: { orgId, verifiedOn: null, cancelledOn: null, dueOn: { lt: now } },
      select: { dueOn: true },
      orderBy: { dueOn: "asc" },
      take: ROW_LIMIT
    }),
    prisma2.emergencyContact.findMany({
      where: { orgId },
      select: { verifiedOn: true },
      orderBy: [
        { verifiedOn: { sort: "asc", nulls: "first" } },
        { createdAt: "asc" }
      ],
      take: CONTACT_LIMIT
    })
  ]);
  const obligation = MOR_OBLIGATIONS[org.jurisdiction];
  const deadlines = open.flatMap((r) => {
    let due;
    try {
      ({ due } = reportingDeadline(org.jurisdiction, {
        occurredAt: r.occurredAt ?? r.createdAt,
        awareAt: r.awareAt ?? r.createdAt
      }));
    } catch {
      return [];
    }
    return [
      {
        /* `submittedAt` is deliberately NOT passed: it means "the duty
           was discharged", and every row reaching this line is one where
           it demonstrably was not. */
        status: deadlineStatus(due, now, { obligation }),
        /* NULL, NOT ZERO, where the instrument sets no window. Zero
           rendered as "soonest is today", which is a deadline invented
           for an obligation deliberately left open. */
        daysLeft: due === null ? null : Math.ceil((due.getTime() - now.getTime()) / 864e5)
      }
    ];
  });
  return digestFor({
    deadlines,
    currencies: training.map((t) => {
      const verdict = currencyOf({ completedOn: t.completedOn, expiresOn: t.expiresOn }, now);
      return { state: verdict.state, daysLeft: verdict.daysLeft };
    }),
    untriaged,
    overdueActions: overdue.map((a) => ({
      daysLeft: Math.ceil((a.dueOn.getTime() - now.getTime()) / 864e5)
    })),
    contacts: contacts.map((contact) => ({
      state: freshnessOf(contact, now),
      daysLeft: daysUntilStale(contact, now)
    }))
  });
}
async function computeRecordScale(prisma2, orgId) {
  const [reports, indicators, registerEntries] = await Promise.all([
    /* RETRACTION-INCLUDES-DELIBERATELY: this counts whether the
           operator is REPORTING, not what is outstanding. Filing something
           and then correcting it is a working reporting culture rather than
           an empty one, and offering "file the first report" to somebody
           who has filed and retracted three would read as not having
           noticed they did.
    
           Nothing downstream of this number acts on a report. It decides
           one thing: whether /today greets somebody with a sequence or with
           their record. Every query that DOES act on reports — the digest
           above, the picture, the export's own count — excludes retracted
           rows, and must keep doing so. */
    prisma2.safetyReport.count({ where: { orgId } }),
    prisma2.spi.count({ where: { orgId } }),
    prisma2.hazard.count({ where: { orgId } })
  ]);
  return { reports, indicators, registerEntries };
}
var UNTRIAGED_STATE, DEADLINE_LOOKBACK_DAYS, ROW_LIMIT, TRAINING_LIMIT, CONTACT_LIMIT;
var init_digest_compute = __esm({
  "apps/api/src/digest.compute.ts"() {
    "use strict";
    init_digest();
    init_currency();
    init_erp();
    init_regulations();
    UNTRIAGED_STATE = "SUBMITTED";
    DEADLINE_LOOKBACK_DAYS = 90;
    ROW_LIMIT = 500;
    TRAINING_LIMIT = 2e3;
    CONTACT_LIMIT = 300;
  }
});

// apps/api/src/routes.digest.ts
async function digestRoutes(app) {
  app.get("/api/v1/digest", {
    preHandler: [authenticate],
    config: { rateLimit: { max: 60, timeWindow: "1 minute" } }
  }, async (req, reply) => {
    const auth = req.auth;
    if (!can(auth.role, "report.read.org")) {
      return reply.code(403).send({ error: "forbidden" });
    }
    const now = /* @__PURE__ */ new Date();
    const digest = await computeDigest(prisma, auth.org, now);
    if (!digest) return reply.code(404).send({ error: "not_found" });
    const [scale, org, teamCount] = await Promise.all([
      computeRecordScale(prisma, auth.org),
      prisma.org.findUnique({
        where: { id: auth.org },
        select: { createdAt: true, trialEndsOn: true, paidThrough: true }
      }),
      prisma.user.count({ where: { orgId: auth.org, active: true } })
    ]);
    if (!org) return reply.code(404).send({ error: "not_found" });
    const dates = {
      trialEndsOn: org.trialEndsOn ?? trialEndsFrom(org.createdAt),
      paidThrough: org.paidThrough
    };
    const trialState = stateOn(dates, now);
    return reply.send({
      digest,
      scale,
      teamCount,
      trial: {
        state: trialState,
        daysRemaining: trialState === "TRIAL" ? Math.max(0, daysUntilChange(dates, now)) : null,
        endsOn: dates.trialEndsOn.toISOString()
      },
      wouldSend: isWorthSending(digest),
      delivery: mailConfigFromEnv().apiKey ? "CONFIGURED" : "NOT_CONFIGURED",
      computedAt: now.toISOString()
    });
  });
}
var init_routes_digest = __esm({
  "apps/api/src/routes.digest.ts"() {
    "use strict";
    init_src();
    init_digest();
    init_subscription();
    init_digest_compute();
    init_core();
    init_mail();
  }
});

// apps/api/src/routes.actions.ts
import { z as z10 } from "zod";
async function actionRoutes(app) {
  const limited = {
    preHandler: [authenticate],
    config: { rateLimit: { max: 120, timeWindow: "1 minute" } }
  };
  const shape = {
    id: true,
    action: true,
    ownerPost: true,
    dueOn: true,
    reportId: true,
    findingId: true,
    riskId: true,
    changeId: true,
    completedOn: true,
    completedById: true,
    completionNote: true,
    verifiedOn: true,
    verifiedById: true,
    verificationNote: true,
    cancelledOn: true,
    cancelledReason: true,
    createdAt: true
  };
  const present = (r, today) => ({
    ...r,
    dueOn: r.dueOn?.toISOString().slice(0, 10) ?? null,
    completedOn: r.completedOn?.toISOString() ?? null,
    verifiedOn: r.verifiedOn?.toISOString() ?? null,
    cancelledOn: r.cancelledOn?.toISOString() ?? null,
    createdAt: r.createdAt.toISOString(),
    /* Derived on every read and sent alongside the dates rather than
       instead of them: the caller can check the arithmetic, which is
       the whole reason it is not stored. */
    status: statusOf(r, today)
  });
  app.get("/api/v1/actions", limited, async (req, reply) => {
    if (!can(req.auth.role, "report.read.org")) {
      return reply.code(403).send({ error: "forbidden" });
    }
    const rows = await prisma.correctiveAction.findMany({
      where: tenantWhere(req),
      /* Nulls last: an action with no due date is not the most urgent
         thing in the list, and Postgres sorts NULL first ascending by
         default — which would put every undated action above every
         overdue one. */
      orderBy: [{ dueOn: { sort: "asc", nulls: "last" } }, { createdAt: "asc" }],
      take: LIST_LIMIT5,
      select: shape
    });
    const today = /* @__PURE__ */ new Date();
    return reply.send({
      truncated: rows.length === LIST_LIMIT5,
      actions: rows.map((r) => present(r, today)),
      summary: summarise(rows, today)
    });
  });
  app.post("/api/v1/actions", limited, async (req, reply) => {
    if (!can(req.auth.role, "hazard.manage")) {
      return reply.code(403).send({ error: "forbidden" });
    }
    const parsed = CreateSchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ error: "invalid", detail: parsed.error.flatten() });
    }
    const d = parsed.data;
    const owns = await sourceBelongsToOrg(d, req);
    if (!owns) return reply.code(404).send({ error: "not_found" });
    const row = await prisma.$transaction(async (tx) => {
      const created = await tx.correctiveAction.create({
        data: {
          orgId: req.auth.org,
          action: d.action,
          ownerPost: d.ownerPost,
          ...d.dueOn ? { dueOn: day2(d.dueOn) } : {},
          ...d.reportId ? { reportId: d.reportId } : {},
          ...d.findingId ? { findingId: d.findingId } : {},
          ...d.riskId ? { riskId: d.riskId } : {},
          ...d.changeId ? { changeId: d.changeId } : {}
        },
        select: shape
      });
      await appendAuditTx(tx, {
        orgId: req.auth.org,
        userId: req.auth.sub,
        action: "action.create",
        entityType: "CorrectiveAction",
        entityId: created.id
      });
      return created;
    });
    return reply.code(201).send({ action: present(row, /* @__PURE__ */ new Date()) });
  });
  app.post("/api/v1/actions/:id/complete", limited, async (req, reply) => {
    if (!can(req.auth.role, "hazard.manage")) {
      return reply.code(403).send({ error: "forbidden" });
    }
    const parsed = CompleteSchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ error: "invalid", detail: parsed.error.flatten() });
    }
    const existing = await find(req);
    if (!existing) return reply.code(404).send({ error: "not_found" });
    if (existing.cancelledOn) {
      return reply.code(409).send({
        error: "cancelled",
        message: "This action was cancelled. Completing it would record work against a decision not to do it \u2014 raise a new action instead, so the record shows both."
      });
    }
    const row = await prisma.$transaction(async (tx) => {
      const saved = await tx.correctiveAction.update({
        where: { id: existing.id },
        data: {
          completedOn: parsed.data.completedOn ? day2(parsed.data.completedOn) : /* @__PURE__ */ new Date(),
          completedById: req.auth.sub,
          ...parsed.data.completionNote ? { completionNote: parsed.data.completionNote } : {}
        },
        select: shape
      });
      await appendAuditTx(tx, {
        orgId: req.auth.org,
        userId: req.auth.sub,
        action: "action.complete",
        entityType: "CorrectiveAction",
        entityId: saved.id
      });
      return saved;
    });
    return reply.send({ action: present(row, /* @__PURE__ */ new Date()) });
  });
  app.post("/api/v1/actions/:id/verify", limited, async (req, reply) => {
    if (!can(req.auth.role, "audit.read")) {
      return reply.code(403).send({ error: "forbidden" });
    }
    const parsed = VerifySchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ error: "invalid", detail: parsed.error.flatten() });
    }
    const existing = await find(req);
    if (!existing) return reply.code(404).send({ error: "not_found" });
    const refusal = verificationRefusal(existing, req.auth.sub);
    if (refusal) {
      return reply.code(409).send({ error: "cannot_verify", message: refusal });
    }
    const row = await prisma.$transaction(async (tx) => {
      const saved = await tx.correctiveAction.update({
        where: { id: existing.id },
        data: {
          verifiedOn: parsed.data.verifiedOn ? day2(parsed.data.verifiedOn) : /* @__PURE__ */ new Date(),
          verifiedById: req.auth.sub,
          ...parsed.data.verificationNote ? { verificationNote: parsed.data.verificationNote } : {}
        },
        select: shape
      });
      await appendAuditTx(tx, {
        orgId: req.auth.org,
        userId: req.auth.sub,
        action: "action.verify",
        entityType: "CorrectiveAction",
        entityId: saved.id
      });
      return saved;
    });
    return reply.send({ action: present(row, /* @__PURE__ */ new Date()) });
  });
  app.post("/api/v1/actions/:id/cancel", limited, async (req, reply) => {
    if (!can(req.auth.role, "hazard.manage")) {
      return reply.code(403).send({ error: "forbidden" });
    }
    const parsed = CancelSchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ error: "invalid", detail: parsed.error.flatten() });
    }
    const existing = await find(req);
    if (!existing) return reply.code(404).send({ error: "not_found" });
    const row = await prisma.$transaction(async (tx) => {
      const saved = await tx.correctiveAction.update({
        where: { id: existing.id },
        data: { cancelledOn: /* @__PURE__ */ new Date(), cancelledReason: parsed.data.cancelledReason },
        select: shape
      });
      await appendAuditTx(tx, {
        orgId: req.auth.org,
        userId: req.auth.sub,
        action: "action.cancel",
        entityType: "CorrectiveAction",
        entityId: saved.id
      });
      return saved;
    });
    return reply.send({ action: present(row, /* @__PURE__ */ new Date()) });
  });
  function find(req) {
    const { id } = req.params;
    return prisma.correctiveAction.findFirst({
      where: { ...tenantWhere(req), id },
      select: { ...shape, completedById: true }
    });
  }
  async function sourceBelongsToOrg(d, req) {
    const where = tenantWhere(req);
    if (d.reportId) {
      return !!await prisma.safetyReport.findFirst({
        where: { ...where, id: d.reportId },
        select: { id: true }
      });
    }
    if (d.findingId) {
      return !!await prisma.auditFinding.findFirst({
        where: { ...where, id: d.findingId },
        select: { id: true }
      });
    }
    if (d.riskId) {
      return !!await prisma.riskAssessment.findFirst({
        where: { ...where, id: d.riskId },
        select: { id: true }
      });
    }
    if (d.changeId) {
      return !!await prisma.changeAssessment.findFirst({
        where: { ...where, id: d.changeId },
        select: { id: true }
      });
    }
    return false;
  }
}
var LIST_LIMIT5, SOURCES, CreateSchema, CompleteSchema, VerifySchema, CancelSchema, day2;
var init_routes_actions = __esm({
  "apps/api/src/routes.actions.ts"() {
    "use strict";
    init_src();
    init_capa();
    init_core();
    LIST_LIMIT5 = 500;
    SOURCES = ["reportId", "findingId", "riskId", "changeId"];
    CreateSchema = z10.object({
      action: z10.string().trim().min(1).max(2e3),
      ownerPost: z10.string().trim().min(1).max(160),
      dueOn: z10.string().date().optional(),
      reportId: z10.string().uuid().optional(),
      findingId: z10.string().uuid().optional(),
      riskId: z10.string().uuid().optional(),
      changeId: z10.string().uuid().optional()
    }).refine(
      (a) => SOURCES.filter((k) => a[k]).length === 1,
      {
        message: "An action belongs to exactly one thing \u2014 a report, an audit finding, a register entry or a change. With none it appears in no list and nobody does it; with two it is counted twice."
      }
    );
    CompleteSchema = z10.object({
      completionNote: z10.string().trim().max(4e3).optional(),
      /* The date the work was DONE, which is not the date it was recorded.
         Recording last month's work this morning is the ordinary case, and
         conflating the two dates every action to the day of data entry —
         the same distinction the SPI action record makes. */
      completedOn: z10.string().date().optional()
    });
    VerifySchema = z10.object({
      verificationNote: z10.string().trim().max(4e3).optional(),
      verifiedOn: z10.string().date().optional()
    });
    CancelSchema = z10.object({
      /* REQUIRED, unlike the notes above. Cancelling is a safety decision —
         an operator has decided against a control it had undertaken — and
         the reason is the part an auditor asks for. A cancellation with no
         reason is indistinguishable from a delete, which is why this is not
         a delete. */
      cancelledReason: z10.string().trim().min(1).max(4e3)
    });
    day2 = (s) => /* @__PURE__ */ new Date(`${s}T00:00:00.000Z`);
  }
});

// apps/api/src/routes.erp.ts
import { z as z11 } from "zod";
async function erpRoutes(app) {
  const limited = {
    preHandler: [authenticate],
    config: { rateLimit: { max: 120, timeWindow: "1 minute" } }
  };
  const shape = {
    id: true,
    name: true,
    role: true,
    organisation: true,
    phone: true,
    altPhone: true,
    email: true,
    callOrder: true,
    authority: true,
    notes: true,
    verifiedOn: true,
    verifiedById: true
  };
  app.get("/api/v1/sms/contacts", limited, async (req, reply) => {
    const rows = await prisma.emergencyContact.findMany({
      where: tenantWhere(req),
      take: LIMIT,
      select: shape
    });
    const today = /* @__PURE__ */ new Date();
    return reply.send({
      truncated: rows.length === LIMIT,
      /* Ordered here rather than in SQL, because "no call order sorts
         LAST" is the rule and Postgres sorts NULL first ascending. The
         same trap the corrective actions carried, and the directory is
         the place it would matter most — a list whose entire meaning is
         the order, with the unordered entries at the top. */
      contacts: inCallOrder(rows).map((c) => ({
        ...c,
        verifiedOn: c.verifiedOn?.toISOString() ?? null,
        freshness: freshnessOf(c, today)
      })),
      directory: assess2(rows, today)
    });
  });
  app.post("/api/v1/sms/contacts", limited, async (req, reply) => {
    if (!can(req.auth.role, "erp.manage")) {
      return reply.code(403).send({ error: "forbidden" });
    }
    const parsed = ContactSchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ error: "invalid", detail: parsed.error.flatten() });
    }
    const d = parsed.data;
    const row = await prisma.$transaction(async (tx) => {
      const created = await tx.emergencyContact.create({
        data: {
          orgId: req.auth.org,
          name: d.name,
          role: d.role,
          phone: d.phone,
          ...d.organisation ? { organisation: d.organisation } : {},
          ...d.altPhone ? { altPhone: d.altPhone } : {},
          ...d.email ? { email: d.email } : {},
          ...d.callOrder !== void 0 ? { callOrder: d.callOrder } : {},
          ...d.authority ? { authority: d.authority } : {},
          ...d.notes ? { notes: d.notes } : {}
          /* NOT VERIFIED ON CREATION, and this is the decision the whole
             feature turns on. Typing a number out of an old manual is
             not confirming it reaches anybody — and defaulting
             verifiedOn to now() would make every freshly-imported
             directory read as fully current on the day it is least
             trustworthy. Somebody has to dial. */
        },
        select: shape
      });
      await appendAuditTx(tx, {
        orgId: req.auth.org,
        userId: req.auth.sub,
        action: "erp.contact.create",
        entityType: "EmergencyContact",
        entityId: created.id
      });
      return created;
    });
    return reply.code(201).send({
      contact: { ...row, verifiedOn: null, freshness: freshnessOf(row, /* @__PURE__ */ new Date()) }
    });
  });
  app.post("/api/v1/sms/contacts/:id/verify", limited, async (req, reply) => {
    if (!can(req.auth.role, "erp.manage")) {
      return reply.code(403).send({ error: "forbidden" });
    }
    const { id } = req.params;
    const existing = await prisma.emergencyContact.findFirst({
      where: { ...tenantWhere(req), id },
      select: { id: true }
    });
    if (!existing) return reply.code(404).send({ error: "not_found" });
    const row = await prisma.$transaction(async (tx) => {
      const saved = await tx.emergencyContact.update({
        where: { id: existing.id },
        /* Always now(), never a date the caller chooses. Every other
           date in this product accepts a backdate because recording
           last month's work this morning is ordinary — but "I confirmed
           this number" is a thing that happened when the call was made,
           and letting it be backdated is letting a stale directory be
           made current by typing. */
        data: { verifiedOn: /* @__PURE__ */ new Date(), verifiedById: req.auth.sub },
        select: shape
      });
      await appendAuditTx(tx, {
        orgId: req.auth.org,
        userId: req.auth.sub,
        action: "erp.contact.verify",
        entityType: "EmergencyContact",
        entityId: saved.id
      });
      return saved;
    });
    return reply.send({
      contact: {
        ...row,
        verifiedOn: row.verifiedOn?.toISOString() ?? null,
        freshness: freshnessOf(row, /* @__PURE__ */ new Date())
      }
    });
  });
  app.delete("/api/v1/sms/contacts/:id", limited, async (req, reply) => {
    if (!can(req.auth.role, "erp.manage")) {
      return reply.code(403).send({ error: "forbidden" });
    }
    const { id } = req.params;
    const existing = await prisma.emergencyContact.findFirst({
      where: { ...tenantWhere(req), id },
      select: { id: true }
    });
    if (!existing) return reply.code(404).send({ error: "not_found" });
    await prisma.$transaction(async (tx) => {
      await tx.emergencyContact.delete({ where: { id: existing.id } });
      await appendAuditTx(tx, {
        orgId: req.auth.org,
        userId: req.auth.sub,
        action: "erp.contact.delete",
        entityType: "EmergencyContact",
        entityId: existing.id
      });
    });
    return reply.code(204).send();
  });
}
var LIMIT, ContactSchema;
var init_routes_erp = __esm({
  "apps/api/src/routes.erp.ts"() {
    "use strict";
    init_src();
    init_erp();
    init_core();
    LIMIT = 300;
    ContactSchema = z11.object({
      name: z11.string().trim().min(1).max(160),
      role: z11.string().trim().min(1).max(160),
      organisation: z11.string().trim().max(160).optional(),
      /* Not validated as a phone number, on purpose. An operator's call
         list holds satellite numbers, radio frequencies, extensions and
         "ask for the duty engineer on the hangar line" — and a regex that
         refuses any of those pushes the real answer into the notes field,
         where nobody dials it from. */
      phone: z11.string().trim().min(1).max(80),
      altPhone: z11.string().trim().max(80).optional(),
      email: z11.string().trim().email().max(200).optional().or(z11.literal("")),
      callOrder: z11.number().int().min(1).max(999).optional(),
      authority: z11.string().trim().max(2e3).optional(),
      notes: z11.string().trim().max(2e3).optional()
    });
  }
});

// packages/shared/src/auditpack.ts
function countOf(payload, key) {
  const v = payload[key];
  if (Array.isArray(v)) return v.length;
  if (v && typeof v === "object") return 1;
  return 0;
}
function composePack(payload, generatedAt) {
  const org = payload.org ?? {};
  const auditLog = Array.isArray(payload.auditLog) ? payload.auditLog : [];
  const last = auditLog.length ? auditLog[auditLog.length - 1].hash ?? null : null;
  const sections = PACK_MAP.map((m) => {
    const count = m.keys.reduce((n, k) => n + countOf(payload, k), 0);
    return Object.freeze({
      elementId: m.id,
      name: m.name,
      asks: m.asks,
      count,
      sources: Object.freeze([...m.keys]),
      holding: count > 0 ? "RECORDS" : "NOTHING",
      ...count === 0 ? { gap: m.gap } : {}
    });
  });
  return Object.freeze({
    operator: org.name ?? "Unnamed operator",
    jurisdiction: org.jurisdiction ?? "\u2014",
    generatedAt: generatedAt.toISOString(),
    sections: Object.freeze(sections),
    gaps: Object.freeze(
      sections.filter((s) => s.holding === "NOTHING").map((s) => s.elementId)
    ),
    verification: Object.freeze({
      entries: auditLog.length,
      lastHash: last,
      howToVerify: HOW_TO_VERIFY
    })
  });
}
var PACK_MAP, HOW_TO_VERIFY;
var init_auditpack = __esm({
  "packages/shared/src/auditpack.ts"() {
    "use strict";
    PACK_MAP = Object.freeze([
      {
        id: "1.1",
        name: "Management commitment and responsibility",
        asks: "A safety policy, signed by the accountable executive, currently in force.",
        keys: ["policies"],
        gap: "No safety policy on record. This is the first document an inspector asks for."
      },
      {
        id: "1.2",
        name: "Safety accountabilities",
        asks: "Who is accountable for what, written down and matched to real posts.",
        keys: ["accountabilities"],
        gap: "No accountabilities recorded. An SMS with no named owners is an organisation chart, and 1.2 asks who answers for each part of it."
      },
      {
        id: "1.3",
        name: "Appointment of key safety personnel",
        asks: "The appointment of the safety manager, with a letter reference and a date.",
        keys: ["appointments"],
        gap: "No appointment on record for the safety post. The regulator wants the letter reference and the date, not the name of whoever answers the phone."
      },
      {
        id: "1.4",
        name: "Emergency response planning",
        asks: "A call-out directory that has been verified, and an exercise that found something.",
        keys: ["contacts", "exercises"],
        gap: "No emergency contacts and no exercise. A plan nobody has tested is a document."
      },
      {
        id: "1.5",
        name: "SMS documentation",
        asks: "Controlled documents with a reference, revision, approver and review date.",
        keys: ["documents", "documentReads"],
        gap: "No controlled documents registered. Document control means reference, revision, approver and review date \u2014 an inspector checks the discipline, not the prose."
      },
      {
        id: "2.1",
        name: "Hazard identification",
        asks: "Reports coming in, and hazards raised from them.",
        keys: ["reports", "hazards", "voluntaryScheme"],
        gap: "No reports and no hazards. An inspector reads this as a reporting culture that is not working."
      },
      {
        id: "2.2",
        name: "Safety risk assessment and mitigation",
        asks: "Assessed risks with a tolerability decision and a named owner.",
        keys: ["riskAssessments"],
        gap: "No risk assessments. Hazards identified and never assessed is the most common finding."
      },
      {
        id: "3.1",
        name: "Safety performance monitoring and measurement",
        asks: "Indicators with targets, and periods recorded against them over time.",
        keys: ["spis", "spiPeriods"],
        gap: "No safety performance indicators. Amendment 2 replaced a static acceptable level with exactly this."
      },
      {
        id: "3.2",
        name: "Management of change",
        asks: "Changes assessed before they took effect, with approval recorded.",
        keys: ["changes"],
        gap: "No change assessments on record. A new type, a new base or a new contract assessed after it took effect is the finding element 3.2 exists to prevent."
      },
      {
        id: "3.3",
        name: "Continuous improvement",
        asks: "Internal audit findings, and corrective actions closed and verified.",
        keys: ["findings", "actions"],
        gap: "No audit findings and no corrective actions. Nothing shows the loop closing."
      },
      {
        id: "4.1",
        name: "Training and education",
        asks: "Who was trained, in what, when \u2014 and what has lapsed.",
        keys: ["training"],
        gap: "No training records. An empty matrix reads to an inspector as untrained, not as unrecorded \u2014 and 4.1 asks when each course lapses, not only that it happened."
      },
      {
        id: "4.2",
        name: "Safety communication",
        asks: "Safety information published, and feedback reaching the people who reported.",
        keys: ["communications"],
        gap: "No safety communications published. Element 4.2 asks whether people who file hear back."
      }
    ]);
    HOW_TO_VERIFY = "Each audit entry carries the hash of the one before it. Take the last hash below, post the exported audit log to /api/v1/audit/verify, and the chain is confirmed or the first altered entry is named. Neither this operator nor UsalamaSMS can change a past entry without breaking every hash after it.";
  }
});

// apps/api/src/routes.export.ts
async function exportRoutes(app) {
  const limited = {
    preHandler: [authenticate],
    config: { rateLimit: { max: 6, timeWindow: "1 minute" } }
  };
  app.get(
    "/api/v1/export",
    limited,
    async (req, reply) => {
      if (!can(req.auth.role, "org.export")) {
        return reply.code(403).send({
          error: "forbidden",
          detail: "Taking a copy of the whole safety record is held by the safety manager and the accountable executive."
        });
      }
      const where = tenantWhere(req);
      const [
        org,
        users,
        reports,
        hazards,
        riskAssessments,
        policies,
        accountabilities,
        appointments,
        exercises,
        documents,
        findings,
        training,
        communications,
        auditLog,
        spis,
        spiPeriods,
        voluntaryScheme,
        changes,
        contacts,
        actions,
        attachments,
        transitions,
        fatigueLimits,
        policyReads,
        documentReads,
        config2
      ] = await Promise.all([
        prisma.org.findUnique({
          where: { id: req.auth.org },
          select: { id: true, name: true, jurisdiction: true, createdAt: true }
        }),
        prisma.user.findMany({
          where,
          take: PROBE,
          orderBy: [{ name: "asc" }],
          // No passwordHash and no mfaSecret. Email stays: an operator
          // that cannot tell which account was whose has a copy of its
          // record and no way to stand it up again, which is the thing
          // the terms promise it will have.
          select: { id: true, email: true, name: true, role: true, active: true, createdAt: true }
        }),
        /* RETRACTION-INCLUDES-DELIBERATELY: the export is evidence, not a
                  work list.
        
                  Every other read path drops retracted reports — the queue,
                  the digest, the risk picture, the indicator counts — because
                  those answer "what needs doing" and a withdrawn duplicate
                  needs nothing. This one answers "what is on the record", and
                  it is handed to an authority.
        
                  If an export hid retracted reports, retraction would become a
                  way to remove an inconvenient occurrence from what the
                  regulator sees. That is the single thing this feature must
                  not be, and excluding them here is how it would have become
                  it. The rows carry retractedAt, retractedById and the reason,
                  the audit chain carries a report.retracted entry, and the
                  reader can see both. */
        prisma.safetyReport.findMany({ where, take: PROBE, orderBy: [{ createdAt: "asc" }] }),
        prisma.hazard.findMany({ where, take: PROBE, orderBy: [{ createdAt: "asc" }] }),
        prisma.riskAssessment.findMany({ where, take: PROBE, orderBy: [{ createdAt: "asc" }] }),
        prisma.safetyPolicy.findMany({ where, take: PROBE, orderBy: [{ version: "asc" }] }),
        prisma.accountability.findMany({ where, take: PROBE, orderBy: [{ post: "asc" }] }),
        prisma.appointment.findMany({ where, take: PROBE, orderBy: [{ appointedOn: "asc" }] }),
        prisma.emergencyExercise.findMany({ where, take: PROBE, orderBy: [{ heldOn: "asc" }] }),
        prisma.controlledDocument.findMany({ where, take: PROBE, orderBy: [{ reference: "asc" }] }),
        prisma.auditFinding.findMany({ where, take: PROBE, orderBy: [{ createdAt: "asc" }] }),
        prisma.trainingRecord.findMany({ where, take: PROBE, orderBy: [{ completedOn: "asc" }] }),
        prisma.safetyCommunication.findMany({ where, take: PROBE, orderBy: [{ publishedOn: "asc" }] }),
        prisma.auditLog.findMany({ where, take: PROBE, orderBy: [{ seq: "asc" }] }),
        /* THE NINE THAT WERE MISSING. Ordered the way an auditor reads
           them rather than the way they were added, and each ordered
           within itself by the column somebody would sort on. */
        prisma.spi.findMany({ where, take: PROBE, orderBy: [{ name: "asc" }] }),
        prisma.spiPeriod.findMany({ where, take: PROBE, orderBy: [{ spiId: "asc" }, { label: "asc" }] }),
        /* Zero or one per operator — `findMany` rather than `findUnique`
           so the payload shape does not change with its presence, and a
           reader parses one collection rather than a nullable object. */
        prisma.voluntaryScheme.findMany({ where, take: PROBE }),
        /* THE DECLARED DUTY LIMITS. Tenant-owned, so the terms' promise
           of the operator's own copy covers it — and it is one of the
           few rows in this export an operator would notice missing,
           because it is the statement of what binds them and where that
           came from. check:claims caught its absence rather than a
           reviewer. */
        prisma.fatigueLimit.findMany({ where, take: PROBE }),
        prisma.changeAssessment.findMany({ where, take: PROBE, orderBy: [{ assessedOn: "asc" }] }),
        prisma.emergencyContact.findMany({ where, take: PROBE, orderBy: [{ callOrder: "asc" }] }),
        prisma.correctiveAction.findMany({ where, take: PROBE, orderBy: [{ createdAt: "asc" }] }),
        /* THE ATTACHMENT RECORDS, NOT THE FILES. The bytes are in object
           storage and a JSON export is the wrong container for six
           megabytes of photograph per report.
           What an operator's own copy needs is the LEDGER: that a
           photograph existed against this report, what type and size it
           was, and its sha256 — so a file recovered from storage later
           can be shown to be the one the audit chain attested. Without
           the hash the export would record that evidence existed and
           give nobody a way to prove any particular file is it. */
        prisma.reportAttachment.findMany({ where, take: PROBE, orderBy: [{ createdAt: "asc" }] }),
        /* The disposition history. `byUserId` names the SAFETY OFFICER
           who moved the report, never the reporter — a transition is an
           office action, and C-01's concern was the person who filed.
           Without this the export holds outcomes and no evidence of how
           they were reached, which is the half an auditor asks for. */
        prisma.reportTransition.findMany({ where, take: PROBE, orderBy: [{ at: "asc" }] }),
        prisma.policyAcknowledgement.findMany({ where, take: PROBE, orderBy: [{ acknowledgedAt: "asc" }] }),
        prisma.documentAcknowledgement.findMany({ where, take: PROBE, orderBy: [{ acknowledgedAt: "asc" }] }),
        /* The operator's own vocabulary. A register exported without it
           reads in the shipped words rather than the words the operator
           actually uses, which is the copy an auditor would be handed
           and would not recognise. `findMany` rather than `findUnique`
           so the payload shape does not change with its presence. */
        prisma.orgConfig.findMany({ where, take: PROBE })
      ]);
      const oversized = [
        ["users", users],
        ["reports", reports],
        ["hazards", hazards],
        ["riskAssessments", riskAssessments],
        ["policies", policies],
        ["accountabilities", accountabilities],
        ["appointments", appointments],
        ["exercises", exercises],
        ["documents", documents],
        ["findings", findings],
        ["training", training],
        ["communications", communications],
        ["auditLog", auditLog],
        ["spis", spis],
        ["spiPeriods", spiPeriods],
        ["voluntaryScheme", voluntaryScheme],
        ["changes", changes],
        ["contacts", contacts],
        ["actions", actions],
        ["transitions", transitions],
        ["policyReads", policyReads],
        ["documentReads", documentReads],
        ["config", config2]
      ].filter(([, rows]) => rows.length > EXPORT_LIMIT).map(([name]) => name);
      if (oversized.length) {
        req.log.warn(
          { org: req.auth.org, oversized },
          "export refused \u2014 a collection exceeded the single-file limit"
        );
        return reply.code(413).send({
          error: "too_large",
          limit: EXPORT_LIMIT,
          collections: oversized,
          message: `This operator's record is larger than one export file can carry \u2014 ${oversized.join(", ")} ${oversized.length === 1 ? "exceeds" : "exceed"} ${EXPORT_LIMIT.toLocaleString("en")} rows. Nothing was produced, deliberately: a shortened export looks exactly like a complete one to whoever is handed it, and this file is evidence. Ask for a copy taken in parts.`
        });
      }
      const chain = await verifyAuditChain(req.auth.org);
      await appendAudit({
        orgId: req.auth.org,
        userId: req.auth.sub,
        action: "org.export",
        entityType: "Org",
        entityId: req.auth.org,
        detail: {
          reports: reports.length,
          auditEntries: auditLog.length,
          chainOk: chain.ok
        }
      });
      const chainEntries = auditLog.map((e) => ({ ...e, seq: e.seq.toString() }));
      if (req.query?.pack === "1") {
        const pack = composePack(
          {
            org,
            users,
            reports,
            hazards,
            riskAssessments,
            policies,
            accountabilities,
            appointments,
            exercises,
            documents,
            findings,
            training,
            communications,
            auditLog: chainEntries,
            spis,
            spiPeriods,
            voluntaryScheme,
            changes,
            contacts,
            fatigueLimits,
            actions,
            attachments,
            transitions,
            policyReads,
            documentReads,
            config: config2
          },
          /* @__PURE__ */ new Date()
        );
        const packName = `usalamasms-audit-pack-${req.auth.org}.json`;
        return reply.header("content-disposition", `attachment; filename="${packName}"`).send({ format: EXPORT_FORMAT, pack });
      }
      const filename = `usalamasms-export-${req.auth.org}.json`;
      return reply.header("content-disposition", `attachment; filename="${filename}"`).send({
        format: EXPORT_FORMAT,
        exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
        exportedBy: req.auth.sub,
        org,
        /* The verdict describes the chain AS EXPORTED — the entry
           recording this export is appended above and so is not in
           `auditLog` below. That is stated rather than hidden: a
           reader who verifies this file and finds the last entry
           missing should know it is by construction. */
        /* THREE STATES, NOT TWO, and the third is why this is not
                     just `ok`. verifyAuditChain() returns ok:false for an org
                     with no entries at all — deliberately, under charter rule
                     11: a wiped table must not pass as a clean bill of health.
                     That is right for the verifier and wrong to hand an
                     operator unexplained, because the first export a new
                     operator takes has an empty log and `ok: false` reads as
                     "your record is corrupt" at the exact moment they are
                     deciding whether to trust it.
        
                     So the verdict is passed through untouched — never
                     softened — and `state` says which of the three situations
                     produced it. */
        chain: {
          ok: chain.ok,
          entries: chainEntries.length,
          state: chainEntries.length === 0 ? "empty" : chain.ok ? "verified" : "broken",
          note: chainEntries.length === 0 ? "This operator has no log entries yet, so there is nothing to verify. That is why ok is false: an empty chain is reported as unverified rather than as verified, so a wiped log cannot pass as a clean one." : chain.ok ? "Every entry links to the one before it. The entry recording this export is appended before the file is built, so it appears in the NEXT export rather than this one." : "The chain does not verify. Entries are present but at least one does not link to the one before it. Raise this before relying on the file."
        },
        reports,
        hazards,
        riskAssessments,
        policies,
        accountabilities,
        appointments,
        exercises,
        documents,
        findings,
        training,
        communications,
        users,
        spis,
        spiPeriods,
        voluntaryScheme,
        changes,
        contacts,
        actions,
        attachments,
        transitions,
        policyReads,
        documentReads,
        config: config2,
        auditLog: chainEntries
      });
    }
  );
}
var EXPORT_FORMAT, EXPORT_EXCLUSIONS, EXPORT_LIMIT, PROBE;
var init_routes_export = __esm({
  "apps/api/src/routes.export.ts"() {
    "use strict";
    init_src();
    init_auditpack();
    init_core();
    EXPORT_FORMAT = 2;
    EXPORT_EXCLUSIONS = Object.freeze({
      SyncReceipt: "Carries the device id in cleartext for named submissions, and a clientId that joins straight to the report. A file containing them lets a reader CLUSTER reports by handset \u2014 most of the way to identifying the person at a six-aircraft operator. A delivery mechanism, not a safety record.",
      RefreshToken: "A live credential. An export is a file that leaves the building, and a session token in one is a session somebody else can resume."
    });
    EXPORT_LIMIT = Math.max(
      1,
      Number(process.env["EXPORT_ROW_LIMIT"]) || 2e4
    );
    PROBE = EXPORT_LIMIT + 1;
  }
});

// apps/api/src/routes.admin.ts
import { z as z12 } from "zod";
import argon23 from "argon2";
import { randomBytes as randomBytes3 } from "node:crypto";
function guard5(role, permission) {
  return can(role, permission);
}
function issuePassword2() {
  const bytes = randomBytes3(20);
  let out = "";
  for (const b of bytes) out += ALPHABET[b % ALPHABET.length];
  return `${out.slice(0, 5)}-${out.slice(5, 10)}-${out.slice(10, 15)}-${out.slice(15, 20)}`;
}
async function adminRoutes(app) {
  const limited = {
    preHandler: [authenticate],
    /* Tighter than the operational routes. Nothing here is used in a
       loop, and provisioning runs argon2 — an unthrottled endpoint that
       hashes a password on every call is a CPU exhaustion primitive as
       well as an account-creation one. */
    config: { rateLimit: { max: 30, timeWindow: "1 minute" } }
  };
  app.get("/api/v1/admin/operators", limited, async (req, reply) => {
    if (!guard5(req.auth.role, "platform.operator.provision")) {
      return reply.code(403).send({ error: "forbidden" });
    }
    const orgs = await prisma.org.findMany({
      select: {
        id: true,
        name: true,
        jurisdiction: true,
        aocNumber: true,
        fleetSize: true,
        trialEndsOn: true,
        paidThrough: true,
        createdAt: true,
        _count: { select: { users: true } }
      },
      orderBy: { createdAt: "desc" },
      take: 500
    });
    const now = /* @__PURE__ */ new Date();
    return reply.send({
      operators: orgs.map((o) => ({
        id: o.id,
        name: o.name,
        jurisdiction: o.jurisdiction,
        aocNumber: o.aocNumber,
        fleetSize: o.fleetSize,
        users: o._count.users,
        createdAt: o.createdAt,
        trialEndsOn: o.trialEndsOn,
        paidThrough: o.paidThrough,
        /* Computed here for the same reason it is computed everywhere:
           a stored state is one a failed webhook can leave lying. */
        state: stateOn(
          { trialEndsOn: o.trialEndsOn ?? /* @__PURE__ */ new Date(0), paidThrough: o.paidThrough },
          now
        )
      }))
    });
  });
  app.post("/api/v1/admin/operators", limited, async (req, reply) => {
    if (!guard5(req.auth.role, "platform.operator.provision")) {
      return reply.code(403).send({ error: "forbidden" });
    }
    const body = ProvisionInput.safeParse(req.body);
    if (!body.success) return reply.code(400).send({ error: "invalid_operator" });
    const email = body.data.adminEmail.toLowerCase();
    const existing = await prisma.user.findFirst({ where: { email }, select: { id: true } });
    if (existing) return reply.code(409).send({ error: "email_already_registered" });
    const password = issuePassword2();
    const passwordHash = await argon23.hash(password);
    const now = /* @__PURE__ */ new Date();
    const org = await prisma.$transaction(async (tx) => {
      const created = await tx.org.create({
        data: {
          name: body.data.orgName,
          jurisdiction: body.data.jurisdiction,
          aocNumber: body.data.aocNumber ?? null,
          fleetSize: body.data.fleetSize ?? null,
          /* The trial starts when the account is CREATED, not when
             somebody first signs in. An operator who is handed a
             credential and does not use it for three weeks has spent
             three weeks of trial, and that is the honest reading of a
             clock that starts on provisioning. */
          trialEndsOn: trialEndsFrom(now)
        }
      });
      await tx.user.create({
        data: {
          orgId: created.id,
          email,
          name: body.data.adminName,
          role: body.data.adminRole,
          passwordHash,
          active: true
        }
      });
      return created;
    });
    await prisma.$transaction((tx) => appendAuditTx(tx, {
      orgId: org.id,
      userId: req.auth.sub,
      action: "operator.provisioned",
      entityType: "Org",
      entityId: org.id,
      /* Built field by field. Spreading the request body here would put
         a password in the audit chain the first time this input grows a
         field somebody forgot about. */
      detail: {
        name: org.name,
        jurisdiction: org.jurisdiction,
        firstUserEmail: email,
        firstUserRole: body.data.adminRole,
        trialEndsOn: org.trialEndsOn?.toISOString() ?? null
      }
    }));
    const invitation = await sendInvitation(
      email,
      org.name,
      org.trialEndsOn?.toISOString().slice(0, 10) ?? null,
      mailConfigFromEnv()
    );
    return reply.code(201).send({
      id: org.id,
      name: org.name,
      trialEndsOn: org.trialEndsOn,
      adminEmail: email,
      /* ONCE. Not stored in plaintext, not logged, not returned again.
         The administrator who called this either passes it on now or
         issues a password reset. */
      password,
      passwordShownOnce: true,
      /* SENT / NOT_CONFIGURED / FAILED, never a boolean. "false" would
         collapse "this deployment has no mail key" into "the provider
         refused", and those need different actions from the person
         reading the screen. */
      invitation: invitation.status,
      invitationReason: invitation.status === "FAILED" ? invitation.reason : void 0
    });
  });
  app.post("/api/v1/upgrade-request", limited, async (req, reply) => {
    const auth = req.auth;
    const org = await prisma.org.findUnique({
      where: { id: auth.org },
      select: { name: true, fleetSize: true, trialEndsOn: true, paidThrough: true }
    });
    if (!org) return reply.code(401).send({ error: "invalid_token" });
    const who = await prisma.user.findUnique({
      where: { id: auth.sub },
      select: { email: true, name: true }
    });
    const band = typeof org.fleetSize === "number" && org.fleetSize > 0 ? bandForFleet(org.fleetSize) : null;
    await prisma.$transaction(async (tx) => {
      await appendAuditTx(tx, {
        orgId: auth.org,
        userId: auth.sub,
        action: "platform.upgrade.requested",
        entityType: "Org",
        entityId: auth.org,
        /* Built field by field. Spreading the org would put whatever
           that table grows next into the audit chain, which is the
           trap routes.admin.ts already records about provisioning. */
        detail: {
          fleetSize: org.fleetSize ?? null,
          band: band?.id ?? null,
          usdMonthly: band?.usdMonthly ?? null
        }
      });
    });
    const notice = await sendUpgradeRequest(
      org.name,
      who?.email ?? "unknown",
      org.fleetSize ?? null,
      band ? { name: band.name, usdMonthly: band.usdMonthly } : null,
      mailConfigFromEnv()
    );
    return reply.code(202).send({
      recorded: true,
      /* SENT / NOT_CONFIGURED / FAILED. The operator is told plainly if
         nothing reached us, so they can pick up a phone rather than
         wait. */
      notified: notice.status,
      band: band ? { name: band.name, usdMonthly: band.usdMonthly } : null
    });
  });
  app.get("/api/v1/admin/upgrade-requests", limited, async (req, reply) => {
    if (!guard5(req.auth.role, "platform.entitlement.manage")) {
      return reply.code(403).send({ error: "forbidden" });
    }
    const rows = await prisma.auditLog.findMany({
      where: { action: "platform.upgrade.requested" },
      orderBy: [{ seq: "desc" }],
      take: 100,
      select: {
        createdAt: true,
        orgId: true,
        detail: true,
        org: { select: { name: true, fleetSize: true, trialEndsOn: true, paidThrough: true } }
      }
    });
    const now = /* @__PURE__ */ new Date();
    return reply.send({
      requests: rows.map((r) => {
        const state = stateOn(
          {
            trialEndsOn: r.org.trialEndsOn ?? trialEndsFrom(/* @__PURE__ */ new Date()),
            paidThrough: r.org.paidThrough
          },
          now
        );
        return {
          askedOn: r.createdAt.toISOString(),
          orgId: r.orgId,
          orgName: r.org.name,
          fleetSize: r.org.fleetSize ?? null,
          detail: r.detail ?? null,
          /* ANSWERED means the operator is paid up now, whenever that
             happened. Derived rather than stored: a flag set when an
             entitlement was granted would be wrong the moment one
             lapsed again, and this list is read to decide who still
             needs chasing. */
          answered: state !== "LAPSED",
          state
        };
      })
    });
  });
  app.post("/api/v1/admin/operators/:id/entitlement", limited, async (req, reply) => {
    if (!guard5(req.auth.role, "platform.entitlement.manage")) {
      return reply.code(403).send({ error: "forbidden" });
    }
    const body = EntitlementInput.safeParse(req.body);
    if (!body.success) return reply.code(400).send({ error: "invalid_entitlement" });
    if (body.data.paidThrough === void 0 && body.data.trialEndsOn === void 0) {
      return reply.code(400).send({ error: "nothing_to_change" });
    }
    const id = req.params.id;
    const before = await prisma.org.findUnique({
      where: { id },
      select: { id: true, name: true, trialEndsOn: true, paidThrough: true }
    });
    if (!before) return reply.code(404).send({ error: "not_found" });
    const data = {};
    if (body.data.paidThrough !== void 0) {
      data.paidThrough = body.data.paidThrough ? new Date(body.data.paidThrough) : null;
    }
    if (body.data.trialEndsOn !== void 0) {
      data.trialEndsOn = body.data.trialEndsOn ? new Date(body.data.trialEndsOn) : null;
    }
    const after = await prisma.org.update({
      where: { id },
      data,
      select: { id: true, name: true, trialEndsOn: true, paidThrough: true }
    });
    await prisma.$transaction((tx) => appendAuditTx(tx, {
      orgId: id,
      userId: req.auth.sub,
      action: "entitlement.changed",
      entityType: "Org",
      entityId: id,
      /* BOTH SIDES, because "paid through December" tells you nothing
         about whether that was an extension, a correction or a
         reversal. The audit chain is what this console is answerable
         through, and a one-sided entry cannot answer for a mistake. */
      /* ISO strings rather than Dates: `detail` is a Json column, and a
         Date silently becomes something else on the way through. The
         audit chain is hashed over this value, so "something else" is
         not a cosmetic problem. */
      detail: {
        reason: body.data.reason,
        from: {
          trialEndsOn: before.trialEndsOn?.toISOString() ?? null,
          paidThrough: before.paidThrough?.toISOString() ?? null
        },
        to: {
          trialEndsOn: after.trialEndsOn?.toISOString() ?? null,
          paidThrough: after.paidThrough?.toISOString() ?? null
        }
      }
    }));
    return reply.send({
      id: after.id,
      name: after.name,
      trialEndsOn: after.trialEndsOn,
      paidThrough: after.paidThrough,
      /* An operator with no trial date and no payment has never been
         entitled to anything; stateOn wants a date, so the absence is
         mapped to the epoch rather than smuggled through as null. A
         trial that "ended in 1970" reads as LAPSED, which is the
         truthful answer for an account nobody has granted anything. */
      state: stateOn(
        {
          trialEndsOn: after.trialEndsOn ?? /* @__PURE__ */ new Date(0),
          paidThrough: after.paidThrough
        },
        /* @__PURE__ */ new Date()
      )
    });
  });
}
var ALPHABET, ProvisionInput, EntitlementInput;
var init_routes_admin = __esm({
  "apps/api/src/routes.admin.ts"() {
    "use strict";
    init_src();
    init_regulations();
    init_pricing();
    init_subscription();
    init_core();
    init_mail();
    ALPHABET = "abcdefghijkmnpqrstuvwxyz23456789ACDEFGHJKLMNPQRSTUVWXYZ";
    ProvisionInput = z12.object({
      orgName: z12.string().trim().min(2).max(160),
      jurisdiction: z12.enum(JURISDICTIONS).default("KE"),
      aocNumber: z12.string().trim().max(64).optional(),
      fleetSize: z12.number().int().min(0).max(2e3).optional(),
      adminEmail: z12.string().trim().toLowerCase().email().max(254),
      adminName: z12.string().trim().min(2).max(160),
      /* The first user is the OPERATOR'S own administrator, not ours, and
         not a reporter. Restricted to the two posts that can meaningfully
         receive an empty account: the person who administers it and the
         person accountable for it. */
      adminRole: z12.enum(["SYSTEM_ADMIN", "ACCOUNTABLE_EXECUTIVE"]).default("SYSTEM_ADMIN")
    });
    EntitlementInput = z12.object({
      /* Both nullable on purpose. Clearing `paidThrough` is how a wrongly
         confirmed payment is undone, and a console that can only ever
         extend is one where a mistake is permanent. */
      paidThrough: z12.string().datetime().nullable().optional(),
      trialEndsOn: z12.string().datetime().nullable().optional(),
      /* Free text, required, and it goes in the audit entry. "Why is this
         operator paid through December" is the question this console will
         be asked, and an entitlement change with no reason recorded cannot
         answer it. */
      reason: z12.string().trim().min(3).max(500)
    });
  }
});

// packages/shared/src/icaas.ts
function composeCap(a) {
  const missing = [];
  const action = (a.action ?? "").trim();
  if (!action) missing.push("The corrective action itself is empty.");
  const ownerPost = (a.ownerPost ?? "").trim();
  if (!ownerPost) missing.push("No post is accountable for it \u2014 a CAP with no owner is sent back.");
  const targetDate = iso2(a.dueOn);
  if (!targetDate) {
    missing.push("No target date. The portal's CAP form expects one, and an inspector will ask.");
  }
  if (a.cancelledOn) {
    missing.push("This action was cancelled. It is not an answer to a CAR.");
  }
  const finding = a.finding?.finding?.trim() || null;
  if (a.findingWithheld) {
    missing.push(
      "An audit finding is linked to this action and your role cannot read it. Ask the safety manager or an auditor for the CAR reference before you raise the CAP."
    );
  } else if (!finding) {
    missing.push(
      "No audit finding is linked. The portal raises a CAP against a CAR, so you will need to pick the matching one yourself."
    );
  }
  const evidence = Object.freeze(
    (a.attachments ?? []).filter((f) => f?.sha256).map((f) => Object.freeze({ label: f.label ?? "Untitled", sha256: f.sha256 }))
  );
  return Object.freeze({
    reference: a.finding?.auditRef?.trim() || a.id || "\u2014",
    finding,
    action,
    ownerPost,
    targetDate,
    completedOn: iso2(a.completedOn),
    verifiedOn: iso2(a.verifiedOn),
    evidence,
    missing: Object.freeze(missing),
    readyToSubmit: missing.length === 0
  });
}
var SUBMITS_TO_AUTHORITY, ICAAS_PORTAL, ICAAS_SOURCE, CAP_STEPS, PREREQUISITES, iso2;
var init_icaas = __esm({
  "packages/shared/src/icaas.ts"() {
    "use strict";
    SUBMITS_TO_AUTHORITY = false;
    ICAAS_PORTAL = "https://ecitizen.kcaa.or.ke";
    ICAAS_SOURCE = "ICAAS External Portal User Manual, Kenya Civil Aviation Authority (2023). The portal is a web application with no published API \u2014 this product prepares the pack and links to it, and does not submit on the operator's behalf.";
    CAP_STEPS = Object.freeze([
      "Sign in at the portal as the organisation, or as a Representative authorised to transact for it.",
      "Open the operator's CARs and find the one this corrective action answers.",
      "Create or amend the CAP, pasting the action, the owner and the target date below.",
      "Submit it, and wait for the inspector's comments and approval status.",
      "Once the CAP is approved, upload the implementation evidence against it."
    ]);
    PREREQUISITES = Object.freeze([
      "A KCAA customer account with a valid email address.",
      "A self-service transactional account, activated from the emailed link.",
      "Internal approval of the account, which the manual puts at up to one hour on a working day."
    ]);
    iso2 = (v) => v == null ? null : v instanceof Date ? v.toISOString() : String(v);
  }
});

// apps/api/src/routes.icaas.ts
async function icaasRoutes(app) {
  const composed = {
    preHandler: [authenticate, requireEntitlement("GENERATE_DOCUMENT")],
    config: { rateLimit: { max: 60, timeWindow: "1 minute" } }
  };
  app.get(
    "/api/v1/icaas/cap/:id",
    composed,
    async (req, reply) => {
      const auth = req.auth;
      if (!can(auth.role, "report.read.org")) {
        return reply.code(403).send({ error: "forbidden" });
      }
      const action = await prisma.correctiveAction.findFirst({
        /* tenantWhere FIRST, and the id as a further condition rather
           than a findUnique with a tenancy check after — one query that
           cannot return another operator's row is safer than two
           statements that must be read together to see that it cannot. */
        where: { ...tenantWhere(req), id: req.params.id },
        select: {
          id: true,
          action: true,
          ownerPost: true,
          dueOn: true,
          completedOn: true,
          verifiedOn: true,
          cancelledOn: true,
          findingId: true,
          reportId: true
        }
      });
      if (!action) return reply.code(404).send({ error: "not_found" });
      const mayReadFindings = can(auth.role, "audit.read");
      const withheld = [];
      let finding = null;
      if (action.findingId && mayReadFindings) {
        const row = await prisma.auditFinding.findFirst({
          where: { ...tenantWhere(req), id: action.findingId },
          select: { finding: true, auditRef: true }
        });
        if (row) finding = row;
      }
      if (action.findingId && !mayReadFindings) {
        withheld.push(
          "The linked audit finding and its CAR reference \u2014 these need audit access."
        );
      }
      const mayReadEvidence = can(auth.role, "report.read.org");
      let attachments = [];
      if (action.reportId && mayReadEvidence) {
        const rows = await prisma.reportAttachment.findMany({
          where: { ...tenantWhere(req), reportId: action.reportId },
          select: { label: true, sha256: true },
          take: 50
        });
        attachments = rows.map((r) => ({
          label: r.label ?? "Untitled",
          sha256: r.sha256
        }));
      }
      if (action.reportId && !mayReadEvidence) {
        withheld.push("Files attached to the originating report \u2014 these need report access.");
      }
      const pack = composeCap({
        ...action,
        finding,
        findingWithheld: Boolean(action.findingId) && !mayReadFindings,
        attachments
      });
      return reply.send({
        /* Re-sent on every response rather than compiled into a screen.
           A constant a client caches is a constant a client can be
           wrong about, and this is the one fact in the feature that
           must never be wrong. */
        submitsToAuthority: SUBMITS_TO_AUTHORITY,
        portal: ICAAS_PORTAL,
        source: ICAAS_SOURCE,
        steps: CAP_STEPS,
        prerequisites: PREREQUISITES,
        pack,
        /* Named, not dropped. An empty array means nothing was hidden
           from this reader — which is a different statement from a
           pack that happens to look complete. */
        withheld
      });
    }
  );
}
var init_routes_icaas = __esm({
  "apps/api/src/routes.icaas.ts"() {
    "use strict";
    init_src();
    init_icaas();
    init_core();
  }
});

// apps/api/src/rate-limit-key.ts
function rateLimitKey(headers, fallbackIp) {
  const platform = headers[EDGE_HEADER];
  const value = Array.isArray(platform) ? platform[0] : platform;
  const trimmed = value?.trim();
  return trimmed ? `edge:${trimmed}` : `ip:${fallbackIp}`;
}
var EDGE_HEADER;
var init_rate_limit_key = __esm({
  "apps/api/src/rate-limit-key.ts"() {
    "use strict";
    EDGE_HEADER = "x-nf-client-connection-ip";
  }
});

// apps/api/src/schema-guard.ts
async function missingTables(prisma2) {
  const rows = await prisma2.$queryRawUnsafe(
    `SELECT t.name, to_regclass('public.' || quote_ident(t.name)) IS NOT NULL AS present
       FROM unnest($1::text[]) AS t(name)`,
    EXPECTED_TABLES
  );
  return rows.filter((r) => !r.present).map((r) => r.name).sort();
}
var EXPECTED_TABLES;
var init_schema_guard = __esm({
  "apps/api/src/schema-guard.ts"() {
    "use strict";
    EXPECTED_TABLES = Object.freeze([
      "Accountability",
      "Appointment",
      "AuditFinding",
      "AuditLog",
      "ChangeAssessment",
      "ControlledDocument",
      "CorrectiveAction",
      "DocumentAcknowledgement",
      "EmergencyContact",
      "EmergencyExercise",
      "FatigueLimit",
      "Hazard",
      "Org",
      "OrgConfig",
      "PasswordReset",
      "PolicyAcknowledgement",
      "RefreshToken",
      "ReportAttachment",
      "ReportTransition",
      "RiskAssessment",
      "SafetyCommunication",
      "SafetyPolicy",
      "SafetyReport",
      "Spi",
      "SpiPeriod",
      "SyncReceipt",
      "TrainingRecord",
      "User",
      "VoluntaryScheme"
    ]);
  }
});

// apps/api/src/server.ts
var server_exports = {};
__export(server_exports, {
  build: () => build
});
import Fastify from "fastify";
import rateLimit from "@fastify/rate-limit";
async function build() {
  const app = Fastify({
    // ==================================================================
    // ONE HOP, not `true`. The difference is the whole rate limit.
    //
    // `trustProxy: true` makes Fastify resolve req.ip as the LEFTMOST
    // X-Forwarded-For entry, which is the one the caller writes. The
    // comment that used to sit here asserted the opposite — that a
    // caller could not forge their way into a fresh bucket. Booting a
    // Fastify instance with that exact configuration says otherwise:
    //
    //   trustProxy: true   XFF "FORGED, 9.9.9.9, 8.8.8.8" -> FORGED
    //   trustProxy: 1      XFF "FORGED, 9.9.9.9, 8.8.8.8" -> 8.8.8.8
    //
    // A number trusts that many hops from the right, so what survives is
    // what the immediate proxy appended rather than what arrived with
    // the request. One hop, because there is one proxy.
    //
    // This alone is not sufficient — a caller sending a SINGLE forged
    // entry is still the rightmost — which is why rateLimitKey() below
    // prefers the platform's own header over the IP entirely. Both are
    // here on purpose: the header is the control, the hop count is what
    // stops the fallback being free to forge.
    // ==================================================================
    trustProxy: 1,
    logger: {
      level: process.env["LOG_LEVEL"] ?? "info",
      // ==============================================================
      // REDACTION IS NOT OPTIONAL HERE.
      //
      // The whole product rests on a promise that a safety narrative
      // reaches the safety office and nobody else. A request logger that
      // prints bodies would write those narratives — and the identity of
      // anonymous reporters — into a log aggregator with a completely
      // different access model, where they are searchable by anyone with
      // operations access and retained on somebody else's schedule.
      //
      // This is the same failure as the sync receipt: not a leak in the
      // feature, a leak in the plumbing around it.
      // ==============================================================
      redact: {
        paths: [
          "req.headers.authorization",
          "req.headers.cookie",
          "req.body.narrative",
          "req.body.password",
          "req.body.items",
          "res.headers['set-cookie']"
        ],
        censor: "[REDACTED]"
      },
      serializers: {
        req(req) {
          return { method: req.method, url: req.url, id: req.id };
        }
      }
    }
  });
  app.addContentTypeParser(
    "application/json",
    { parseAs: "string", bodyLimit: 1048576 },
    (_req, body, done) => {
      try {
        done(null, JSON.parse(body));
      } catch {
        done(Object.assign(new Error("invalid_json"), { statusCode: 400 }), void 0);
      }
    }
  );
  await app.register(rateLimit, {
    global: false,
    // Per-IP. `trustProxy` above means this is the client address from
    // X-Forwarded-For rather than the edge's — behind Netlify the header
    // is set by the platform, so a caller cannot forge their way into a
    // fresh bucket by sending their own.
    keyGenerator: (req) => rateLimitKey(req.headers, req.ip),
    // In-memory, which means PER INSTANCE. On a container host that is
    // the whole limit. On Lambda each warm instance keeps its own
    // counter, so the effective limit is the configured one times the
    // concurrency — a real weakening, and the honest fix is a shared
    // store (Redis) rather than a larger number here. Stated because a
    // limit whose true value is unknown to its reader is barely a limit.
    // Even so: 10-per-instance beats unbounded by the entire distance
    // between a control and no control.
    // `statusCode` is carried on the object deliberately. The plugin
    // hands whatever this returns to setErrorHandler below, which decides
    // the status from `err.statusCode` — without it the throttle arrived
    // as a 500, telling a client to retry a request the server had in
    // fact refused on purpose. Found by asserting 429 and getting 500.
    errorResponseBuilder: () => ({ statusCode: 429, error: "too_many_requests" })
  });
  app.setErrorHandler((err, req, reply) => {
    req.log.error({ err: { message: err.message, code: err.code } }, "request failed");
    const thrown = err;
    if (err.statusCode === 429) {
      reply.code(429).send({ error: thrown.error ?? "too_many_requests" });
      return;
    }
    const status = err.statusCode && err.statusCode < 500 ? err.statusCode : 500;
    reply.code(status).send({ error: status === 500 ? "internal_error" : err.message });
  });
  for (const prefix of ["", "/api"]) {
    app.get(`${prefix}/health`, async () => ({ ok: true }));
    app.get(`${prefix}/ready`, async (_req, reply) => {
      try {
        const missing = await missingTables(prisma);
        if (missing.length) {
          return reply.code(503).send({
            ok: false,
            reason: "schema_behind_code",
            missingTables: missing,
            detail: "The database is reachable but does not have every table this build queries. Run the outstanding Prisma migration \u2014 deploying code does not apply one."
          });
        }
        return { ok: true };
      } catch {
        return reply.code(503).send({ ok: false, reason: "unreachable" });
      }
    });
  }
  await app.register(authRoutes);
  await app.register(syncRoutes);
  await app.register(smsRoutes);
  await app.register(spiRoutes);
  await app.register(registerRoutes);
  await app.register(changeRoutes);
  await app.register(reportRoutes);
  await app.register(configRoutes);
  await app.register(attachmentRoutes);
  await app.register(pictureRoutes);
  await app.register(fatigueRoutes);
  await app.register(digestRoutes);
  await app.register(actionRoutes);
  await app.register(erpRoutes);
  await app.register(exportRoutes);
  await app.register(adminRoutes);
  await app.register(icaasRoutes);
  app.get(
    "/api/v1/orgs/:orgId/audit/verify",
    { preHandler: [authenticate, requirePermission("regulator.oversight")] },
    async (req, reply) => {
      if (req.params.orgId !== req.auth.org) {
        return reply.code(403).send({ error: "forbidden" });
      }
      return verifyAuditChain(req.params.orgId);
    }
  );
  app.post(
    "/api/v1/reports/:id/deidentify",
    {
      preHandler: [authenticate, requirePermission("report.deidentify.review")],
      config: { rateLimit: { max: 30, timeWindow: "1 minute" } }
    },
    async (req, reply) => {
      const report = await prisma.safetyReport.findFirst({
        where: { id: req.params.id, orgId: req.auth.org },
        select: { id: true }
      });
      if (!report) return reply.code(404).send({ error: "not_found" });
      try {
        const { residual } = await deIdentifyVcr(req.params.id, req.auth.sub, {
          reviewerAcceptedResidual: req.body?.acceptResidual === true
        });
        return reply.send({ ok: true, residual });
      } catch (err) {
        if (err instanceof ResidualIdentifiersError) {
          return reply.code(409).send({
            error: "residual_identifiers",
            residual: err.residual,
            hint: "A named reviewer must confirm before distribution. Re-send with acceptResidual: true."
          });
        }
        throw err;
      }
    }
  );
  return app;
}
var init_server = __esm({
  "apps/api/src/server.ts"() {
    "use strict";
    init_core();
    init_routes_sync();
    init_routes_auth();
    init_routes_sms();
    init_routes_spi();
    init_routes_register();
    init_routes_change();
    init_routes_reports();
    init_routes_config();
    init_routes_attachments();
    init_routes_picture();
    init_routes_fatigue();
    init_routes_digest();
    init_routes_actions();
    init_routes_erp();
    init_routes_export();
    init_routes_admin();
    init_routes_icaas();
    init_rate_limit_key();
    init_schema_guard();
    if (process.argv[1] && import.meta.url.endsWith(process.argv[1].replace(/^.*[/\\]/, ""))) {
      const port = Number(process.env["PORT"] ?? 8080);
      build().then(
        (app) => app.listen({ port, host: "0.0.0.0" }).then(() => {
          app.log.info({ port, ttl: ENV.ACCESS_TTL }, "usalamasms api listening");
        })
      ).catch((err) => {
        console.error("FATAL: could not start", err);
        process.exit(1);
      });
    }
  }
});

// netlify/functions/api.mts
var appPromise = null;
function missingConfig() {
  const missing = [];
  const candidate = Netlify.env.get("NETLIFY_DB_URL") ?? Netlify.env.get("DATABASE_URL") ?? Netlify.env.get("SUPABASE_DATABASE_URL");
  if (!candidate) {
    missing.push("NETLIFY_DB_URL \u2014 connect Netlify Database to this project");
  } else if (!/^postgres(ql)?:\/\//.test(candidate)) {
    missing.push(
      "Database connection \u2014 set, but not a Postgres URI. The Supabase extension's SUPABASE_DATABASE_URL is the REST API base (https://\u2026), not a connection string; connect Netlify Database or set DATABASE_URL explicitly."
    );
  }
  for (const name of ["JWT_SECRET", "DEIDENT_SALT"]) {
    if (!Netlify.env.get(name)) missing.push(name);
  }
  return missing;
}
var api_default = async (req, _context) => {
  const missing = missingConfig();
  if (missing.length > 0) {
    return Response.json(
      {
        error: "not_configured",
        missing,
        hint: "Set these on the Netlify project. See docs/06-DEPLOYMENT.md."
      },
      { status: 503, headers: { "cache-control": "no-store" } }
    );
  }
  try {
    if (!appPromise) {
      appPromise = Promise.resolve().then(() => (init_server(), server_exports)).then(async (mod) => {
        const app2 = await mod.build();
        await app2.ready();
        return app2;
      });
    }
    const app = await appPromise;
    const url = new URL(req.url);
    const body = req.method === "GET" || req.method === "HEAD" ? void 0 : await req.text();
    const res = await app.inject({
      method: req.method,
      url: url.pathname + url.search,
      headers: headersToObject(req.headers),
      ...body === void 0 ? {} : { payload: body }
    });
    return new Response(res.body, {
      status: res.statusCode,
      headers: res.headers
    });
  } catch (err) {
    console.error("[usalamasms] function failed", err);
    appPromise = null;
    return Response.json({ error: "internal_error" }, { status: 500 });
  }
};
function headersToObject(headers) {
  const out = {};
  headers.forEach((value, key) => {
    out[key] = value;
  });
  return out;
}
var config = {
  path: "/api/*"
};
export {
  config,
  api_default as default
};
